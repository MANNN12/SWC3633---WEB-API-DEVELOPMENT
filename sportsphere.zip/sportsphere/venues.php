<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_helpers.php';

jsonHeaders(['GET', 'POST', 'PUT', 'DELETE']);
$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? validId($_GET['id']) : null;

if ($method === 'GET') {
    if ($id !== null) {
        $stmt = $conn->prepare('SELECT * FROM venues WHERE id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $venue = $stmt->get_result()->fetch_assoc();
        if (!$venue) respond(404, ['error' => 'Venue not found']);
        respond(200, ['data' => $venue]);
    }

    $result = $conn->query('SELECT * FROM venues ORDER BY id ASC');
    respond(200, ['data' => $result->fetch_all(MYSQLI_ASSOC)]);
}

if ($method === 'POST') {
    $currentUser = authenticateToken();
    authorizeRoles(['admin', 'staff'], $currentUser);

    $data = readJson();
    $name = trim($data['venue_name'] ?? '');
    $category = trim($data['category'] ?? '');
    $rate = filter_var($data['hourly_rate'] ?? null, FILTER_VALIDATE_FLOAT);

    if (empty($name) || empty($category) || $rate === false) {
        respond(422, ['error' => 'Invalid or missing venue specifications']);
    }

    $stmt = $conn->prepare('INSERT INTO venues (venue_name, category, hourly_rate) VALUES (?, ?, ?)');
    $stmt->bind_param('ssd', $name, $category, $rate);
    $stmt->execute();

    respond(201, ['message' => 'Venue created successfully', 'id' => $conn->insert_id]);
}

if ($method === 'PUT') {
    $currentUser = authenticateToken();
    authorizeRoles(['admin', 'staff'], $currentUser);

    if ($id === null) respond(400, ['error' => 'Venue ID is required']);

    $data = readJson();
    $name = trim($data['venue_name'] ?? '');
    $rate = filter_var($data['hourly_rate'] ?? null, FILTER_VALIDATE_FLOAT);
    $available = isset($data['is_available']) ? (int)$data['is_available'] : 1;

    $stmt = $conn->prepare('UPDATE venues SET venue_name = ?, hourly_rate = ?, is_available = ? WHERE id = ?');
    $stmt->bind_param('sdii', $name, $rate, $available, $id);
    $stmt->execute();

    respond(200, ['message' => 'Venue record updated successfully']);
}

if ($method === 'DELETE') {
    $currentUser = authenticateToken();
    authorizeRoles(['admin'], $currentUser);

    if ($id === null) respond(400, ['error' => 'Venue ID is required']);

    $stmt = $conn->prepare('DELETE FROM venues WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();

    respond(200, ['message' => 'Venue deleted successfully']);
}

respond(405, ['error' => 'Method Not Allowed']);