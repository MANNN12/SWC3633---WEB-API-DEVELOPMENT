import { api, login, paidMap, rememberPayment, setUserName, getExp } from './api.js';
import { $, $$, esc, rm, fdate, today, icon, LOGO, badge, toast, skeleton, empty, errorBox, modal, confirmBox, busy, dataTable, art } from './ui.js';

const bName = b => b.booking_type === 'event' ? (b.event_name || 'Event #' + b.event_id) : (b.venue_name || 'Venue #' + b.venue_id);
const left = e => Math.max(0, (+e.total_tickets || 0) - (+e.tickets_sold || 0));
const isPast = e => String(e.event_date).slice(0, 10) < today();
const sum = (a, f) => a.reduce((s, x) => s + (Number(f(x)) || 0), 0);
const field = (id, label, attrs = '', hint = '') => `<div class="field"><label for="${id}">${label}</label><input id="${id}" ${attrs}>${hint ? `<small>${hint}</small>` : ''}<small class="ferr" id="${id}-e" role="alert"></small></div>`;
const setErr = (id, msg) => { const e = $('#' + id + '-e'); if (e) e.textContent = msg || ''; const i = $('#' + id); if (i) i.setAttribute('aria-invalid', msg ? 'true' : 'false'); return !msg; };
const stat = (label, value, ic, sub = '') => `<div class="stat"><span class="stat-ic">${icon(ic)}</span><div><small>${esc(label)}</small><b>${esc(value)}</b>${sub ? `<em>${esc(sub)}</em>` : ''}</div></div>`;
const head = (title, sub, actions = '') => `<div class="page-head"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div><div class="actions">${actions}</div></div>`;
const stack = parts => { const t = sum(parts, p => p[1]) || 1; return `<div class="stack" role="img" aria-label="${esc(parts.map(p => p[0] + ': ' + p[1]).join(', '))}">${parts.map(p => p[1] ? `<i style="flex:${p[1]};background:${p[2]}" title="${esc(p[0])}"></i>` : '').join('')}</div><ul class="legend">${parts.map(p => `<li><i style="background:${p[2]}"></i>${esc(p[0])} <b>${p[1]}</b></li>`).join('')}</ul>`; };

async function load(host, fn) {
  host.innerHTML = skeleton();
  try { await fn(); } catch (e) { if (e.status === -1) return; host.innerHTML = errorBox(e, true); const b = $('[data-retry]', host); if (b) b.onclick = () => load(host, fn); }
}

/* ---------------- Auth ---------------- */
export function authPage(host, mode, onDone, notice = '') {
  const reg = mode === 'register';
  host.innerHTML = `<div class="auth"><aside class="auth-art"><div class="brandline"><span class="mark">${LOGO}</span>SportSphere</div>
    <svg class="court" viewBox="0 0 400 260" aria-hidden="true"><g fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="2"><rect x="20" y="20" width="360" height="220" rx="14"/><path d="M200 20v220M20 90h70v80H20M380 90h-70v80h70"/><circle cx="200" cy="130" r="42"/><circle cx="200" cy="130" r="4" fill="#fff"/></g></svg>
    <h2>Book courts. Join events. Play more.</h2><p>One place to reserve sports facilities and tickets for tournaments.</p></aside>
    <main class="auth-form"><form id="af" novalidate><h1>${reg ? 'Create your account' : 'Welcome back'}</h1><p class="sub">${reg ? 'Sign up as a customer to book venues and event tickets.' : 'Sign in to manage your bookings and events.'}</p>
    ${notice ? `<div class="alert warn" role="alert">${esc(notice)}</div>` : ''}<div class="alert bad" id="aerr" role="alert" hidden></div>
    ${reg ? field('name', 'Full name', 'autocomplete="name" required') : ''}${field('email', 'Email', 'type="email" autocomplete="email" required')}
    <div class="field"><label for="pw">Password</label><div class="pw"><input id="pw" type="password" autocomplete="${reg ? 'new-password' : 'current-password'}" required><button type="button" class="icon-btn" id="tpw" aria-label="Show password" aria-pressed="false">${icon('eye')}</button></div><small class="ferr" id="pw-e" role="alert"></small></div>
    <button class="btn primary lg" id="sub" type="submit">${reg ? 'Create account' : 'Sign in'}</button>
    <p class="switch">${reg ? 'Already registered? <a href="#/login">Sign in</a>' : 'New customer? <a href="#/register">Create an account</a>'}</p></form></main></div>`;
  $('#tpw').onclick = e => { const p = $('#pw'), s = p.type === 'password'; p.type = s ? 'text' : 'password'; e.currentTarget.innerHTML = icon(s ? 'eyeoff' : 'eye'); e.currentTarget.setAttribute('aria-pressed', s); e.currentTarget.setAttribute('aria-label', s ? 'Hide password' : 'Show password'); };
  $('#af').onsubmit = async ev => {
    ev.preventDefault(); const err = $('#aerr'); err.hidden = true;
    const name = reg ? $('#name').value.trim() : '', email = $('#email').value.trim(), pw = $('#pw').value;
    let ok = true;
    if (reg) ok = setErr('name', name ? '' : 'Enter your name.') && ok;
    ok = setErr('email', /^\S+@\S+\.\S+$/.test(email) ? '' : 'Enter a valid email address.') && ok;
    ok = setErr('pw', pw ? '' : 'Enter your password.') && ok;
    if (!ok) return;
    await busy($('#sub'), async () => {
      try {
        if (reg) { await api.register({ name, email, password: pw, role: 'customer' }); }
        onDone(await login(email, pw));
      } catch (e) { err.textContent = e.message; err.hidden = false; }
    });
  };
}

/* ---------------- Dashboards ---------------- */
const greet = u => { const h = new Date().getHours(); return `${h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'}, ${u.name.split(' ')[0]}`; };
const hero = (u, sub, cta = '') => `<section class="hero"><div><small>${new Date().toLocaleDateString('en-MY', { weekday: 'long', day: 'numeric', month: 'long' })}</small><h1>${esc(greet(u))}</h1><p>${esc(sub)}</p></div><div class="actions">${cta}</div></section>`;
const mini = (b, extra = '') => `<li><div><b>${esc(bName(b))}</b><small>${fdate(b.booking_date)} · ${b.booking_type === 'event' ? b.quantity + ' ticket(s)' : b.quantity + ' hr'} · ${rm(b.total_price)}</small></div>${badge(b.status)}${extra}</li>`;

export async function dashboard(host, { user }) {
  await load(host, async () => {
    const needPay = user.role === 'staff' || user.role === 'admin';
    const [bk, ev, vn, pay, us] = await Promise.all([api.bookings(), api.events(), api.venues(), needPay ? api.payments() : null, user.role === 'admin' ? api.users() : null]);
    const live = bk.filter(b => b.status !== 'cancelled');
    let h = '';
    if (user.role === 'customer') {
      const mine = bk.filter(b => +b.customer_id === +user.id), up = mine.filter(b => b.status !== 'cancelled' && String(b.booking_date) >= today()).sort((a, b) => a.booking_date > b.booking_date ? 1 : -1);
      const nxt = ev.filter(e => !isPast(e) && left(e) > 0).sort((a, b) => a.event_date > b.event_date ? 1 : -1).slice(0, 3);
      h = hero(user, up.length ? `Your next booking is ${bName(up[0])} on ${fdate(up[0].booking_date)}.` : 'Find a court or grab tickets to an upcoming event.', `<a class="btn primary" href="#/venues">Book a venue</a><a class="btn ghost" href="#/events">Browse events</a>`) +
        `<div class="stats">${stat('My bookings', mine.length, 'ticket')}${stat('Upcoming', up.length, 'calendar')}${stat('Awaiting confirmation', mine.filter(b => b.status === 'pending').length, 'clock')}${stat('Booked value', rm(sum(mine.filter(b => b.status !== 'cancelled'), b => b.total_price)), 'card', 'excluding cancelled')}</div>
        <div class="grid2"><section class="card"><h2>Upcoming bookings</h2>${up.length ? `<ul class="list">${up.slice(0, 5).map(b => mini(b)).join('')}</ul>` : empty('No upcoming bookings', 'Book a venue or event to see it here.')}<a class="more" href="#/bookings">All my bookings →</a></section>
        <section class="card"><h2>Open for tickets</h2>${nxt.length ? `<ul class="list">${nxt.map(e => `<li><div><b>${esc(e.event_name)}</b><small>${fdate(e.event_date)} · ${left(e)} left</small></div><b>${+e.ticket_price ? rm(e.ticket_price) : 'Free'}</b></li>`).join('')}</ul>` : empty('No events open right now')}<a class="more" href="#/events">All events →</a></section></div>`;
    } else if (user.role === 'organiser') {
      const my = ev.filter(e => +e.organiser_id === +user.id), ids = new Set(my.map(e => +e.id)), eb = live.filter(b => b.booking_type === 'event' && ids.has(+b.event_id));
      h = hero(user, 'Track ticket sales across your events.', `<a class="btn primary" href="#/manage/events">Manage my events</a>`) +
        `<div class="stats">${stat('My events', my.length, 'calendar')}${stat('Tickets booked', sum(my, e => e.tickets_sold), 'ticket', 'of ' + sum(my, e => e.total_tickets) + ' available')}${stat('Booked value', rm(sum(eb, b => b.total_price)), 'card', 'non-cancelled bookings')}${stat('Upcoming', my.filter(e => !isPast(e)).length, 'clock')}</div>
        <section class="card"><h2>Your events</h2>${my.length ? `<ul class="list">${my.map(e => `<li><div><b>${esc(e.event_name)}</b><small>${fdate(e.event_date)} · ${rm(e.ticket_price)}</small><div class="bar"><i style="width:${Math.min(100, (+e.tickets_sold / (+e.total_tickets || 1)) * 100)}%"></i></div></div><span>${e.tickets_sold}/${e.total_tickets}</span></li>`).join('')}</ul>` : empty('No events yet', 'Create your first event from "My events".')}</section>`;
    } else if (user.role === 'staff') {
      const pend = bk.filter(b => b.status === 'pending');
      h = hero(user, pend.length ? `${pend.length} booking(s) are waiting for confirmation.` : 'The confirmation queue is clear.', `<a class="btn primary" href="#/manage/bookings">Open bookings</a>`) +
        `<div class="stats">${stat('Pending bookings', pend.length, 'clock')}${stat('Confirmed', bk.filter(b => b.status === 'confirmed').length, 'check')}${stat('Payments completed', rm(sum(pay.filter(p => p.payment_status === 'completed'), p => p.amount)), 'card')}${stat('Venues available', vn.filter(v => +v.is_available).length + '/' + vn.length, 'court')}</div>
        <section class="card"><h2>Confirmation queue</h2>${pend.length ? `<ul class="list">${pend.slice(0, 6).map(b => mini(b)).join('')}</ul>` : empty('Nothing pending')}<a class="more" href="#/manage/bookings">Manage bookings →</a></section>`;
    } else {
      const cnt = (a, k, v) => a.filter(x => x[k] === v).length;
      h = hero(user, 'System overview from live records.', `<a class="btn primary" href="#/users">Manage users</a>`) +
        `<div class="stats">${stat('Users', us.length, 'users')}${stat('Venues', vn.length, 'court')}${stat('Events', ev.length, 'calendar')}${stat('Bookings', bk.length, 'ticket')}${stat('Payments completed', rm(sum(pay.filter(p => p.payment_status === 'completed'), p => p.amount)), 'card')}</div>
        <div class="grid2"><section class="card"><h2>Bookings by status</h2>${stack([['Confirmed', cnt(bk, 'status', 'confirmed'), 'var(--ok)'], ['Pending', cnt(bk, 'status', 'pending'), 'var(--warn)'], ['Cancelled', cnt(bk, 'status', 'cancelled'), 'var(--bad)']])}</section>
        <section class="card"><h2>Payments by status</h2>${stack([['Completed', cnt(pay, 'payment_status', 'completed'), 'var(--ok)'], ['Pending', cnt(pay, 'payment_status', 'pending'), 'var(--warn)'], ['Failed', cnt(pay, 'payment_status', 'failed'), 'var(--bad)']])}</section></div>`;
    }
    host.innerHTML = h;
  });
}

/* ---------------- Venues ---------------- */
function bookVenue(v, { user, go }) {
  const d = modal({ title: 'Book ' + v.venue_name, body: `<form id="bf" novalidate>${art(v.category)}<p class="muted">${esc(v.category)} · ${rm(v.hourly_rate)} per hour</p>
    ${field('bdate', 'Date', `type="date" min="${today()}" value="${today()}" required`)}${field('bqty', 'Number of hours', 'type="number" min="1" max="24" step="1" value="1" required', 'The system charges the hourly rate × this number.')}
    <div class="total"><span>Estimated total</span><b id="btot">${rm(v.hourly_rate)}</b></div><p class="note">${icon('info')}Bookings start as <b>pending</b> until staff confirm them. The server does not check for overlapping bookings.</p>
    <div class="m-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" id="bsub">Request booking</button></div></form>` });
  const upd = () => { $('#btot').textContent = rm(v.hourly_rate * (parseInt($('#bqty').value) || 0)); };
  d.addEventListener('input', upd); d.addEventListener('click', e => e.target.closest('[data-close]') && d.close());
  $('#bf', d).onsubmit = async ev => {
    ev.preventDefault(); const date = $('#bdate').value, q = parseInt($('#bqty').value);
    let ok = setErr('bdate', date && date >= today() ? '' : 'Choose today or a future date.');
    ok = setErr('bqty', q >= 1 && q <= 24 ? '' : 'Enter 1–24 hours.') && ok; if (!ok) return;
    await busy($('#bsub'), async () => {
      try { const r = await api.createBooking({ customer_id: +user.id, booking_type: 'venue', venue_id: +v.id, booking_date: date, quantity: q }); d.close(); toast(`Booking #${r.booking_id} requested (${r.status}).`); go('/bookings'); }
      catch (e) { toast(e.message, 'bad'); }
    });
  };
}
export async function venuesPage(host, ctx) {
  await load(host, async () => {
    const vn = await api.venues(), cats = [...new Set(vn.map(v => v.category))].sort();
    host.innerHTML = head('Venues', 'Courts and facilities you can rent by the hour.', ctx.user.role === 'staff' || ctx.user.role === 'admin' ? '<a class="btn" href="#/manage/venues">Manage venues</a>' : '') +
      `<div class="toolbar"><label class="search">${icon('search')}<input type="search" id="vq" placeholder="Search venues…" aria-label="Search venues"></label><select id="vc" aria-label="Category"><option value="">Category: all</option>${cats.map(c => `<option>${esc(c)}</option>`).join('')}</select><select id="va" aria-label="Availability"><option value="">Availability: all</option><option value="1">Available</option><option value="0">Unavailable</option></select><select id="vs" aria-label="Sort"><option value="n">Sort: name</option><option value="pa">Price: low to high</option><option value="pd">Price: high to low</option></select></div><div class="cards" id="vg"></div>`;
    const draw = () => {
      const q = $('#vq').value.toLowerCase(), c = $('#vc').value, a = $('#va').value, s = $('#vs').value;
      const r = vn.filter(v => (!q || (v.venue_name + ' ' + v.category).toLowerCase().includes(q)) && (!c || v.category === c) && (a === '' || String(+v.is_available) === a));
      r.sort((x, y) => s === 'pa' ? x.hourly_rate - y.hourly_rate : s === 'pd' ? y.hourly_rate - x.hourly_rate : x.venue_name.localeCompare(y.venue_name));
      $('#vg').innerHTML = r.length ? r.map(v => `<article class="vcard">${art(v.category)}<div class="vc-body"><div class="row"><h3>${esc(v.venue_name)}</h3>${badge(+v.is_available ? 'Available' : 'Unavailable')}</div><p class="muted">${esc(v.category)}</p><div class="row"><b class="price">${rm(v.hourly_rate)}<small> / hr</small></b>${ctx.user.role === 'customer' ? `<button class="btn primary sm" data-book="${v.id}" ${+v.is_available ? '' : 'disabled'}>Book</button>` : ''}</div></div></article>`).join('') : `<div style="grid-column:1/-1">${empty(vn.length ? 'No venues match' : 'No venues registered yet')}</div>`;
    };
    host.oninput = host.onchange = draw; draw();
    host.onclick = e => { const b = e.target.closest('[data-book]'); if (b) bookVenue(vn.find(v => +v.id === +b.dataset.book), ctx); };
  });
}

/* ---------------- Events ---------------- */
function bookEvent(ev, { user, go }) {
  const max = left(ev);
  const d = modal({ title: 'Tickets: ' + ev.event_name, body: `<form id="bf" novalidate><p class="muted">${fdate(ev.event_date)} · ${+ev.ticket_price ? rm(ev.ticket_price) + ' per ticket' : 'Free entry'} · ${max} left</p>
    ${field('bqty', 'Tickets', `type="number" min="1" max="${max}" step="1" value="1" required`)}<div class="total"><span>Estimated total</span><b id="btot">${rm(ev.ticket_price)}</b></div>
    <p class="note">${icon('info')}Bookings start as <b>pending</b> until staff confirm them. The remaining-ticket limit shown here is a guide; the server does not enforce it.</p>
    <div class="m-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" id="bsub">Request tickets</button></div></form>` });
  d.addEventListener('input', () => { $('#btot').textContent = rm(ev.ticket_price * (parseInt($('#bqty').value) || 0)); });
  d.addEventListener('click', e => e.target.closest('[data-close]') && d.close());
  $('#bf', d).onsubmit = async e2 => {
    e2.preventDefault(); const q = parseInt($('#bqty').value);
    if (!setErr('bqty', q >= 1 && q <= max ? '' : `Enter 1–${max} tickets.`)) return;
    await busy($('#bsub'), async () => {
      try { const r = await api.createBooking({ customer_id: +user.id, booking_type: 'event', event_id: +ev.id, booking_date: String(ev.event_date).slice(0, 10), quantity: q }); d.close(); toast(`Booking #${r.booking_id} requested (${r.status}).`); go('/bookings'); }
      catch (e) { toast(e.message, 'bad'); }
    });
  };
}
export async function eventsPage(host, ctx) {
  await load(host, async () => {
    const evs = await api.events();
    host.innerHTML = head('Events', 'Tournaments and community sports events.', ['organiser', 'admin'].includes(ctx.user.role) ? '<a class="btn" href="#/manage/events">Manage events</a>' : '') +
      `<div class="toolbar"><label class="search">${icon('search')}<input type="search" id="eq" placeholder="Search events…" aria-label="Search events"></label><select id="ew" aria-label="When"><option value="">When: all</option><option value="u">Upcoming</option><option value="p">Past</option></select><select id="ep" aria-label="Price"><option value="">Price: all</option><option value="f">Free</option><option value="x">Paid</option></select><select id="es" aria-label="Sort"><option value="d">Sort: soonest</option><option value="l">Latest</option><option value="p">Price: low to high</option></select></div><div class="cards" id="eg"></div>`;
    const draw = () => {
      const q = $('#eq').value.toLowerCase(), w = $('#ew').value, p = $('#ep').value, s = $('#es').value;
      const r = evs.filter(e => (!q || e.event_name.toLowerCase().includes(q)) && (!w || (w === 'p') === isPast(e)) && (!p || (p === 'f') === !+e.ticket_price));
      r.sort((a, b) => s === 'p' ? a.ticket_price - b.ticket_price : (a.event_date > b.event_date ? 1 : -1) * (s === 'l' ? -1 : 1));
      $('#eg').innerHTML = r.length ? r.map(e => { const l = left(e), pct = Math.min(100, (+e.tickets_sold / (+e.total_tickets || 1)) * 100), st = isPast(e) ? 'Past' : l ? '' : 'Sold out';
        return `<article class="ecard"><div class="date"><b>${new Date(String(e.event_date).slice(0, 10) + 'T00:00:00').getDate()}</b><span>${new Date(String(e.event_date).slice(0, 10) + 'T00:00:00').toLocaleDateString('en-MY', { month: 'short' })}</span></div><div class="ec-body"><div class="row"><h3>${esc(e.event_name)}</h3>${st ? badge(st) : ''}</div><p class="muted">${fdate(e.event_date)}</p><div class="bar"><i style="width:${pct}%"></i></div><small class="muted">${l} of ${e.total_tickets} tickets left</small><div class="row"><b class="price">${+e.ticket_price ? rm(e.ticket_price) : 'Free'}</b>${ctx.user.role === 'customer' ? `<button class="btn primary sm" data-book="${e.id}" ${st ? 'disabled' : ''}>Get tickets</button>` : ''}</div></div></article>`; }).join('') : `<div style="grid-column:1/-1">${empty(evs.length ? 'No events match' : 'No events published yet')}</div>`;
    };
    host.oninput = host.onchange = draw; draw();
    host.onclick = e => { const b = e.target.closest('[data-book]'); if (b) bookEvent(evs.find(x => +x.id === +b.dataset.book), ctx); };
  });
}

/* ---------------- Customer bookings ---------------- */
function payDialog(b, { user }, done) {
  const d = modal({ title: 'Pay for booking #' + b.id, body: `<form id="pf"><p><b>${esc(bName(b))}</b><br><span class="muted">${fdate(b.booking_date)}</span></p><div class="total"><span>Amount</span><b>${rm(b.total_price)}</b></div>
    <div class="field"><label for="pm">Payment method</label><select id="pm"><option value="fpx">Online banking (FPX)</option><option value="card">Credit / debit card</option><option value="e-wallet">E-wallet</option></select></div>
    <p class="note">${icon('info')}SportSphere has no external payment gateway: submitting records a payment with the server, which immediately marks it completed.</p>
    <div class="m-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" id="psub">Record payment</button></div></form>` });
  d.addEventListener('click', e => e.target.closest('[data-close]') && d.close());
  $('#pf', d).onsubmit = async ev => {
    ev.preventDefault();
    await busy($('#psub'), async () => {
      try { const method = $('#pm').value, r = await api.pay({ booking_id: +b.id, payment_method: method, amount: +b.total_price }); rememberPayment(user.id, b.id, { ref: r.transaction_ref, method, amount: +b.total_price }); d.close(); toast('Payment recorded. Reference ' + r.transaction_ref); done(); }
      catch (e) { toast(e.message, 'bad'); }
    });
  };
}
export async function myBookings(host, ctx) {
  await load(host, async () => {
    const mine = (await api.bookings()).filter(b => +b.customer_id === +ctx.user.id), paid = paidMap(ctx.user.id);
    host.innerHTML = head('My bookings', 'Your venue rentals and event tickets.') + `<div class="alert info">${icon('info')}Customers can't cancel bookings or view payment history in the current system; contact staff to cancel. "Paid" reflects payments made in this browser.</div><div id="bt"></div>`;
    dataTable($('#bt'), {
      rows: mine, text: b => `${b.id} ${bName(b)} ${b.status} ${b.booking_date}`, emptyMsg: 'You have no bookings yet.',
      filters: [{ label: 'Status', options: ['pending', 'confirmed', 'cancelled'], get: b => b.status }, { label: 'Type', options: ['venue', 'event'], get: b => b.booking_type }],
      cols: [{ label: 'Ref', render: b => '#' + b.id, sort: b => +b.id }, { label: 'Booking', render: b => `<b>${esc(bName(b))}</b><small class="block muted">${esc(b.booking_type)}</small>`, sort: bName }, { label: 'Date', render: b => fdate(b.booking_date), sort: b => b.booking_date },
        { label: 'Qty', render: b => b.quantity + (b.booking_type === 'venue' ? ' hr' : '') }, { label: 'Total', render: b => rm(b.total_price), sort: b => +b.total_price }, { label: 'Status', render: b => badge(b.status) },
        { label: 'Payment', render: b => paid[b.id] ? badge('Paid', 'ok') + `<small class="block muted">${esc(paid[b.id].ref)}</small>` : b.status === 'cancelled' ? '—' : '<span class="muted">Not paid</span>' },
        { label: '', render: b => `<button class="btn sm" data-d="${b.id}">Details</button>${!paid[b.id] && b.status !== 'cancelled' ? ` <button class="btn primary sm" data-pay="${b.id}">Pay</button>` : ''}` }],
    });
    host.onclick = e => {
      const dt = e.target.closest('[data-d]'), py = e.target.closest('[data-pay]');
      if (dt) { const b = mine.find(x => +x.id === +dt.dataset.d); modal({ title: 'Booking #' + b.id, body: `<dl class="dl"><dt>Item</dt><dd>${esc(bName(b))}</dd><dt>Type</dt><dd>${esc(b.booking_type)}</dd><dt>Date</dt><dd>${fdate(b.booking_date)}</dd><dt>Quantity</dt><dd>${b.quantity}</dd><dt>Total</dt><dd>${rm(b.total_price)}</dd><dt>Status</dt><dd>${badge(b.status)}</dd></dl>${b.status === 'confirmed' && b.qr_code_url ? `<div class="qr"><img src="${esc(b.qr_code_url)}" alt="QR ticket for booking ${b.id}" width="150" height="150"><small>Show this QR code at the venue.</small></div>` : '<p class="muted">A QR ticket appears here once staff confirm the booking.</p>'}` }); }
      if (py) payDialog(mine.find(x => +x.id === +py.dataset.pay), ctx, () => ctx.refresh());
    };
  });
}

/* ---------------- Staff/Admin: bookings & payments ---------------- */
export async function manageBookings(host, ctx) {
  await load(host, async () => {
    const bk = await api.bookings(), admin = ctx.user.role === 'admin';
    host.innerHTML = head('Bookings', 'Review, confirm and cancel customer bookings. Confirming issues the QR ticket.') + '<div id="bt"></div>';
    const act = (b, label, cls, st) => `<button class="btn sm ${cls}" data-st="${st}" data-id="${b.id}">${label}</button>`;
    dataTable($('#bt'), {
      rows: bk, text: b => `${b.id} ${b.customer_name} ${bName(b)} ${b.status}`, emptyMsg: 'No bookings have been made yet.',
      filters: [{ label: 'Status', options: ['pending', 'confirmed', 'cancelled'], get: b => b.status }, { label: 'Type', options: ['venue', 'event'], get: b => b.booking_type }],
      cols: [{ label: 'Ref', render: b => '#' + b.id, sort: b => +b.id }, { label: 'Customer', render: b => esc(b.customer_name || 'User #' + b.customer_id), sort: b => b.customer_name || '' }, { label: 'Booking', render: b => `<b>${esc(bName(b))}</b><small class="block muted">${esc(b.booking_type)} · ×${b.quantity}</small>`, sort: bName },
        { label: 'Date', render: b => fdate(b.booking_date), sort: b => b.booking_date }, { label: 'Total', render: b => rm(b.total_price), sort: b => +b.total_price }, { label: 'Status', render: b => badge(b.status), sort: b => b.status },
        { label: 'Actions', render: b => `<div class="btns">${b.status !== 'confirmed' ? act(b, 'Confirm', 'primary', 'confirmed') : ''}${b.status !== 'cancelled' ? act(b, 'Cancel', '', 'cancelled') : ''}${b.status !== 'pending' ? act(b, 'Reopen', '', 'pending') : ''}${admin ? `<button class="btn sm danger" data-del="${b.id}" aria-label="Delete booking ${b.id}">${icon('trash')}</button>` : ''}</div>` }],
    });
    host.onclick = async e => {
      const s = e.target.closest('[data-st]'), d = e.target.closest('[data-del]');
      if (s) await busy(s, async () => { try { await api.setBookingStatus(s.dataset.id, s.dataset.st); toast(`Booking #${s.dataset.id} set to ${s.dataset.st}.`); ctx.refresh(); } catch (er) { toast(er.message, 'bad'); } });
      if (d && await confirmBox({ title: 'Delete booking?', text: `Booking #${d.dataset.del} will be permanently removed.`, okLabel: 'Delete', danger: true })) { try { await api.deleteBooking(d.dataset.del); toast('Booking deleted.'); ctx.refresh(); } catch (er) { toast(er.message, 'bad'); } }
    };
  });
}
export async function paymentsPage(host) {
  await load(host, async () => {
    const [pay, bk] = await Promise.all([api.payments(), api.bookings()]), bm = Object.fromEntries(bk.map(b => [b.id, b]));
    host.innerHTML = head('Payments', 'Read-only record of payments received.') + `<div class="stats">${stat('Completed', rm(sum(pay.filter(p => p.payment_status === 'completed'), p => p.amount)), 'check')}${stat('Pending', pay.filter(p => p.payment_status === 'pending').length, 'clock')}${stat('Failed', pay.filter(p => p.payment_status === 'failed').length, 'x')}${stat('Records', pay.length, 'card')}</div><div id="pt"></div>`;
    dataTable($('#pt'), {
      rows: pay, text: p => `${p.transaction_ref} ${p.payment_method} ${p.payment_status} ${(bm[p.booking_id] || {}).customer_name || ''}`, emptyMsg: 'No payments recorded yet.',
      filters: [{ label: 'Status', options: ['completed', 'pending', 'failed'], get: p => p.payment_status }, { label: 'Method', options: ['fpx', 'card', 'e-wallet'], get: p => p.payment_method }],
      cols: [{ label: 'Reference', render: p => `<b>${esc(p.transaction_ref)}</b>`, sort: p => p.transaction_ref }, { label: 'Booking', render: p => { const b = bm[p.booking_id]; return b ? `#${b.id} · ${esc(bName(b))}<small class="block muted">${esc(b.customer_name || '')}</small>` : '#' + p.booking_id; } },
        { label: 'Method', render: p => esc(p.payment_method), sort: p => p.payment_method }, { label: 'Amount', render: p => rm(p.amount), sort: p => +p.amount }, { label: 'Status', render: p => badge(p.payment_status) }, { label: 'Date', render: p => fdate(p.created_at), sort: p => p.created_at }],
    });
  });
}

/* ---------------- Staff/Admin: venues ---------------- */
function venueForm(v, done) {
  const d = modal({ title: v ? 'Edit venue' : 'Add venue', body: `<form id="vf" novalidate>${field('vn', 'Venue name', `value="${esc(v ? v.venue_name : '')}" required`)}${v ? `<p class="muted">Category: ${esc(v.category)} (cannot be changed)</p>` : field('vcat', 'Category / sport', 'list="cats" placeholder="e.g. Futsal" required') + '<datalist id="cats"><option>Futsal</option><option>Badminton</option><option>Pickleball</option><option>Tennis</option><option>Basketball</option></datalist>'}
    ${field('vr', 'Hourly rate (RM)', `type="number" min="0" step="0.01" value="${v ? v.hourly_rate : ''}" required`)}${v ? `<label class="check"><input type="checkbox" id="va" ${+v.is_available ? 'checked' : ''}> Available for booking</label>` : ''}
    <div class="m-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" id="vs">Save</button></div></form>` });
  d.addEventListener('click', e => e.target.closest('[data-close]') && d.close());
  $('#vf', d).onsubmit = async ev => {
    ev.preventDefault(); const name = $('#vn').value.trim(), rate = parseFloat($('#vr').value), cat = v ? '' : $('#vcat').value.trim();
    let ok = setErr('vn', name ? '' : 'Enter a name.'); if (!v) ok = setErr('vcat', cat ? '' : 'Enter a category.') && ok; ok = setErr('vr', rate >= 0 ? '' : 'Enter a valid rate.') && ok; if (!ok) return;
    await busy($('#vs'), async () => { try { v ? await api.updateVenue(v.id, { venue_name: name, hourly_rate: rate, is_available: $('#va').checked ? 1 : 0 }) : await api.createVenue({ venue_name: name, category: cat, hourly_rate: rate }); d.close(); toast(v ? 'Venue updated.' : 'Venue added.'); done(); } catch (e) { toast(e.message, 'bad'); } });
  };
}
export async function manageVenues(host, ctx) {
  await load(host, async () => {
    const vn = await api.venues(), admin = ctx.user.role === 'admin';
    host.innerHTML = head('Manage venues', 'Add courts, change rates and toggle availability.', '<button class="btn primary" id="addv">' + icon('plus') + ' Add venue</button>') + '<div id="vt"></div>';
    dataTable($('#vt'), { rows: vn, text: v => v.venue_name + ' ' + v.category, emptyMsg: 'No venues yet. Add the first one.', filters: [{ label: 'Category', options: [...new Set(vn.map(v => v.category))], get: v => v.category }, { label: 'Status', options: ['Available', 'Unavailable'], get: v => +v.is_available ? 'Available' : 'Unavailable' }],
      cols: [{ label: 'Venue', render: v => `<b>${esc(v.venue_name)}</b>`, sort: v => v.venue_name }, { label: 'Category', render: v => esc(v.category), sort: v => v.category }, { label: 'Rate', render: v => rm(v.hourly_rate) + ' /hr', sort: v => +v.hourly_rate }, { label: 'Status', render: v => badge(+v.is_available ? 'Available' : 'Unavailable') },
        { label: 'Actions', render: v => `<div class="btns"><button class="btn sm" data-e="${v.id}">${icon('edit')} Edit</button>${admin ? `<button class="btn sm danger" data-del="${v.id}" aria-label="Delete ${esc(v.venue_name)}">${icon('trash')}</button>` : ''}</div>` }] });
    $('#addv').onclick = () => venueForm(null, ctx.refresh);
    host.onclick = async e => { const ed = e.target.closest('[data-e]'), dl = e.target.closest('[data-del]');
      if (ed) venueForm(vn.find(v => +v.id === +ed.dataset.e), ctx.refresh);
      if (dl && await confirmBox({ title: 'Delete venue?', text: 'This permanently removes the venue.', okLabel: 'Delete', danger: true })) { try { await api.deleteVenue(dl.dataset.del); toast('Venue deleted.'); ctx.refresh(); } catch (er) { toast(er.message, 'bad'); } } };
  });
}

/* ---------------- Organiser/Admin: events ---------------- */
function eventForm(ev, orgs, ctx, done) {
  const admin = ctx.user.role === 'admin';
  const d = modal({ title: ev ? 'Edit event' : 'Create event', body: `<form id="ef" novalidate>${field('en', 'Event name', `value="${esc(ev ? ev.event_name : '')}" required`)}${ev ? `<p class="muted">Date and total tickets can't be changed after publishing.</p>` : field('ed', 'Event date', `type="date" min="${today()}" required`) + field('etk', 'Total tickets', 'type="number" min="1" step="1" required') + (admin ? `<div class="field"><label for="eo">Organiser</label><select id="eo">${orgs.map(o => `<option value="${o.id}">${esc(o.name)}</option>`).join('')}</select></div>` : '')}
    ${field('ep', 'Ticket price (RM, 0 for free)', `type="number" min="0" step="0.01" value="${ev ? ev.ticket_price : ''}" required`)}<div class="m-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" id="es">${ev ? 'Save' : 'Publish'}</button></div></form>` });
  d.addEventListener('click', e => e.target.closest('[data-close]') && d.close());
  $('#ef', d).onsubmit = async x => {
    x.preventDefault(); const name = $('#en').value.trim(), price = parseFloat($('#ep').value);
    let ok = setErr('en', name ? '' : 'Enter a name.') && true; ok = setErr('ep', price >= 0 ? '' : 'Enter a valid price.') && ok;
    let date, tix; if (!ev) { date = $('#ed').value; tix = parseInt($('#etk').value); ok = setErr('ed', date ? '' : 'Choose a date.') && ok; ok = setErr('etk', tix >= 1 ? '' : 'Enter at least 1 ticket.') && ok; if (admin && !orgs.length) { toast('No organiser accounts exist to assign.', 'bad'); ok = false; } }
    if (!ok) return;
    await busy($('#es'), async () => { try { ev ? await api.updateEvent(ev.id, { event_name: name, ticket_price: price }) : await api.createEvent({ event_name: name, organiser_id: admin ? +$('#eo').value : +ctx.user.id, event_date: date, ticket_price: price, total_tickets: tix }); d.close(); toast(ev ? 'Event updated.' : 'Event published.'); done(); } catch (e) { toast(e.message, 'bad'); } });
  };
}
export async function manageEvents(host, ctx) {
  await load(host, async () => {
    const admin = ctx.user.role === 'admin', [all, users] = await Promise.all([api.events(), admin ? api.users() : []]);
    const evs = admin ? all : all.filter(e => +e.organiser_id === +ctx.user.id), orgs = users.filter(u => u.role === 'organiser'), on = Object.fromEntries(users.map(u => [u.id, u.name]));
    host.innerHTML = head(admin ? 'Manage events' : 'My events', admin ? 'All events across organisers.' : 'Events you have published.', '<button class="btn primary" id="adde">' + icon('plus') + ' Create event</button>') + '<div id="et"></div>';
    dataTable($('#et'), { rows: evs, text: e => e.event_name, emptyMsg: 'No events yet. Create your first event.', filters: [{ label: 'When', options: ['Upcoming', 'Past'], get: e => isPast(e) ? 'Past' : 'Upcoming' }],
      cols: [{ label: 'Event', render: e => `<b>${esc(e.event_name)}</b>${admin ? `<small class="block muted">${esc(on[e.organiser_id] || 'Organiser #' + e.organiser_id)}</small>` : ''}`, sort: e => e.event_name }, { label: 'Date', render: e => fdate(e.event_date), sort: e => e.event_date }, { label: 'Price', render: e => +e.ticket_price ? rm(e.ticket_price) : 'Free', sort: e => +e.ticket_price },
        { label: 'Tickets', render: e => `${e.tickets_sold} / ${e.total_tickets} sold`, sort: e => +e.tickets_sold }, { label: 'Actions', render: e => `<div class="btns"><button class="btn sm" data-e="${e.id}">${icon('edit')} Edit</button><button class="btn sm danger" data-del="${e.id}" aria-label="Delete ${esc(e.event_name)}">${icon('trash')}</button></div>` }] });
    $('#adde').onclick = () => eventForm(null, orgs, ctx, ctx.refresh);
    host.onclick = async e => { const ed = e.target.closest('[data-e]'), dl = e.target.closest('[data-del]');
      if (ed) eventForm(evs.find(x => +x.id === +ed.dataset.e), orgs, ctx, ctx.refresh);
      if (dl && await confirmBox({ title: 'Delete event?', text: 'The event is removed permanently. Existing bookings for it are not changed by this action.', okLabel: 'Delete', danger: true })) { try { await api.deleteEvent(dl.dataset.del); toast('Event deleted.'); ctx.refresh(); } catch (er) { toast(er.message, 'bad'); } } };
  });
}

/* ---------------- Admin: users ---------------- */
export async function usersPage(host, ctx) {
  await load(host, async () => {
    const us = await api.users();
    host.innerHTML = head('Users', 'Accounts registered in the system.', '<button class="btn primary" id="addu">' + icon('plus') + ' Add user</button>') + '<div id="ut"></div>';
    dataTable($('#ut'), { rows: us, text: u => `${u.name} ${u.email} ${u.role}`, filters: [{ label: 'Role', options: ['admin', 'organiser', 'staff', 'customer'], get: u => u.role }],
      cols: [{ label: 'Name', render: u => `<span class="avatar sm">${esc(u.name.slice(0, 1))}</span> <b>${esc(u.name)}</b>`, sort: u => u.name }, { label: 'Email', render: u => esc(u.email), sort: u => u.email }, { label: 'Role', render: u => badge(u.role, 'role'), sort: u => u.role }, { label: 'Joined', render: u => fdate(u.created_at), sort: u => u.created_at },
        { label: 'Actions', render: u => `<div class="btns"><button class="btn sm" data-e="${u.id}">${icon('edit')} Role</button>${+u.id !== +ctx.user.id ? `<button class="btn sm danger" data-del="${u.id}" aria-label="Delete ${esc(u.name)}">${icon('trash')}</button>` : ''}</div>` }] });
    $('#addu').onclick = () => { const d = modal({ title: 'Add user', body: `<form id="uf" novalidate>${field('un', 'Full name', 'required')}${field('ue', 'Email', 'type="email" required')}${field('up', 'Password', 'type="password" autocomplete="new-password" required')}<div class="field"><label for="ur">Role</label><select id="ur"><option>customer</option><option>organiser</option><option>staff</option><option>admin</option></select></div><div class="m-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" id="us">Create</button></div></form>` });
      d.addEventListener('click', e => e.target.closest('[data-close]') && d.close());
      $('#uf', d).onsubmit = async ev => { ev.preventDefault(); const n = $('#un').value.trim(), em = $('#ue').value.trim(), pw = $('#up').value; let ok = setErr('un', n ? '' : 'Enter a name.'); ok = setErr('ue', /^\S+@\S+\.\S+$/.test(em) ? '' : 'Enter a valid email.') && ok; ok = setErr('up', pw ? '' : 'Enter a password.') && ok; if (!ok) return;
        await busy($('#us'), async () => { try { await api.register({ name: n, email: em, password: pw, role: $('#ur').value }); d.close(); toast('User created.'); ctx.refresh(); } catch (e) { toast(e.message, 'bad'); } }); }; };
    host.onclick = async e => { const ed = e.target.closest('[data-e]'), dl = e.target.closest('[data-del]');
      if (ed) { const u = us.find(x => +x.id === +ed.dataset.e), d = modal({ title: 'Change role: ' + u.name, body: `<form id="rf"><div class="field"><label for="rr">Role</label><select id="rr">${['customer', 'organiser', 'staff', 'admin'].map(r => `<option ${r === u.role ? 'selected' : ''}>${r}</option>`).join('')}</select></div><div class="m-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" id="rs">Save</button></div></form>` });
        d.addEventListener('click', x => x.target.closest('[data-close]') && d.close());
        $('#rf', d).onsubmit = async ev => { ev.preventDefault(); await busy($('#rs'), async () => { try { await api.updateUser(u.id, { name: u.name, role: $('#rr').value }); d.close(); toast('Role updated.'); ctx.refresh(); } catch (er) { toast(er.message, 'bad'); } }); }; }
      if (dl && await confirmBox({ title: 'Delete user?', text: 'This permanently removes the account.', okLabel: 'Delete', danger: true })) { try { await api.deleteUser(dl.dataset.del); toast('User deleted.'); ctx.refresh(); } catch (er) { toast(er.message, 'bad'); } } };
  });
}

/* ---------------- Profile ---------------- */
export function profilePage(host, ctx) {
  const u = ctx.user, exp = getExp();
  host.innerHTML = head('Profile', 'Your account details.') + `<section class="card narrow"><div class="prof"><span class="avatar lg">${esc(u.name.slice(0, 1).toUpperCase())}</span><div><h2>${esc(u.name)}</h2>${badge(u.role, 'role')}</div></div>
    <dl class="dl"><dt>User ID</dt><dd>#${u.id}</dd><dt>Session expires</dt><dd>${exp ? new Date(exp * 1000).toLocaleTimeString('en-MY', { hour: '2-digit', minute: '2-digit' }) : '—'}</dd></dl>
    <form id="pnf" novalidate>${field('pn', 'Display name', `value="${esc(u.name)}" required`)}<button class="btn primary" id="pns">Save name</button></form><p class="note">${icon('info')}Your email, password and role can't be changed here: the system provides no endpoint for that.</p></section>`;
  $('#pnf').onsubmit = async e => { e.preventDefault(); const n = $('#pn').value.trim(); if (!setErr('pn', n ? '' : 'Enter a name.')) return;
    await busy($('#pns'), async () => { try { await api.updateUser(u.id, { name: n, role: u.role }); setUserName(n); toast('Name updated.'); ctx.shell(); } catch (er) { toast(er.message, 'bad'); } }); };
}
