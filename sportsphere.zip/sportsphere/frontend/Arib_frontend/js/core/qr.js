// Ticket QR display for the GoQR (api.qrserver.com) integration.
//
// The QR URL is produced by the backend: bookings.php calls generateQRCode() in api_helpers.php with
// "SPORTSPHERE-BOOKING-CUST{id}-DATE{date}-PRICE{total}" when a booking becomes confirmed, stores the URL in
// bookings.qr_code_url and returns it. This file never builds ticket data itself and holds no key (the service
// needs none); it only checks the URL, shows it clearly, and handles loading and failure.
import { icon } from './icons.js';
import { esc } from './ui.js';

const HOST = 'api.qrserver.com';
const PATH = '/v1/create-qr-code/';
const SHOW_SIZE = '240x240'; // backend asks for 150x150; the same service renders the same data crisper at this size
const LOAD_TIMEOUT_MS = 12000;

/** Returns {src, data} for a URL that came from the GoQR service, or null for anything else. */
export function qrInfo(u) {
  if (typeof u !== 'string') return null;
  let url;
  try { url = new URL(u); } catch { return null; }
  if (url.protocol !== 'https:' || url.hostname !== HOST || url.pathname !== PATH || url.username || url.password) return null;
  const data = url.searchParams.get('data');
  if (!data) return null;
  const show = new URL(url.href);
  show.searchParams.set('size', SHOW_SIZE);
  return { src: show.href, data };
}

/** Markup for a QR ticket. Call mountQr(root) afterwards to start loading the image. */
export function qrTicket(u, { title = 'Entry QR code', note = 'Show this code on arrival.' } = {}) {
  const info = qrInfo(u);
  if (!info) return '';
  return `<div class="ticket" data-qr="${esc(info.src)}">
    <div class="qr-box" role="img" aria-label="${esc(title)}"><div class="skel" data-qr-skel></div></div>
    <div><h4>${esc(title)}</h4><p class="muted" style="font-size:14px">${esc(note)}</p><div class="code" title="Data encoded in this QR code">${esc(info.data)}</div></div>
  </div>`;
}

function load(box, src) {
  box.querySelectorAll('img.qr, .qr-fail').forEach(n => n.remove());
  const skel = box.querySelector('[data-qr-skel]') || box.appendChild(Object.assign(document.createElement('div'), { className: 'skel' }));
  skel.hidden = false; skel.setAttribute('data-qr-skel', '');
  const img = new Image();
  img.className = 'qr'; img.alt = 'QR code for this booking'; img.decoding = 'async'; img.referrerPolicy = 'no-referrer';
  let settled = false;
  const fail = () => {
    if (settled) return; settled = true; clearTimeout(timer);
    skel.hidden = true; img.remove();
    box.insertAdjacentHTML('beforeend', `<div class="qr-fail">${icon('alert')}<span>The QR image could not be loaded. The QR service may be offline or blocked on this network.</span><button type="button" class="btn btn-ghost btn-sm" data-qr-retry>${icon('refresh', 'i-sm')} Try again</button></div>`);
    box.querySelector('[data-qr-retry]').onclick = () => load(box, src);
  };
  const timer = setTimeout(fail, LOAD_TIMEOUT_MS);
  img.onload = () => { if (settled) return; settled = true; clearTimeout(timer); skel.hidden = true; box.dataset.state = 'ready'; };
  img.onerror = fail;
  box.dataset.state = 'loading';
  box.appendChild(img);
  img.src = src;
}

export function mountQr(root) {
  root.querySelectorAll('[data-qr]').forEach(t => { const box = t.querySelector('.qr-box'); if (box && !box.dataset.state) load(box, t.dataset.qr); });
}
