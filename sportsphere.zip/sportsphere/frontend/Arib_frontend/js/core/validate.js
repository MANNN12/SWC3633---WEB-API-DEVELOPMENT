// Client-side input checks that mirror what the PHP backend already enforces, so mistakes are caught
// before a request is sent. They are a convenience for the user, not security: the server remains
// the authority (readJson(), validId(), filter_var() and the role checks in api_helpers.php).

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export const BOOKING_TYPES = ['venue', 'event'];
export const BOOKING_STATUSES = ['pending', 'confirmed', 'cancelled'];
export const PAYMENT_METHODS = ['fpx', 'card', 'e-wallet'];
export const ROLES = ['admin', 'organiser', 'staff', 'customer'];

export class ValidationError extends Error {
  constructor(message, field) { super(message); this.name = 'ValidationError'; this.field = field; }
}
const fail = (message, field) => { throw new ValidationError(message, field); };

// validId(): a whole number >= 1
export const isId = v => { const n = Number(v); return Number.isInteger(n) && n >= 1 && String(v).trim() !== ''; };
export const isEmail = v => EMAIL.test(String(v || '').trim());
export const isDate = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) && !Number.isNaN(Date.parse(v));
export const isMoney = v => v !== '' && v != null && Number.isFinite(Number(v));
export const text = (v, { min = 1, max = 255 } = {}) => { const s = String(v ?? '').trim(); return s.length >= min && s.length <= max; };

/* Request-body checks, keyed by the endpoint they protect. Each throws ValidationError with a plain message. */
export const rules = {
  login(b) {
    if (!text(b.email) || !text(b.password)) fail('Email and password are required.', 'email');
    if (!isEmail(b.email)) fail('Enter a valid email address.', 'email');
  },
  register(b) {
    if (!text(b.name)) fail('Enter your full name.', 'name');
    if (!isEmail(b.email)) fail('Enter a valid email address.', 'email');
    if (!text(b.password)) fail('Enter a password.', 'password');
    if (b.role && !ROLES.includes(b.role)) fail('Choose a valid role.', 'role');
  },
  booking(b) {
    if (!isId(b.customer_id)) fail('Your account could not be identified. Please sign in again.', 'customer_id');
    if (!BOOKING_TYPES.includes(b.booking_type)) fail('Choose a venue or event booking.', 'booking_type');
    if (b.booking_type === 'venue' && !isId(b.venue_id)) fail('Choose a venue to book.', 'venue_id');
    if (b.booking_type === 'event' && !isId(b.event_id)) fail('Choose an event to book.', 'event_id');
    if (!isDate(b.booking_date)) fail('Choose a valid date.', 'booking_date');
    if (!isId(b.quantity)) fail('Quantity must be at least 1.', 'quantity');
  },
  bookingStatus(b) { if (!BOOKING_STATUSES.includes(b.status)) fail('Choose a valid status.', 'status'); },
  payment(b) {
    if (!isId(b.booking_id)) fail('Choose a booking to pay for.', 'booking_id');
    if (!PAYMENT_METHODS.includes(b.payment_method)) fail('Choose a payment method.', 'payment_method');
    if (!isMoney(b.amount) || Number(b.amount) < 0) fail('Enter a valid amount.', 'amount');
  },
  venue(b, { creating = true } = {}) {
    if (!text(b.venue_name, { max: 120 })) fail('Enter a venue name.', 'venue_name');
    if (creating && !text(b.category, { max: 50 })) fail('Enter a category.', 'category');
    if (!isMoney(b.hourly_rate) || Number(b.hourly_rate) < 0) fail('Enter a valid hourly rate.', 'hourly_rate');
  },
  event(b, { creating = true } = {}) {
    if (!text(b.event_name, { max: 150 })) fail('Enter an event name.', 'event_name');
    if (!isMoney(b.ticket_price) || Number(b.ticket_price) < 0) fail('Enter a valid ticket price.', 'ticket_price');
    if (creating) {
      if (!isId(b.organiser_id)) fail('Choose an organiser.', 'organiser_id');
      if (!isDate(b.event_date)) fail('Choose a valid event date.', 'event_date');
      if (!isId(b.total_tickets)) fail('Capacity must be at least 1.', 'total_tickets');
    }
  },
  userUpdate(b) {
    if (!text(b.name)) fail('Enter a name.', 'name');
    if (!ROLES.includes(b.role)) fail('Choose a valid role.', 'role');
  },
};
