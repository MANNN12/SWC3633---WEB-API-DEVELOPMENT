// API client for the existing SportSphere PHP backend (read-only consumer; nothing here changes the backend).
//
// How this file lines up with the backend (api_helpers.php, auth.php):
//  - Security: auth.php verifies the password and signs the HS256 JWT with a server-side secret. The browser never
//    sees that secret and never hashes or compares passwords; it sends the password once over the login request
//    and keeps only the returned token. The token's `exp` claim is read here so expired sessions are dropped.
//  - Middleware: authenticateToken() expects "Authorization: Bearer <jwt>" and answers 401; authorizeRoles()
//    answers 403. jsonHeaders() makes every reply JSON and answers CORS preflight. This client sends that header,
//    handles 401/403 in one place and treats anything that is not JSON as a server fault.
//  - API management: logRequest() writes each hit to api_access.log on the server (nothing to do client-side);
//    respond() always returns {error: "..."} on failure, which is surfaced as the message; readJson() rejects
//    bodies that are not JSON objects, so bodies are checked here first (validate.js).
import { rules, isId, ValidationError } from './validate.js';

/* ---------- where the API lives ---------- */
const m = location.pathname.match(/^(.*?\/)frontend\/Arib_frontend/);
const FALLBACK_BASE = m ? m[1] : '/sportsphere/';
// Optional override for serving the frontend from a different origin (e.g. Live Server). The backend's CORS
// headers (Access-Control-Allow-Origin / -Headers / -Methods) make that work; same-origin needs no setting.
function configuredBase() {
  try {
    const v = localStorage.getItem('ss_api_base');
    if (v && /^https?:\/\/[^\s]+\/$/.test(v)) return v;
  } catch { /* storage unavailable */ }
  return null;
}
export const API_BASE = configuredBase() || FALLBACK_BASE;

const KEY = 'ss_arib_session';
const REQUEST_TIMEOUT_MS = 20000;
const ROLE_SET = new Set(['admin', 'organiser', 'staff', 'customer']);
let session = null;
let expiryTimer = null;

/* ---------- JWT handling (decoding only; signing and verifying stay on the server) ---------- */
// auth.php builds tokens with plain base64 (not base64url), so accept both alphabets and any padding.
function decodePart(part) {
  const s = String(part).replace(/-/g, '+').replace(/_/g, '/');
  const bin = atob(s + '='.repeat((4 - (s.length % 4)) % 4));
  try { return JSON.parse(decodeURIComponent(bin.split('').map(c => '%' + c.charCodeAt(0).toString(16).padStart(2, '0')).join(''))); }
  catch { return JSON.parse(bin); }
}
export function readClaims(token) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) throw new Error('Malformed token');
  const p = decodePart(parts[1]);
  if (!p || typeof p.exp !== 'number' || !ROLE_SET.has(p.role) || !Number.isFinite(Number(p.sub))) throw new Error('Unexpected token claims');
  return p;
}
const EXPIRY_SKEW_MS = 5000; // treat a token as expired slightly early so a request never races the deadline
const isExpired = exp => exp * 1000 - EXPIRY_SKEW_MS <= Date.now();

const listeners = { unauthorized: [] };
export const onUnauthorized = fn => listeners.unauthorized.push(fn);
function endSession(reason) { clearSession(); listeners.unauthorized.forEach(f => f(reason)); }

function armExpiry() {
  clearTimeout(expiryTimer);
  if (!session) return;
  const ms = session.exp * 1000 - EXPIRY_SKEW_MS - Date.now();
  // setTimeout cannot exceed ~24.8 days; tokens last 5 hours, but clamp anyway.
  expiryTimer = setTimeout(() => endSession('expired'), Math.max(0, Math.min(ms, 2 ** 31 - 1)));
}
// Timers are throttled in background tabs and stop while a laptop sleeps, so also re-check when the tab returns.
document.addEventListener('visibilitychange', () => { if (!document.hidden && session && isExpired(session.exp)) endSession('expired'); });

function buildSession(token) {
  const c = readClaims(token);
  // The user shown in the UI comes from the token's own claims, not from separately stored text.
  return { token, exp: c.exp, user: { id: Number(c.sub), name: String(c.name || ''), role: c.role } };
}

let expiredOnLoad = false;
export const consumeExpiredOnLoad = () => { const v = expiredOnLoad; expiredOnLoad = false; return v; };

export function loadSession() {
  try {
    const raw = sessionStorage.getItem(KEY);
    if (!raw) return null;
    const next = buildSession(JSON.parse(raw).token);
    if (isExpired(next.exp)) { clearSession(); expiredOnLoad = true; return null; }
    session = next;
    armExpiry();
  } catch { clearSession(); }
  return session;
}
export const getSession = () => session;
export const getUser = () => session && session.user;
export const sessionExpiresAt = () => session ? new Date(session.exp * 1000) : null;
export function clearSession() {
  session = null; clearTimeout(expiryTimer);
  try { sessionStorage.removeItem(KEY); } catch { /* ignore */ }
}

/* ---------- errors ---------- */
// kind: network | timeout | badresponse | validation | expired | unauthorized | forbidden | notfound | conflict | server | request
export class ApiError extends Error {
  constructor(message, status, body, kind = 'request') { super(message); this.name = 'ApiError'; this.status = status; this.body = body; this.kind = kind; }
}
const kindOf = s => s === 401 ? 'unauthorized' : s === 403 ? 'forbidden' : s === 404 ? 'notfound' : s === 409 ? 'conflict' : s >= 500 ? 'server' : 'request';

/* ---------- request log (client-side only; the authoritative log is api_access.log on the server) ---------- */
const recent = [];
export const getRequestLog = () => recent.slice();
function note(method, path, status, ms) { recent.push({ at: new Date().toISOString(), method, path, status, ms }); if (recent.length > 30) recent.shift(); }

/* ---------- one place that builds headers, sends, and interprets every response ---------- */
function headersFor({ body, auth }) {
  const h = { Accept: 'application/json' };
  if (body !== undefined) h['Content-Type'] = 'application/json'; // jsonHeaders()/readJson() on the server expect JSON
  if (auth) h.Authorization = 'Bearer ' + session.token;          // authenticateToken() reads exactly this header
  return h;
}

async function request(path, { method = 'GET', body, auth = false, query } = {}) {
  if (body !== undefined && (body === null || typeof body !== 'object' || Array.isArray(body))) {
    throw new ApiError('The request could not be sent because its data was not valid.', 0, null, 'validation'); // readJson() would answer 400
  }
  if (auth) {
    if (!session) throw new ApiError('Please sign in to continue.', 401, null, 'unauthorized');
    if (isExpired(session.exp)) { endSession('expired'); throw new ApiError('Your session has expired. Please sign in again.', 401, null, 'expired'); }
  }
  const url = new URL(API_BASE + path, location.origin);
  if (query) Object.entries(query).forEach(([k, v]) => {
    if (v == null) return;
    if (k === 'id' && !isId(v)) throw new ApiError('That record could not be found.', 0, null, 'validation'); // validId() would ignore it
    url.searchParams.set(k, v);
  });

  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), REQUEST_TIMEOUT_MS);
  const t0 = performance.now();
  let res;
  try {
    res = await fetch(url, { method, headers: headersFor({ body, auth }), body: body !== undefined ? JSON.stringify(body) : undefined, signal: ctl.signal });
  } catch (e) {
    note(method, path, 0, Math.round(performance.now() - t0));
    if (e && e.name === 'AbortError') throw new ApiError('The server took too long to respond. Please try again.', 0, null, 'timeout');
    throw new ApiError('Cannot reach the SportSphere server. Check that Apache and MySQL are running in XAMPP.', 0, null, 'network');
  } finally { clearTimeout(timer); }
  note(method, path, res.status, Math.round(performance.now() - t0));

  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { /* non-JSON, e.g. a PHP warning printed before the JSON */ }

  if (!res.ok) {
    const serverMsg = data && typeof data.error === 'string' ? data.error : '';
    if (res.status === 401 && auth) { // token missing, malformed or expired according to authenticateToken()
      endSession('rejected');
      throw new ApiError('Your session has expired. Please sign in again.', 401, data, 'expired');
    }
    if (res.status === 403) throw new ApiError('Your role does not have permission to do that.', 403, data, 'forbidden'); // authorizeRoles()
    const msg = serverMsg || (data === null ? 'The server returned an unexpected response.' : `Request failed (${res.status}).`);
    throw new ApiError(msg, res.status, data, data === null ? 'badresponse' : kindOf(res.status));
  }
  if (data === null) throw new ApiError('The server returned an unexpected (non-JSON) response.', res.status, null, 'badresponse');
  return data;
}

// Wrap a validator so bad input becomes an ApiError before anything is sent.
const checked = (rule, body, opts) => {
  try { rule(body, opts); }
  catch (e) { if (e instanceof ValidationError) throw Object.assign(new ApiError(e.message, 0, null, 'validation'), { field: e.field }); throw e; }
};

export async function login(email, password) {
  const body = { email: String(email).trim(), password };
  checked(rules.login, body);
  // auth.php compares the password and signs the token; a 401 here means wrong credentials, not an expired session.
  const d = await request('auth.php', { method: 'POST', body });
  if (!d || typeof d.token !== 'string') throw new ApiError('The server did not return a sign-in token.', 200, d, 'badresponse');
  let next;
  try { next = buildSession(d.token); } catch { throw new ApiError('The server returned a sign-in token this app cannot read.', 200, null, 'badresponse'); }
  if (isExpired(next.exp)) throw new ApiError('The server returned a token that has already expired. Check the server clock.', 200, null, 'badresponse');
  session = next;
  armExpiry();
  try { sessionStorage.setItem(KEY, JSON.stringify({ token: d.token })); } catch { /* storage unavailable: session lasts until reload */ }
  return session.user;
}

export const api = {
  venues: () => request('venues.php').then(d => d.data),
  venue: id => request('venues.php', { query: { id } }).then(d => d.data),
  createVenue: b => { checked(rules.venue, b); return request('venues.php', { method: 'POST', body: b, auth: true }); },
  updateVenue: (id, b) => { checked(rules.venue, b, { creating: false }); return request('venues.php', { method: 'PUT', body: b, auth: true, query: { id } }); },
  deleteVenue: id => request('venues.php', { method: 'DELETE', auth: true, query: { id } }),

  events: () => request('events.php').then(d => d.data),
  event: id => request('events.php', { query: { id } }).then(d => d.data),
  createEvent: b => { checked(rules.event, b); return request('events.php', { method: 'POST', body: b, auth: true }); },
  updateEvent: (id, b) => { checked(rules.event, b, { creating: false }); return request('events.php', { method: 'PUT', body: b, auth: true, query: { id } }); },
  deleteEvent: id => request('events.php', { method: 'DELETE', auth: true, query: { id } }),

  // bookings.php GET is unauthenticated and returns every booking; callers must filter.
  bookings: () => request('bookings.php').then(d => d.data),
  createBooking: b => { checked(rules.booking, b); return request('bookings.php', { method: 'POST', body: b, auth: true }); },
  // Confirming makes the server call generateQRCode() and return/store qr_code_url.
  setBookingStatus: (id, status) => { checked(rules.bookingStatus, { status }); return request('bookings.php', { method: 'PUT', body: { status }, auth: true, query: { id } }); },
  deleteBooking: id => request('bookings.php', { method: 'DELETE', auth: true, query: { id } }),

  payments: () => request('payments.php', { auth: true }).then(d => d.data),
  createPayment: b => { checked(rules.payment, b); return request('payments.php', { method: 'POST', body: b, auth: true }); },

  users: () => request('users.php', { query: { page: 1, limit: 500 } }).then(d => d.data),
  register: b => { checked(rules.register, b); return request('users.php', { method: 'POST', body: b }); },
  updateUser: (id, b) => { checked(rules.userUpdate, b); return request('users.php', { method: 'PUT', body: b, auth: true, query: { id } }); },
  deleteUser: id => request('users.php', { method: 'DELETE', auth: true, query: { id } }),
};
