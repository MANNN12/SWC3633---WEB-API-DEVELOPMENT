import { icon } from '../core/icons.js';
import { esc, rm, num, fmtDate, isUpcoming, todayISO, parseDate, badge, pageHead, statCard, mountTable, errorState, skelRows, openModal, closeModal, confirmDialog, toast, withBusy, $ } from '../core/ui.js';
import { api } from '../core/api.js';
import { bookingTitle, qtyLabel, openBookingDetail, openTicket } from './bookings.js';
import { bookingThumb, venueThumb, photosFor, mediaCell } from '../core/venues.js';

const isOn = v => Number(v) === 1;
const remaining = e => Math.max(0, Number(e.total_tickets) - Number(e.tickets_sold || 0));
const err = (root, id, msg) => { const n = $(`[data-err="${id}"]`, root); if (n) n.textContent = msg || ''; };
const clearErrs = root => root.querySelectorAll('[data-err]').forEach(n => (n.textContent = ''));
const fld = (id, label, inner, hint = '') => `<div class="field"><label for="${id}">${label}</label>${inner}${hint ? `<div class="field-hint">${hint}</div>` : ''}<div class="field-error" data-err="${id}"></div></div>`;

async function loadOrError(ctx, title, fn) {
  try { return await fn(); } catch (e) { if (ctx.alive()) ctx.el.innerHTML = pageHead(title) + `<div class="card">${errorState(e.message)}</div>`; return null; }
}

/* ================= BOOKINGS (staff, admin) ================= */
export async function manageBookings(ctx) {
  const { el, user } = ctx;
  const admin = user.role === 'admin';
  let byId = {};
  const load = async () => {
    el.innerHTML = pageHead('Bookings', 'Review, confirm and cancel customer bookings.') + `<div class="card">${skelRows(6)}</div>`;
    const rows = await loadOrError(ctx, 'Bookings', () => api.bookings());
    if (!rows || !ctx.alive()) return;
    byId = Object.fromEntries(rows.map(b => [b.id, b]));
    const pend = rows.filter(b => b.status === 'pending').length;
    el.innerHTML = pageHead('Bookings', 'Review, confirm and cancel customer bookings.') +
      `<div class="grid grid-stats">${statCard('All bookings', num(rows.length), 'ticket')}${statCard('Pending', num(pend), 'clock', 'amber')}${statCard('Confirmed', num(rows.filter(b => b.status === 'confirmed').length), 'checkc', 'green')}${statCard('Cancelled', num(rows.filter(b => b.status === 'cancelled').length), 'x', 'red')}</div><div class="card" id="tbl"></div>`;
    mountTable($('#tbl', el), {
      rows, pageSize: 10, searchPlaceholder: 'Search by customer, item or ID…', emptyTitle: 'No bookings', emptyText: 'Customer bookings will appear here.',
      searchText: b => `${b.id} ${b.customer_name} ${bookingTitle(b)} ${b.status} ${b.booking_type}`,
      filters: [{ label: 'Status', options: ['pending', 'confirmed', 'cancelled'], get: b => b.status }, { label: 'Type', options: ['venue', 'event'], get: b => b.booking_type }],
      columns: [
        { label: 'ID', sort: b => Number(b.id), render: b => '#' + b.id },
        { label: 'Customer', sort: b => b.customer_name || '', render: b => `<div class="cell-main">${esc(b.customer_name || '—')}</div>` },
        { label: 'Item', sort: b => bookingTitle(b), render: b => mediaCell(bookingThumb(b), esc(bookingTitle(b)), `${esc(b.booking_type)} · ${esc(qtyLabel(b))}`) },
        { label: 'Date', sort: b => b.booking_date, render: b => fmtDate(b.booking_date) },
        { label: 'Total', cls: 'num', sort: b => Number(b.total_price), render: b => rm(b.total_price) },
        { label: 'Status', sort: b => b.status, render: b => badge(b.status) },
        { label: '', cls: 'num', render: b => `<div class="row-actions"><button class="btn btn-ghost btn-sm" data-view="${b.id}">Details</button>${b.status !== 'confirmed' ? `<button class="btn btn-success btn-sm" data-st="confirmed" data-id="${b.id}">Confirm</button>` : ''}${b.status !== 'cancelled' ? `<button class="btn btn-danger btn-sm" data-st="cancelled" data-id="${b.id}">Cancel</button>` : ''}${b.status === 'cancelled' ? `<button class="btn btn-ghost btn-sm" data-st="pending" data-id="${b.id}">Reopen</button>` : ''}${admin ? `<button class="icon-btn" style="width:30px;height:30px" data-del="${b.id}" aria-label="Delete booking ${b.id}">${icon('trash', 'i-sm')}</button>` : ''}</div>` },
      ],
    });
  };
  el.addEventListener('click', async e => {
    const v = e.target.closest('[data-view]'), s = e.target.closest('[data-st]'), d = e.target.closest('[data-del]');
    if (v) return openBookingDetail(byId[v.dataset.view], { user });
    if (s) {
      const id = s.dataset.id, st = s.dataset.st;
      if (st === 'cancelled' && !(await confirmDialog({ title: 'Cancel booking?', message: `Booking #${id} will be marked cancelled and its QR ticket removed.`, confirmLabel: 'Cancel booking', danger: true }))) return;
      await withBusy(s, async () => { try { const r = await api.setBookingStatus(id, st); toast(`Booking #${id} marked ${st}`, 'success'); const b = byId[id]; await load(); if (st === 'confirmed' && r.qr_code_url && b) openTicket(b, r.qr_code_url); } catch (x) { toast(x.message, 'error'); } });
    }
    if (d) {
      if (!(await confirmDialog({ title: 'Delete booking?', message: `Booking #${d.dataset.del} and its payment records will be permanently deleted.`, confirmLabel: 'Delete', danger: true }))) return;
      await withBusy(d, async () => { try { await api.deleteBooking(d.dataset.del); toast('Booking deleted', 'success'); await load(); } catch (x) { toast(x.message, 'error'); } });
    }
  });
  await load();
}

/* ================= VENUES (staff, admin) ================= */
function venueModal(v, cats, onSaved) {
  const edit = !!v;
  const body = `<form id="vf" novalidate>
    ${fld('vn', 'Venue name', `<input class="input" id="vn" value="${esc(v ? v.venue_name : '')}" maxlength="120" required>`)}
    <div id="vphoto" aria-live="polite"></div>
    ${edit ? fld('vc', 'Category', `<input class="input" id="vc" value="${esc(v.category)}" disabled>`, 'Category cannot be changed after creation.') : fld('vc', 'Category', `<input class="input" id="vc" list="cats" maxlength="50" placeholder="e.g. Futsal" required><datalist id="cats">${cats.map(c => `<option value="${esc(c)}">`).join('')}</datalist>`)}
    <div class="form-grid">${fld('vr', 'Hourly rate (RM)', `<input class="input" id="vr" type="number" min="0" step="0.01" value="${v ? esc(v.hourly_rate) : ''}" required>`)}
    ${edit ? fld('va', 'Availability', `<select class="select" id="va"><option value="1" ${isOn(v.is_available) ? 'selected' : ''}>Available</option><option value="0" ${!isOn(v.is_available) ? 'selected' : ''}>Unavailable</option></select>`) : ''}</div></form>`;
  const root = openModal({ title: edit ? 'Edit venue' : 'Add venue', body, footer: `<button class="btn btn-ghost" data-close>Cancel</button><button class="btn" id="vs">${edit ? 'Save changes' : 'Create venue'}</button>` });
  // Photos are matched to venues by name (core/venues.js); show which one this name gets.
  const showPhoto = () => {
    const name = $('#vn', root).value.trim(), n = photosFor(name).length;
    $('#vphoto', root).innerHTML = `<div class="photo-row">${venueThumb({ venue_name: name, category: v ? v.category : '' })}<p>${n ? `${n > 1 ? n + ' photos are' : 'A photo is'} matched to this name. Renaming the venue changes which photo it shows.` : 'No photo is matched to this name, so the court illustration is shown. Photos are matched by venue name.'}</p></div>`;
  };
  showPhoto();
  $('#vn', root).addEventListener('input', showPhoto);
  $('#vs', root).onclick = ev => {
    clearErrs(root);
    const name = $('#vn', root).value.trim(), cat = $('#vc', root).value.trim(), rate = parseFloat($('#vr', root).value);
    let ok = true;
    if (!name) { err(root, 'vn', 'Enter a venue name.'); ok = false; }
    if (!edit && !cat) { err(root, 'vc', 'Enter a category.'); ok = false; }
    if (!(rate >= 0)) { err(root, 'vr', 'Enter a valid rate.'); ok = false; }
    if (!ok) return;
    return withBusy(ev.currentTarget, async () => {
      try {
        if (edit) await api.updateVenue(v.id, { venue_name: name, hourly_rate: rate, is_available: Number($('#va', root).value) });
        else await api.createVenue({ venue_name: name, category: cat, hourly_rate: rate });
        closeModal(); toast(edit ? 'Venue updated' : 'Venue created', 'success'); onSaved();
      } catch (x) { toast(x.message, 'error'); }
    });
  };
}

export async function manageVenues(ctx) {
  const { el, user } = ctx;
  const admin = user.role === 'admin';
  let byId = {}, cats = [];
  const load = async () => {
    el.innerHTML = pageHead('Venues', 'Create and maintain bookable venues.') + `<div class="card">${skelRows(5)}</div>`;
    const rows = await loadOrError(ctx, 'Venues', () => api.venues());
    if (!rows || !ctx.alive()) return;
    byId = Object.fromEntries(rows.map(v => [v.id, v])); cats = [...new Set(rows.map(v => v.category))];
    el.innerHTML = pageHead('Venues', 'Create and maintain bookable venues.', `<button class="btn" id="add">${icon('plus', 'i-sm')} Add venue</button>`) +
      `<div class="grid grid-stats">${statCard('Venues', num(rows.length), 'court')}${statCard('Available', num(rows.filter(v => isOn(v.is_available)).length), 'checkc', 'green')}${statCard('Unavailable', num(rows.filter(v => !isOn(v.is_available)).length), 'alert', 'red')}${statCard('Categories', num(cats.length), 'tag')}</div><div class="card" id="tbl"></div>`;
    mountTable($('#tbl', el), {
      rows, pageSize: 10, searchPlaceholder: 'Search venues…', searchText: v => `${v.venue_name} ${v.category}`, emptyTitle: 'No venues', emptyText: 'Add the first venue to start taking bookings.',
      filters: [{ label: 'Category', options: cats, get: v => v.category }, { label: 'Availability', options: ['available', 'unavailable'], get: v => isOn(v.is_available) ? 'available' : 'unavailable' }],
      columns: [
        { label: 'Venue', sort: v => v.venue_name, render: v => mediaCell(venueThumb(v), esc(v.venue_name), `#${v.id}`) },
        { label: 'Category', sort: v => v.category, render: v => esc(v.category) },
        { label: 'Hourly rate', cls: 'num', sort: v => Number(v.hourly_rate), render: v => rm(v.hourly_rate) },
        { label: 'Status', sort: v => v.is_available, render: v => badge(isOn(v.is_available) ? 'Available' : 'Unavailable', isOn(v.is_available) ? 'available' : 'unavailable') },
        { label: '', cls: 'num', render: v => `<div class="row-actions"><button class="btn btn-ghost btn-sm" data-edit="${v.id}">${icon('edit', 'i-sm')} Edit</button>${admin ? `<button class="icon-btn" style="width:30px;height:30px" data-del="${v.id}" aria-label="Delete ${esc(v.venue_name)}">${icon('trash', 'i-sm')}</button>` : ''}</div>` },
      ],
    });
  };
  el.addEventListener('click', async e => {
    if (e.target.closest('#add')) return venueModal(null, cats, load);
    const ed = e.target.closest('[data-edit]'), d = e.target.closest('[data-del]');
    if (ed) venueModal(byId[ed.dataset.edit], cats, load);
    if (d) {
      const v = byId[d.dataset.del];
      if (!(await confirmDialog({ title: 'Delete venue?', message: `"${v.venue_name}" will be removed. Existing bookings keep their record but lose the venue link.`, confirmLabel: 'Delete venue', danger: true }))) return;
      await withBusy(d, async () => { try { await api.deleteVenue(v.id); toast('Venue deleted', 'success'); await load(); } catch (x) { toast(x.message, 'error'); } });
    }
  });
  await load();
}

/* ================= EVENTS (organiser, admin) ================= */
function eventModal(ev, user, organisers, onSaved) {
  const edit = !!ev, admin = user.role === 'admin';
  const body = `<form id="ef" novalidate>
    ${edit ? `<div class="notice">${icon('info')}<div>The server only allows the name and ticket price to be edited. Date and ticket capacity are fixed once published.</div></div>` : ''}
    ${fld('en', 'Event name', `<input class="input" id="en" maxlength="150" value="${esc(ev ? ev.event_name : '')}" required>`)}
    <div class="form-grid">
    ${fld('ep', 'Ticket price (RM)', `<input class="input" id="ep" type="number" min="0" step="0.01" value="${ev ? esc(ev.ticket_price) : ''}" required>`, '0 for a free event.')}
    ${edit ? fld('ed', 'Event date', `<input class="input" id="ed" value="${esc(fmtDate(ev.event_date))}" disabled>`) : fld('ed', 'Event date', `<input class="input" id="ed" type="date" min="${todayISO()}" required>`)}
    ${edit ? fld('et', 'Total tickets', `<input class="input" id="et" value="${esc(ev.total_tickets)}" disabled>`) : fld('et', 'Total tickets', `<input class="input" id="et" type="number" min="1" step="1" required>`)}
    ${!edit && admin ? fld('eo', 'Organiser', `<select class="select" id="eo">${organisers.map(o => `<option value="${o.id}">${esc(o.name)} (${esc(o.role)})</option>`).join('')}</select>`) : ''}</div></form>`;
  const root = openModal({ title: edit ? 'Edit event' : 'Create event', body, footer: `<button class="btn btn-ghost" data-close>Cancel</button><button class="btn" id="es">${edit ? 'Save changes' : 'Publish event'}</button>` });
  $('#es', root).onclick = btn => {
    clearErrs(root);
    const name = $('#en', root).value.trim(), price = parseFloat($('#ep', root).value);
    let ok = true;
    if (!name) { err(root, 'en', 'Enter an event name.'); ok = false; }
    if (!(price >= 0)) { err(root, 'ep', 'Enter a valid price.'); ok = false; }
    let date, tickets;
    if (!edit) {
      date = $('#ed', root).value; tickets = parseInt($('#et', root).value, 10);
      if (!date || parseDate(date) < parseDate(todayISO())) { err(root, 'ed', 'Choose today or a future date.'); ok = false; }
      if (!(tickets >= 1)) { err(root, 'et', 'Enter at least 1 ticket.'); ok = false; }
    }
    if (!ok) return;
    return withBusy(btn.currentTarget, async () => {
      try {
        if (edit) await api.updateEvent(ev.id, { event_name: name, ticket_price: price });
        else await api.createEvent({ event_name: name, organiser_id: admin ? Number($('#eo', root).value) : Number(user.id), event_date: date, ticket_price: price, total_tickets: tickets });
        closeModal(); toast(edit ? 'Event updated' : 'Event published', 'success'); onSaved();
      } catch (x) { toast(x.message, 'error'); }
    });
  };
}

export async function manageEvents(ctx) {
  const { el, user } = ctx;
  const admin = user.role === 'admin';
  let byId = {}, organisers = [];
  const title = admin ? 'Events' : 'My events';
  const load = async () => {
    el.innerHTML = pageHead(title, 'Publish and maintain events.') + `<div class="card">${skelRows(5)}</div>`;
    const data = await loadOrError(ctx, title, async () => { const [e, u] = await Promise.all([api.events(), admin ? api.users() : Promise.resolve([])]); return { e, u }; });
    if (!data || !ctx.alive()) return;
    organisers = data.u.filter(u => u.role === 'organiser' || u.role === 'admin');
    const names = Object.fromEntries(data.u.map(u => [u.id, u.name]));
    // The backend does not enforce ownership, so organisers are limited to their own events here in the UI only.
    const rows = admin ? data.e : data.e.filter(e => Number(e.organiser_id) === Number(user.id));
    byId = Object.fromEntries(rows.map(e => [e.id, e]));
    el.innerHTML = pageHead(title, admin ? 'Every event across all organisers.' : 'Events you have published.', `<button class="btn" id="add">${icon('plus', 'i-sm')} Create event</button>`) +
      `<div class="grid grid-stats">${statCard('Events', num(rows.length), 'calendar')}${statCard('Upcoming', num(rows.filter(e => isUpcoming(e.event_date)).length), 'clock', 'green')}${statCard('Tickets booked', num(rows.reduce((a, e) => a + Number(e.tickets_sold), 0)), 'ticket')}${statCard('Capacity', num(rows.reduce((a, e) => a + Number(e.total_tickets), 0)), 'users')}</div><div class="card" id="tbl"></div>`;
    mountTable($('#tbl', el), {
      rows, pageSize: 10, searchPlaceholder: 'Search events…', searchText: e => e.event_name, emptyTitle: 'No events yet', emptyText: 'Create an event to start selling tickets.',
      filters: [{ label: 'When', options: ['upcoming', 'past'], get: e => isUpcoming(e.event_date) ? 'upcoming' : 'past' }],
      columns: [
        { label: 'Event', sort: e => e.event_name, render: e => `<div class="cell-main">${esc(e.event_name)}</div><div class="cell-sub">#${e.id}${admin ? ' · ' + esc(names[e.organiser_id] || 'Organiser #' + e.organiser_id) : ''}</div>` },
        { label: 'Date', sort: e => e.event_date, render: e => fmtDate(e.event_date) },
        { label: 'Price', cls: 'num', sort: e => Number(e.ticket_price), render: e => Number(e.ticket_price) === 0 ? 'Free' : rm(e.ticket_price) },
        { label: 'Tickets', sort: e => Number(e.tickets_sold), render: e => `<div>${num(e.tickets_sold)} / ${num(e.total_tickets)}</div><div class="progress" style="width:110px;margin-top:6px"><i style="width:${Math.min(100, (e.tickets_sold / e.total_tickets) * 100)}%"></i></div>` },
        { label: 'Status', render: e => badge(isUpcoming(e.event_date) ? (remaining(e) ? 'Open' : 'Sold out') : 'Past', isUpcoming(e.event_date) ? (remaining(e) ? 'open' : 'sold out') : 'past') },
        { label: '', cls: 'num', render: e => `<div class="row-actions"><button class="btn btn-ghost btn-sm" data-edit="${e.id}">${icon('edit', 'i-sm')} Edit</button><button class="icon-btn" style="width:30px;height:30px" data-del="${e.id}" aria-label="Delete ${esc(e.event_name)}">${icon('trash', 'i-sm')}</button></div>` },
      ],
    });
  };
  el.addEventListener('click', async e => {
    if (e.target.closest('#add')) return eventModal(null, user, organisers, load);
    const ed = e.target.closest('[data-edit]'), d = e.target.closest('[data-del]');
    if (ed) eventModal(byId[ed.dataset.edit], user, organisers, load);
    if (d) {
      const ev = byId[d.dataset.del];
      if (!(await confirmDialog({ title: 'Delete event?', message: `"${ev.event_name}" will be removed. Existing bookings keep their record but lose the event link.`, confirmLabel: 'Delete event', danger: true }))) return;
      await withBusy(d, async () => { try { await api.deleteEvent(ev.id); toast('Event deleted', 'success'); await load(); } catch (x) { toast(x.message, 'error'); } });
    }
  });
  await load();
}
