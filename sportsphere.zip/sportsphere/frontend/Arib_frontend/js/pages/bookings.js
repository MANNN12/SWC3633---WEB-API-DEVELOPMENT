import { icon } from '../core/icons.js';
import { esc, rm, fmtDate, badge, pageHead, mountTable, emptyState, errorState, skelRows, openModal, closeModal, toast, withBusy, $ } from '../core/ui.js';
import { api } from '../core/api.js';
import { qrInfo, qrTicket, mountQr } from '../core/qr.js';
import { bookingThumb, bookingBanner, mediaCell } from '../core/venues.js';

export const bookingTitle = b => b.booking_type === 'event'
  ? (b.event_name || (b.event_id ? `Event #${b.event_id}` : 'Removed event'))
  : (b.venue_name || (b.venue_id ? `Venue #${b.venue_id}` : 'Removed venue'));
export const qtyLabel = b => b.booking_type === 'event' ? `${b.quantity} ticket${b.quantity > 1 ? 's' : ''}` : `${b.quantity} hour${b.quantity > 1 ? 's' : ''}`;

// Only render QR images that come from the QR service the backend uses (checked in core/qr.js).
export const safeQr = u => { const i = qrInfo(u); return i ? i.src : null; };

/* Customers cannot read payments.php (admin/staff only), so the only payment evidence they have is the
   response of their own successful POST. Those responses are remembered in this browser, per user. */
const rKey = id => `ss_arib_receipts_${id}`;
export const getReceipts = uid => { try { return JSON.parse(localStorage.getItem(rKey(uid)) || '{}'); } catch { return {}; } };
const saveReceipt = (uid, bid, r) => { try { const all = getReceipts(uid); all[bid] = r; localStorage.setItem(rKey(uid), JSON.stringify(all)); } catch { /* storage unavailable */ } };

export function openPayModal(b, user, onDone) {
  const body = `${bookingBanner(b)}<div class="notice">${icon('info')}<div>SportSphere records the payment method you choose. No card details are collected here, and the server marks the payment as completed immediately — there is no external payment gateway.</div></div>
    <div class="sum-row"><span>${esc(bookingTitle(b))}</span><span>${esc(qtyLabel(b))}</span></div>
    <div class="sum-row total"><span>Amount</span><span>${rm(b.total_price)}</span></div>
    <fieldset style="border:0;padding:0;margin:18px 0 0"><legend class="legend-field">Payment method</legend>
      <div class="pm-opts"><label><input type="radio" name="pm" value="fpx" checked><span>FPX</span></label><label><input type="radio" name="pm" value="card"><span>Card</span></label><label><input type="radio" name="pm" value="e-wallet"><span>E-wallet</span></label></div></fieldset>
    <div class="field-error" id="pay-err" style="margin-top:12px"></div>`;
  const root = openModal({ title: `Pay for booking #${b.id}`, body, footer: '<button class="btn btn-ghost" data-close>Cancel</button><button class="btn btn-success" id="pay-go">Record payment</button>' });
  $('#pay-go', root).onclick = ev => withBusy(ev.currentTarget, async () => {
    const method = $('input[name=pm]:checked', root).value;
    try {
      const r = await api.createPayment({ booking_id: Number(b.id), payment_method: method, amount: Number(b.total_price) });
      saveReceipt(user.id, b.id, { ref: r.transaction_ref, method, amount: Number(b.total_price), at: new Date().toISOString() });
      closeModal();
      toast(`Payment recorded. Reference ${r.transaction_ref}`, 'success');
      onDone && onDone();
    } catch (err) { $('#pay-err', root).textContent = err.message; }
  });
}

export function openBookingDetail(b, { user, receipt, onPay } = {}) {
  const qr = qrInfo(b.qr_code_url);
  const rows = [
    ['Booking', '#' + b.id], ['Type', badge(b.booking_type)], [b.booking_type === 'event' ? 'Event' : 'Venue', esc(bookingTitle(b))],
    ['Date', fmtDate(b.booking_date)], [b.booking_type === 'event' ? 'Tickets' : 'Hours', esc(b.quantity)], ['Total', rm(b.total_price)],
    ['Status', badge(b.status)], ['Customer', esc(b.customer_name || '—')], ['Booked on', fmtDate(b.created_at)],
  ];
  if (receipt) rows.push(['Payment', `${badge('completed')} <span class="muted">${esc(receipt.ref)} · ${esc(receipt.method)}</span>`]);
  const canPay = user && user.role === 'customer' && Number(b.customer_id) === Number(user.id) && b.status !== 'cancelled' && !receipt;
  const body = `${bookingBanner(b)}<dl class="dl">${rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>
    ${qr ? `<div class="mt">${qrTicket(b.qr_code_url, { title: 'Entry QR code', note: 'Show this code on arrival. It was issued by the server when staff confirmed the booking.' })}</div>`
      : b.status === 'pending' ? `<div class="notice mt">${icon('clock')}<div>Awaiting confirmation by staff. A QR ticket is issued when the booking is confirmed.</div></div>` : ''}
    ${user && user.role === 'customer' && b.status !== 'cancelled' ? `<p class="field-hint mt">Customers cannot cancel online — the server only lets staff or admins change a booking's status. Please contact staff to cancel.</p>` : ''}`;
  const root = openModal({ title: 'Booking details', body, footer: `<button class="btn btn-ghost" data-close>Close</button>${canPay ? '<button class="btn btn-success" id="d-pay">Pay now</button>' : ''}` });
  mountQr(root);
  const p = $('#d-pay', root); if (p) p.onclick = () => { closeModal(); onPay && onPay(b); };
}

/* Ticket view used right after staff confirm a booking, and from the My bookings table. */
export function openTicket(b, qrUrl) {
  const url = qrUrl || b.qr_code_url;
  const root = openModal({
    title: 'Entry ticket',
    body: `${bookingBanner(b)}<dl class="dl" style="margin-bottom:18px"><dt>Booking</dt><dd>#${esc(b.id)} · ${esc(bookingTitle(b))}</dd><dt>Date</dt><dd>${fmtDate(b.booking_date)}</dd><dt>Total</dt><dd>${rm(b.total_price)}</dd></dl>${qrTicket(url, { title: 'Entry QR code', note: 'Show this code on arrival.' }) || `<div class="notice warn">${icon('alert')}<div>This booking has no QR ticket yet.</div></div>`}`,
    footer: '<button class="btn btn-ghost" data-close>Close</button>',
  });
  mountQr(root);
}

export async function myBookings(ctx) {
  const { el, user } = ctx;
  let byId = {};
  const load = async () => {
    el.innerHTML = pageHead('My bookings', 'Every venue rental and event ticket on your account.', '<a class="btn" href="#/venues">Book a venue</a>') + `<div class="card">${skelRows(5)}</div>`;
    let rows;
    try { rows = (await api.bookings()).filter(b => Number(b.customer_id) === Number(user.id)); }
    catch (err) { if (ctx.alive()) el.innerHTML = pageHead('My bookings') + `<div class="card">${errorState(err.message)}</div>`; return; }
    if (!ctx.alive()) return;
    const receipts = getReceipts(user.id);
    el.innerHTML = pageHead('My bookings', 'Every venue rental and event ticket on your account.', '<a class="btn" href="#/venues">Book a venue</a>') +
      `<div class="notice">${icon('info')}<div>Payment status is read from receipts saved in this browser — the server does not let customers view payment records.</div></div><div class="card" id="tbl"></div>`;
    byId = Object.fromEntries(rows.map(b => [b.id, b]));
    mountTable($('#tbl', el), {
      rows, pageSize: 8, searchPlaceholder: 'Search bookings…', emptyTitle: 'No bookings yet', emptyText: 'Reserve a venue or buy an event ticket and it will show up here.',
      searchText: b => `${bookingTitle(b)} ${b.status} ${b.booking_type} ${b.id}`,
      filters: [{ label: 'Status', options: ['pending', 'confirmed', 'cancelled'], get: b => b.status }, { label: 'Type', options: ['venue', 'event'], get: b => b.booking_type }],
      columns: [
        { label: 'Booking', sort: b => bookingTitle(b), render: b => mediaCell(bookingThumb(b), esc(bookingTitle(b)), `#${b.id} · ${esc(b.booking_type)} · ${esc(qtyLabel(b))}`) },
        { label: 'Date', sort: b => b.booking_date, render: b => fmtDate(b.booking_date) },
        { label: 'Total', cls: 'num', sort: b => Number(b.total_price), render: b => rm(b.total_price) },
        { label: 'Status', sort: b => b.status, render: b => badge(b.status) },
        { label: 'Payment', render: b => receipts[b.id] ? `${badge('completed')}<div class="cell-sub">${esc(receipts[b.id].ref)}</div>` : b.status === 'cancelled' ? '<span class="muted">—</span>' : `<button class="btn btn-success btn-sm" data-pay="${b.id}">Pay</button>` },
        { label: '', cls: 'num', render: b => `<div class="row-actions">${qrInfo(b.qr_code_url) ? `<button class="btn btn-soft btn-sm" data-ticket="${b.id}">${icon('qr', 'i-sm')} Ticket</button>` : ''}<button class="btn btn-ghost btn-sm" data-view="${b.id}">Details</button></div>` },
      ],
    });
  };
  el.addEventListener('click', e => { // bound once per view; `byId` is refreshed on every load
    const v = e.target.closest('[data-view]'), p = e.target.closest('[data-pay]'), t = e.target.closest('[data-ticket]');
    if (t) openTicket(byId[t.dataset.ticket]);
    if (v) { const b = byId[v.dataset.view]; openBookingDetail(b, { user, receipt: getReceipts(user.id)[b.id], onPay: bb => openPayModal(bb, user, load) }); }
    if (p) openPayModal(byId[p.dataset.pay], user, load);
  });
  await load();
}
