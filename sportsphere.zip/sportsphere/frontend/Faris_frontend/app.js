'use strict';

/* =====================================================================
   SportSphere, Faris frontend
   Talks to the PHP API in the parent folder (auth, venues, events, bookings, payments, users).
   Change API_BASE below, or open the page with ?api=http://host/path to override it.
   ===================================================================== */

const API_BASE = (new URLSearchParams(location.search).get('api') || 'http://localhost/sportsphere').replace(/\/+$/, '');

// Quick-fill buttons on the sign-in page. Set to false before showing this to real users.
const SHOW_DEMO_LOGINS = true;
const DEMO_LOGINS = [
  ['Customer', 'johndoe@gmail.com', 'cust123'],
  ['Organiser', 'futsal@uptm.edu.my', 'org123'],
  ['Staff', 'finance@sportsphere.com', 'staff123'],
  ['Admin', 'admin@sportsphere.com', 'admin123'],
];

/* ---------- small helpers ---------- */

const $ = (sel, root = document) => root.querySelector(sel);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = v => Number(v) || 0;
const cap = s => (s || '').charAt(0).toUpperCase() + (s || '').slice(1);
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// Functions that return markup end in H. Everything else returns plain text, so escape it with esc() in templates.
const money = (n, { free = false, whole = false } = {}) => (free && num(n) === 0) ? 'Free'
  : 'RM ' + num(n).toLocaleString('en-MY', { minimumFractionDigits: whole ? 0 : 2, maximumFractionDigits: whole ? 0 : 2 });
const parseDate = s => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || ''); return m ? { y: +m[1], m: +m[2], d: +m[3] } : null; };
const fmtDate = s => { const p = parseDate(s); return p ? `${p.d} ${MONTHS[p.m - 1]} ${p.y}` : (s || ''); };
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const plural = (n, one, many = one + 's') => `${n} ${n === 1 ? one : many}`;

const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* storage can be blocked */ } },
  del(k) { try { localStorage.removeItem(k); } catch { /* ignore */ } },
};

const state = {
  cache: { venues: [], events: [], bookings: [], payments: [], users: [] },
  courtCat: 'All',
  bk: { status: 'all', q: '' },
  booking: null,
};

/* ---------- session ---------- */

let session = null; // { token, user: { id, name, role } }

function tokenExpiry(token) {
  try {
    const p = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(atob(p)).exp * 1000;
  } catch { return 0; }
}

function loadSession() {
  try {
    const s = JSON.parse(store.get('ss_session') || 'null');
    if (s && s.token && tokenExpiry(s.token) > Date.now()) session = s;
    else store.del('ss_session');
  } catch { store.del('ss_session'); }
}

function saveSession(token, user) {
  session = { token, user: { id: Number(user.id), name: user.name, role: user.role } };
  store.set('ss_session', JSON.stringify(session));
}

function logout(expired = false) {
  session = null;
  store.del('ss_session');
  toast(expired ? 'Your session expired. Sign in again to continue.' : 'You are signed out.', expired ? 'err' : 'ok');
  if (location.hash === (expired ? '#/login' : '#/courts')) route();
  else location.hash = expired ? '#/login' : '#/courts';
}

/* ---------- API ---------- */

async function api(path, { method = 'GET', body } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (session) headers['Authorization'] = `Bearer ${session.token}`;

  let res;
  try {
    res = await fetch(`${API_BASE}/${path}`, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  } catch {
    return { ok: false, status: 0, data: null, error: `Can't get an answer from ${API_BASE}. Check the requested API endpoint in a new tab to see why: Apache may be off, the folder may be in the wrong place, or the database name may not match db.php (it expects sportsphere_db).` };
  }
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch { /* not JSON */ }

  if (res.status === 401 && session) { logout(true); }
  if (res.ok && data === null) return { ok: false, status: res.status, data: null, error: 'The server sent a response this page could not read.' };
  return { ok: res.ok, status: res.status, data, error: res.ok ? null : ((data && data.error) || `Request failed (${res.status}).`) };
}

/* ---------- toast, dialog ---------- */

function toast(msg, kind = 'ok') {
  const t = document.createElement('div');
  t.className = 'toast ' + kind;
  t.textContent = msg;
  const box = $('#toasts');
  box.append(t);
  while (box.children.length > 3) box.firstChild.remove();
  setTimeout(() => t.remove(), 5000);
}

const dlg = $('#dlg');
function openDlg(html, mount) {
  $('#dlgBody').innerHTML = html;
  if (!dlg.open) dlg.showModal();
  if (mount) mount($('#dlgBody'));
}
function closeDlg() { if (dlg.open) dlg.close(); }
dlg.addEventListener('click', e => { if (e.target === dlg) closeDlg(); });

function confirmDlg({ title, body, ok = 'Confirm', keep = 'Keep it', danger = false }) {
  return new Promise(resolve => {
    openDlg(`
      <div class="dlg-form">
        <h2>${esc(title)}</h2>
        <p>${esc(body)}</p>
        <div class="dlg-actions">
          <button type="button" class="btn" data-r="no">${esc(keep)}</button>
          <button type="button" class="btn ${danger ? 'danger' : 'primary'}" data-r="yes">${esc(ok)}</button>
        </div>
      </div>`, root => {
      let done = false;
      const finish = v => { if (done) return; done = true; resolve(v); closeDlg(); };
      $('[data-r=yes]', root).onclick = () => finish(true);
      $('[data-r=no]', root).onclick = () => finish(false);
      dlg.addEventListener('close', () => finish(false), { once: true });
    });
  });
}

/* ---------- pictograms ---------- */

const FLOORS = { futsal: '#2F7D5B', badminton: '#1E4E9C', pickleball: '#2A7F95', tennis: '#3A6EA5', basketball: '#B4703A' };
const sportKey = c => Object.keys(FLOORS).find(k => (c || '').toLowerCase().includes(k)) || 'other';

function courtIconH(category) {
  const k = sportKey(category);
  const frame = '<rect x="4" y="4" width="64" height="46"/>';
  const parts = {
    futsal: '<path d="M36 4V50"/><circle cx="36" cy="27" r="7"/><path d="M4 17A10 10 0 0 1 4 37"/><path d="M68 17A10 10 0 0 0 68 37"/>',
    badminton: '<path d="M36 4V50M26 4V50M46 4V50M4 27H26M46 27H68M4 10H68M4 44H68"/>',
    pickleball: '<path d="M36 4V50M26 4V50M46 4V50M4 27H26M46 27H68"/>',
    tennis: '<path d="M36 4V50M20 10V44M52 10V44M20 27H52M4 10H68M4 44H68"/>',
    basketball: '<path d="M36 4V50"/><circle cx="36" cy="27" r="7"/><path d="M4 19H22V35H4M68 19H50V35H68"/>',
    other: '<path d="M36 4V50"/><circle cx="36" cy="27" r="7"/>',
  }[k];
  return `<svg class="court-ic" viewBox="0 0 72 54" aria-hidden="true" focusable="false"><rect width="72" height="54" rx="4" fill="${FLOORS[k] || '#1E4E9C'}"/><g fill="none" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${frame}${parts}</g></svg>`;
}

// A multi-purpose hall floor: futsal lines in white laid over badminton lines in yellow, the way real halls are marked.
function hallH() {
  return `<svg class="hall" viewBox="0 0 600 400" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">
    <g class="futsal">
      <rect x="20" y="20" width="560" height="360"/>
      <path d="M300 20V380"/><circle cx="300" cy="200" r="50"/>
      <path d="M20 135A65 65 0 0 1 20 265"/><path d="M580 135A65 65 0 0 0 580 265"/>
      <rect x="6" y="178" width="14" height="44"/><rect x="580" y="178" width="14" height="44"/>
      <circle class="dot" cx="135" cy="200" r="3"/><circle class="dot" cx="465" cy="200" r="3"/>
    </g>
    <g class="badminton">
      <rect x="135" y="125" width="330" height="150"/>
      <path d="M135 136H465M135 264H465M300 125V275M251 125V275M349 125V275M154 125V275M446 125V275M135 200H251M349 200H465"/>
    </g>
  </svg>`;
}

const logoMarkH = () => `<svg viewBox="0 0 34 26" aria-hidden="true" focusable="false"><g fill="none" stroke="currentColor" stroke-width="2"><rect x="1.5" y="1.5" width="31" height="23"/><path d="M17 1.5V24.5"/><circle cx="17" cy="13" r="5"/></g></svg>`;

/* ---------- shared markup ---------- */

const chipH = s => `<span class="chip ${esc(s)}">${esc(s)}</span>`;
const pageHead = (title, sub = '', actions = '') => `<div class="page-head"><div><h1>${esc(title)}</h1>${sub ? `<p>${esc(sub)}</p>` : ''}</div>${actions}</div>`;
const errorH = (msg) => `<div class="notice error" role="alert"><h3>That didn't load</h3><p>${esc(msg)}</p><button class="btn" data-act="reload">Try again</button></div>`;
const emptyH = (title, body, cta = '') => `<div class="notice"><h3>${esc(title)}</h3><p class="muted">${esc(body)}</p>${cta}</div>`;

const itemName = b => b.booking_type === 'event' ? (b.event_name || `Event #${b.event_id}`) : (b.venue_name || `Court #${b.venue_id}`);
const METHOD = { fpx: 'FPX', card: 'card', 'e-wallet': 'e-wallet' };

function paymentFor(bookingId) {
  const list = state.cache.payments.filter(p => num(p.booking_id) === num(bookingId));
  return list.sort((a, b) => num(b.id) - num(a.id))[0] || null;
}
function payChipH(p) {
  if (!p) return '<span class="pay none">No payment</span>';
  if (p.payment_status === 'completed') return `<span class="pay completed">Paid by ${esc(METHOD[p.payment_method] || p.payment_method)}</span>`;
  if (p.payment_status === 'failed') return '<span class="pay failed">Payment failed</span>';
  return '<span class="pay">Payment pending</span>';
}

/* ---------- navigation ---------- */

const NAV = {
  guest: [['courts', 'Courts'], ['events', 'Events']],
  customer: [['dashboard', 'Dashboard'], ['courts', 'Courts'], ['events', 'Events'], ['my-bookings', 'My bookings'], ['profile', 'My profile']],
  organiser: [['organiser-dashboard', 'Dashboard'], ['manage-events', 'My events'], ['sales', 'Ticket sales'], ['profile', 'My profile']],
  staff: [['staff-dashboard', 'Dashboard'], ['bookings', 'Bookings'], ['manage-courts', 'Courts'], ['payments', 'Payments'], ['profile', 'My profile']],
  admin: [['overview', 'Overview'], ['bookings', 'Bookings'], ['manage-courts', 'Courts'], ['manage-events', 'Events'], ['payments', 'Payments'], ['users', 'Users'], ['profile', 'My profile']],
};
const CUSTOMER_SYMBOLS = {dashboard:'◫',courts:'▦',events:'▣','my-bookings':'▤',profile:'◉'};
const ROLE_ICONS = { 'organiser-dashboard':'layout-dashboard','staff-dashboard':'layout-dashboard','manage-events':'calendar-days',sales:'chart-no-axes-column-increasing',bookings:'clipboard-list','manage-courts':'layout-grid',payments:'credit-card',overview:'chart-pie',users:'users',profile:'user-round' };
const ROLE_SYMBOLS = { 'organiser-dashboard':'◫','staff-dashboard':'◫', 'manage-events':'▣', sales:'▥', bookings:'☷', 'manage-courts':'▦', payments:'▤', overview:'◫', users:'♙',profile:'◉' };
const roleBannerH = (title,desc) => `<div class="role-hero"><div><span class="role-eyebrow">SPORTSPHERE · ${esc(cap(roleOf()))} WORKSPACE</span><h2>${esc(title)}</h2><p>${esc(desc)}</p></div><span class="role-hero-art" aria-hidden="true">◉</span></div>`;
const roleStatH = (label,value,note='') => `<div class="role-metric"><span>${esc(label)}</span><strong>${esc(value)}</strong>${note ? `<small>${esc(note)}</small>` : ''}</div>`;
const roleMetricsH = (...items) => `<div class="role-metrics">${items.join('')}</div>`;
const HOME = { guest: 'courts', customer: 'dashboard', organiser: 'organiser-dashboard', staff: 'staff-dashboard', admin: 'overview' };
const roleOf = () => session ? session.user.role : 'guest';

function renderShell(current) {
  document.body.dataset.workspace = roleOf();
  const role = roleOf();
  $('#top').innerHTML = `
    <a class="logo" href="#/${HOME[role]}">${logoMarkH()}SportSphere</a>
    ${session
      ? `<div class="who"><div class="who-name"><strong>${esc(session.user.name)}</strong><span>${esc(session.user.role)}</span></div><button class="btn light" data-act="logout">Sign out</button></div>`
      : `<div class="who"><a class="btn light" href="#/login">Sign in</a></div>`}`;
  $('#nav').innerHTML = NAV[role].map(([id, label]) => `<a href="#/${id}" ${id === current ? 'aria-current="page"' : ''}><span class="role-nav-symbol" aria-hidden="true">${(CUSTOMER_SYMBOLS[id] || ROLE_SYMBOLS[id] || '◇')}</span>${esc(label)}</a>`).join('');
}

let renderSeq = 0;
async function route({ soft = false } = {}) {
  const seq = ++renderSeq;
  const main = $('#main');
  const role = roleOf();
  const hash = location.hash.replace(/^#\/?/, '').split('?')[0];

  if (hash === 'login' || hash === 'register') {
    if (session) { location.hash = '#/' + HOME[role]; return; }
    document.body.classList.add('is-auth');
    renderShell(null);
    main.innerHTML = authH(hash);
    document.title = (hash === 'login' ? 'Sign in' : 'Create account') + ' | SportSphere';
    return;
  }

  if (!NAV[role].some(n => n[0] === hash)) { location.replace('#/' + HOME[role]); return; }

  document.body.classList.remove('is-auth');
  document.body.dataset.workspace = ['organiser','staff','admin','customer'].includes(role) ? role : '';
  renderShell(hash);
  document.title = NAV[role].find(n => n[0] === hash)[1] + ' | SportSphere';
  if (!soft) main.innerHTML = '<div class="loading">Loading…</div>';

  let html;
  try { html = await VIEWS[hash](); } catch (e) { html = errorH(e.message || 'Something went wrong.'); }
  if (seq !== renderSeq) return;
  main.innerHTML = html;
  if (MOUNT[hash]) MOUNT[hash]();
  if (!soft) { window.scrollTo(0, 0); }
}

/* =====================================================================
   Sign in / create account
   ===================================================================== */

function authH(mode) {
  const login = mode === 'login';
  return `
  <div class="auth cinematic-auth">
    <div class="auth-background" aria-hidden="true"></div>
    <div class="auth-left">
      <a class="auth-browse" href="#/courts">← Browse courts without signing in</a>
      <div class="auth-left-bottom">
        <span class="auth-kicker">BOOK · PLAY · ENJOY</span>
        <h1>YOUR GAME.<br>YOUR COURT.</h1>
        <p>Find your court. Book your time. Make every game count.</p>
      </div>
    </div>
    <section class="auth-form-wrap">
      <div class="auth-panel">
        <div class="auth-brand"><span class="auth-brand-mark">◈</span> Sport<span>Sphere</span></div>
        <p class="auth-tagline">BOOK. PLAY. ENJOY.</p>
        <form class="auth-form" data-form="${login ? 'login' : 'register'}" novalidate>
          <h2>${login ? 'Welcome Back' : 'Join SportSphere'}</h2>
          <p class="auth-subtitle">${login ? 'Sign in to continue to your account.' : 'Create an account and start booking your next game.'}</p>
          ${login ? '' : `<label class="field">Full name<input name="name" autocomplete="name" placeholder="Your full name" required></label>`}
          <label class="field">Email<input name="email" type="email" autocomplete="email" placeholder="you@example.com" required></label>
          <label class="field">Password<input name="password" type="password" autocomplete="${login ? 'current-password' : 'new-password'}" placeholder="Enter your password" required></label>
          <p class="err" role="alert"></p>
          <button class="btn primary auth-submit" type="submit">${login ? 'Sign In' : 'Create Account'}</button>
          <div class="auth-divider"><span>OR</span></div>
          <p class="switch-line">${login
            ? '<a class="auth-secondary" href="#/register">Create New Account</a>'
            : '<a class="auth-secondary" href="#/login">Back to Sign In</a>'}</p>
          ${login && SHOW_DEMO_LOGINS ? `
            <div class="demo">
              <p>Demo accounts (click to fill the form)</p>
              <div class="demo-row">${DEMO_LOGINS.map((d, i) => `<button type="button" class="btn sm" data-act="demo" data-i="${i}">${esc(d[0])}</button>`).join('')}</div>
            </div>` : ''}
        </form>
      </div>
    </section>
  </div>`;
}

async function submitLogin(form) {
  const fd = new FormData(form);
  const email = String(fd.get('email') || '').trim();
  const password = String(fd.get('password') || '');
  if (!email || !password) return fail(form, 'Enter your email and password.');
  const r = await api('auth.php', { method: 'POST', body: { email, password } });
  if (!r.ok) return fail(form, r.error);
  saveSession(r.data.token, r.data.user);
  toast(`Welcome back, ${r.data.user.name}.`);
  location.hash = '#/' + HOME[r.data.user.role];
  route();
}

async function submitRegister(form) {
  const fd = new FormData(form);
  const name = String(fd.get('name') || '').trim();
  const email = String(fd.get('email') || '').trim();
  const password = String(fd.get('password') || '');
  if (!name) return fail(form, 'Enter your full name.');
  if (!/^\S+@\S+\.\S+$/.test(email)) return fail(form, 'Enter a valid email address.');
  if (password.length < 6) return fail(form, 'Use a password with at least 6 characters.');
  const r = await api('users.php', { method: 'POST', body: { name, email, password } });
  if (!r.ok) return fail(form, r.error);
  const l = await api('auth.php', { method: 'POST', body: { email, password } });
  if (!l.ok) { toast('Account created. Sign in to continue.'); location.hash = '#/login'; return; }
  saveSession(l.data.token, l.data.user);
  toast('Account created. You are signed in.');
  location.hash = '#/' + HOME[l.data.user.role];
  route();
}

function fail(form, msg) { const e = $('.err', form); if (e) e.textContent = msg; return false; }

/* =====================================================================
   Customer: courts, events, my bookings
   ===================================================================== */

function sportPhoto(category) {
  const c = String(category || '').toLowerCase();
  if (c.includes('badminton')) return COURT_PHOTOS.badminton;
  if (c.includes('pickleball')) return COURT_PHOTOS.pickleball;
  return COURT_PHOTOS.futsal;
}


async function viewCourts() {
  const r = await api('venues.php');
  if (!r.ok) return errorH(r.error);
  const list = state.cache.venues = r.data.data || [];
  const cats = [...new Set(list.map(v => v.category))].sort();
  if (state.courtCat !== 'All' && !cats.includes(state.courtCat)) state.courtCat = 'All';
  const shown = list;

  const hero = session ? '' : `
    <section class="hero guest-hero">
      <div class="hero-copy">
        <span class="guest-eyebrow">WELCOME TO SPORTSPHERE</span>
        <h1>Find your court.<br><em>Own the game.</em></h1>
        <p>Book futsal, badminton and pickleball courts in just a few clicks. Your next match starts here.</p>
        <div class="hero-cta">
          <a class="btn primary" href="#/register">Get started →</a>
          <a class="btn light" href="#/login">Sign in</a>
        </div>
        <div class="guest-hero-foot">FUTSAL <span>•</span> BADMINTON <span>•</span> PICKLEBALL</div>
      </div>
    </section>`;

  return `
    ${hero}
    ${session ? pageHead('Courts', 'Rent a court by the hour. Staff confirm each booking and your QR ticket appears once they do.') : `<div class="guest-section-heading"><div><span class="guest-section-kicker">EXPLORE OUR VENUES</span><h2>Choose your court</h2><p>Pick a sport, find your space, and get ready to play.</p></div><span class="guest-section-count">${list.length} courts</span></div>`}
    ${list.length ? `<div class="chips" role="group" aria-label="Filter by sport">
      ${['All', ...cats].map(c => `<button class="filter" aria-pressed="${c === state.courtCat}" data-act="courtCat" data-cat="${esc(c)}">${esc(c)}</button>`).join('')}
    </div>` : ''}
    ${shown.length ? `<div class="courts">${shown.map(v => {
      const open = num(v.is_available) === 1;
      return `<article class="court ${open ? '' : 'off'}" data-court-category="${esc(v.category)}" ${state.courtCat !== 'All' && v.category !== state.courtCat ? 'hidden' : ''}>
        <div class="court-photo" style="background-image:linear-gradient(0deg,rgba(3,24,49,.18),transparent),url('${sportPhoto(v.category)}')"><span class="availability ${open ? 'available' : 'unavailable'}">${open ? 'Available' : 'Unavailable'}</span></div>
        <div class="court-info"><span class="sport-tag">${esc(v.category)}</span><h3>${esc(v.venue_name)}</h3><p class="muted">${open ? 'Ready for booking' : 'Not available right now'}</p></div>
        <div class="court-bottom"><div class="rate">${esc(money(v.hourly_rate))} <small>/ hour</small></div>
        <button class="btn primary" data-act="book" data-kind="venue" data-id="${esc(v.id)}" ${open ? '' : 'disabled'}>${open ? 'Book now →' : 'Unavailable'}</button></div>
      </article>`;
    }).join('')}</div>` : emptyH('No courts yet', 'Courts will show up here as soon as staff add them.')}`;
}

function stubTotals(e) {
  const total = num(e.total_tickets), sold = num(e.tickets_sold);
  return { total, sold, left: Math.max(total - sold, 0) };
}

async function viewEvents() {
  const r = await api('events.php');
  if (!r.ok) return errorH(r.error);
  const list = state.cache.events = (r.data.data || []).slice().sort((a, b) => String(a.event_date).localeCompare(String(b.event_date)));
  const today = todayISO();
  if (!list.length) return pageHead('Events', 'Tournaments and matches you can buy tickets for.') + emptyH('No events yet', 'Check back soon. Organisers publish new events here.');

  return `
    <section class="ev-intro"><div><span class="ev-kicker">SPORTSPHERE • LIVE EXPERIENCES</span><h1>Find your next <em>big moment.</em></h1><p>From local tournaments to championship matches. Discover an event, grab your ticket, and be part of the action.</p></div><div class="ev-intro-mark" aria-hidden="true">✦</div></section>
    <div class="ev-section-title"><div><span class="ev-kicker">THE LINEUP</span><h2>Upcoming & featured events</h2></div><span class="ev-count">${list.length} events</span></div>
    <div class="ev-grid">${list.map((e,idx) => {
      const t = stubTotals(e);
      const p = parseDate(e.event_date) || { d: '', m: 1 };
      const ended = String(e.event_date) < today;
      const out = t.left === 0;
      const pct = t.total ? Math.min(100, Math.round(t.sold / t.total * 100)) : 0;
      const title = String(e.event_name || '').toLowerCase();
      const sport = title.includes('badminton') ? 'badminton' : title.includes('pickleball') ? 'pickleball' : title.includes('futsal') ? 'futsal' : 'multi';
      const photo = sport === 'badminton' ? 'images/BadmintonCourt.jpg' : sport === 'pickleball' ? 'images/PickleballCourt.jpg' : sport === 'futsal' ? 'images/FutsalCourt.jpg' : 'images/login-background.png';
      const label = sport === 'multi' ? 'SPORTS EVENT' : sport.toUpperCase();
      return `<article class="ev-card ${ended ? 'ev-ended' : ''}">
        <div class="ev-cover"><img src="${photo}" alt="${esc(label)} venue" loading="lazy"><div class="ev-cover-shade"></div><span class="ev-sport">${label}</span><span class="ev-date"><b>${esc(p.d)}</b><small>${esc(MONTHS[p.m-1])}</small></span></div>
        <div class="ev-content"><span class="ev-eyebrow">${ended ? 'EVENT ENDED' : out ? 'SOLD OUT' : 'BOOK YOUR SPOT'}</span><h3>${esc(e.event_name)}</h3><p class="ev-when">◷ ${esc(fmtDate(e.event_date))}</p>
          <div class="ev-availability"><div><span>Ticket availability</span><strong>${out ? 'Sold out' : `${esc(t.left)} left`}</strong></div><div class="ev-track"><i style="width:${pct}%"></i></div><small>${esc(t.sold)} of ${esc(t.total)} tickets booked</small></div>
          <div class="ev-footer"><div><small>STARTING FROM</small><strong>${esc(money(e.ticket_price, {free:true}))}</strong></div>${ended ? '<span class="ev-unavailable">Event ended</span>' : out ? '<span class="ev-unavailable">Sold out</span>' : `<button class="btn primary" data-act="book" data-kind="event" data-id="${esc(e.id)}">Get tickets →</button>`}</div>
        </div></article>`;
    }).join('')}</div>`;
}

function myUnpaid() { try { return JSON.parse(store.get('ss_unpaid') || '[]'); } catch { return []; } }
function setUnpaid(list) { store.set('ss_unpaid', JSON.stringify(list)); }

// Court photography used consistently in Courts and My Bookings.
const COURT_PHOTOS = {
  futsal: 'images/FutsalCourt.jpg',
  badminton: 'images/BadmintonCourt.jpg',
  pickleball: 'images/PickleballCourt.jpg'
};
const bookingPhotos = {
  ...COURT_PHOTOS,
  event: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=800&q=80'
};
let myBookingTab = 'upcoming';
function bookingGroup(b) {
  if (b.status === 'cancelled') return 'cancelled';
  if (b.status === 'confirmed' && String(b.booking_date).slice(0, 10) < todayISO()) return 'completed';
  return 'upcoming';
}
function bookingPhoto(b) {
  if (b.booking_type === 'event') return bookingPhotos.event;
  const venue = state.cache.venues.find(v => num(v.id) === num(b.venue_id));
  const category = String(venue?.category || b.category || itemName(b)).toLowerCase();
  return bookingPhotos[Object.keys(bookingPhotos).find(k => category.includes(k))] || bookingPhotos.futsal;
}
function bookingCardH(b, unpaid) {
  const isEvent = b.booking_type === 'event';
  const confirmed = b.status === 'confirmed';
  const needsPay = b.status === 'pending' && unpaid.includes(num(b.id));
  return `<article class="mb-card">
    <img class="mb-photo" src="${esc(bookingPhoto(b))}" alt="${esc(isEvent ? 'Sporting event' : 'Sports court')}" loading="lazy">
    <div class="mb-content">
      <div class="mb-card-top"><span class="mb-type">${isEvent ? 'EVENT TICKET' : 'COURT BOOKING'}</span>${chipH(b.status)}</div>
      <h3>${esc(itemName(b))}</h3>
      <p class="mb-sub">Booking #${esc(b.id)}</p>
      <div class="mb-facts"><span>📅 ${esc(fmtDate(b.booking_date))}</span><span>◷ ${esc(plural(num(b.quantity), isEvent ? 'ticket' : 'hour'))}</span></div>
      <div class="mb-bottom"><strong>${esc(money(b.total_price))}</strong><div class="mb-buttons">${needsPay ? `<button class="btn primary sm" data-act="payNow" data-id="${esc(b.id)}">Pay now</button>` : ''}<button class="btn sm" data-act="myBookingDetails" data-id="${esc(b.id)}">View details</button></div></div>
    </div>
  </article>`;
}
function paintMyBookings() {
  const root = $('#myBookingCards'); if (!root) return;
  const mine = state.cache.bookings;
  document.querySelectorAll('[data-act="myBookingTab"]').forEach(el => {
    el.classList.toggle('on', el.dataset.tab === myBookingTab);
    el.setAttribute('aria-pressed', String(el.dataset.tab === myBookingTab));
  });
  const filtered = mine.filter(b => myBookingTab === 'all' || bookingGroup(b) === myBookingTab);
  root.innerHTML = filtered.length ? filtered.map(b => bookingCardH(b, myUnpaid())).join('') : '<div class="mb-empty">No bookings in this category.</div>';
}
async function viewCustomerDashboard() {
  const result = await api('bookings.php');
  if (!result.ok) return errorH(result.error || 'Could not load your bookings.');
  const mine = (result.data.data || []).filter(b => num(b.customer_id) === num(session.user.id));
  state.cache.bookings = mine;
  const upcoming = mine.filter(b => bookingGroup(b) === 'upcoming');
  const completed = mine.filter(b => bookingGroup(b) === 'completed');
  const cancelled = mine.filter(b => bookingGroup(b) === 'cancelled');
  const next = [...upcoming].sort((a,b) => String(a.booking_date).localeCompare(String(b.booking_date))).slice(0,3);
  const recent = [...mine].sort((a,b) => num(b.id)-num(a.id)).slice(0,4);
  const name = String(session.user.full_name || session.user.name || 'Player').split(' ')[0];
  return `<section class="customer-dashboard">
    <div class="cd-hero"><div><span class="cd-eyebrow">YOUR SPORTSPHERE HUB</span><h1>Welcome back, ${esc(name)}!</h1><p>See what's coming up and manage your games in one place.</p><div class="cd-hero-actions"><a class="btn primary" href="#/courts">Explore courts →</a><a class="btn" href="#/events">Browse events</a></div></div><div class="cd-hero-icon" aria-hidden="true"><span class="sport-orbit">✦</span><span class="sport-orbit-label">PLAY MORE<br>LIVE MORE</span></div></div>
    <div class="cd-stats"><div class="cd-stat"><div class="cd-stat-icon">▤</div><span>Total bookings</span><strong>${mine.length}</strong><small>All your reservations</small></div><div class="cd-stat"><div class="cd-stat-icon">◷</div><span>Upcoming</span><strong>${upcoming.length}</strong><small>Scheduled bookings</small></div><div class="cd-stat"><div class="cd-stat-icon">✓</div><span>Completed</span><strong>${completed.length}</strong><small>Past confirmed games</small></div><div class="cd-stat"><div class="cd-stat-icon">×</div><span>Cancelled</span><strong>${cancelled.length}</strong><small>Cancelled reservations</small></div></div>
    <div class="cd-section-head"><div><h2>Coming up next</h2><p>Your next scheduled courts and events</p></div><a href="#/my-bookings">View all bookings →</a></div>
    ${next.length ? `<div class="cd-next-grid">${next.map(b => `<article class="cd-next-card"><img src="${esc(bookingPhoto(b))}" alt="Sports booking" loading="lazy"><div class="cd-next-body">${chipH(b.status)}<h3>${esc(itemName(b))}</h3><p>📅 ${esc(fmtDate(b.booking_date))}</p><p>${b.booking_type === 'event' ? '🎟 Event ticket' : '🏟 Court reservation'} · ${esc(plural(num(b.quantity), b.booking_type === 'event' ? 'ticket' : 'hour'))}</p><div class="cd-next-bottom"><strong>${esc(money(b.total_price))}</strong><a href="#/my-bookings">Manage →</a></div></div></article>`).join('')}</div>` : `<div class="cd-empty"><span>📅</span><h3>No upcoming bookings</h3><p>Ready for your next game? Find a court or an event to join.</p><a class="btn primary" href="#/courts">Find a court</a></div>`}
    <div class="cd-section-head"><div><h2>Recent activity</h2><p>Your latest booking records</p></div><a href="#/my-bookings">My bookings →</a></div>
    ${recent.length ? `<div class="cd-activity">${recent.map(b => `<div class="cd-activity-row"><div class="cd-activity-symbol">${b.booking_type === 'event' ? '🎟' : '🏸'}</div><div class="cd-activity-name"><strong>${esc(itemName(b))}</strong><span>${esc(fmtDate(b.booking_date))} · Booking #${esc(b.id)}</span></div>${chipH(b.status)}<strong>${esc(money(b.total_price))}</div>`).join('')}</div>` : `<div class="cd-empty"><p>No booking activity yet.</p></div>`}
  </section>`;
}

async function viewMyBookings() {
  const r = await api('bookings.php');
  if (!r.ok) return errorH(r.error);
  const mine = (r.data.data || []).filter(b => num(b.customer_id) === num(session.user.id));
  state.cache.bookings = mine;
  const counts = { all: mine.length, upcoming: 0, completed: 0, cancelled: 0 };
  mine.forEach(b => counts[bookingGroup(b)]++);
  return `${pageHead('My bookings', 'Manage your court reservations and event tickets.')}
    <div class="mb-summary"><div><span>Total bookings</span><strong>${counts.all}</strong></div><div><span>Upcoming</span><strong>${counts.upcoming}</strong></div><div><span>Completed</span><strong>${counts.completed}</strong></div></div>
    <div class="mb-tabs" role="group" aria-label="Booking status">${['upcoming','completed','cancelled','all'].map(t => `<button class="tab ${t === myBookingTab ? 'on' : ''}" data-act="myBookingTab" data-tab="${t}" aria-pressed="${t === myBookingTab}">${cap(t)} <span>${counts[t]}</span></button>`).join('')}</div>
    <div id="myBookingCards" class="mb-list"></div>
    ${!mine.length ? '<p class="muted">No bookings yet. <a href="#/courts">Browse courts</a> to get started.</p>' : ''}`;
}
function openMyBookingDetails(id) {
  const b = state.cache.bookings.find(x => num(x.id) === num(id)); if (!b) return;
  const confirmed = b.status === 'confirmed';
  openDlg(`<div class="dlg-form"><div><h2>${esc(itemName(b))}</h2><p class="muted">Booking #${esc(b.id)}</p></div>
    <img class="mb-detail-photo" src="${esc(bookingPhoto(b))}" alt="Sports venue" loading="lazy">
    <div class="mb-detail-grid"><span>Status</span><strong>${chipH(b.status)}</strong><span>Date</span><strong>${esc(fmtDate(b.booking_date))}</strong><span>Quantity</span><strong>${esc(plural(num(b.quantity), b.booking_type === 'event' ? 'ticket' : 'hour'))}</strong><span>Total</span><strong>${esc(money(b.total_price))}</strong></div>
    ${confirmed && b.qr_code_url ? `<div class="mb-qr"><img src="${esc(b.qr_code_url)}" width="144" height="144" alt="QR ticket"><p class="muted">Show this QR code at check-in.</p></div>` : '<p class="muted">QR ticket is available once staff confirms your booking.</p>'}
    <div class="dlg-actions"><button class="btn primary" data-act="closeDlg">Close</button></div></div>`);
}

/* ---------- booking dialog ---------- */

const payMethodsH = () => `<fieldset class="seg"><legend>Payment method</legend>${[['fpx', 'Online banking (FPX)'], ['card', 'Credit or debit card'], ['e-wallet', 'E-wallet']]
  .map(([v, l], i) => `<label><input type="radio" name="pay" value="${v}" ${i === 0 ? 'checked' : ''}><span>${l}</span></label>`).join('')}</fieldset>`;

function openBooking(kind, id) {
  if (!session) { toast('Sign in to book.', 'err'); location.hash = '#/login'; return; }
  if (!['customer','organiser','staff','admin'].includes(session.user.role)) { toast('Only customer accounts can book.', 'err'); return; }
  const item = (kind === 'venue' ? state.cache.venues : state.cache.events).find(x => num(x.id) === num(id));
  if (!item) return;
  state.booking = { kind, item };

  const isVenue = kind === 'venue';
  const unit = num(isVenue ? item.hourly_rate : item.ticket_price);
  const left = isVenue ? 8 : Math.max(stubTotals(item).left, 1);
  const unitWord = isVenue ? 'hour' : 'ticket';

  openDlg(`
    <form class="dlg-form" data-form="book" novalidate>
      <div>
        <h2>${isVenue ? 'Book ' + esc(item.venue_name) : esc(item.event_name)}</h2>
        <p class="muted">${isVenue ? `${esc(item.category)}, ${esc(money(unit))} per hour` : `${esc(fmtDate(item.event_date))}, ${esc(money(unit, { free: true }))} per ticket`}</p>
      </div>
      ${isVenue ? `<label class="field">Date<input type="date" name="date" min="${todayISO()}" value="${todayISO()}" required></label>` : ''}
      <label class="field">${isVenue ? 'Hours' : 'Tickets'}
        <input type="number" name="qty" min="1" max="${left}" value="1" required>
        ${isVenue ? '<span class="hint">Up to 8 hours per booking.</span>' : `<span class="hint">${esc(plural(left, 'ticket'))} left.</span>`}
      </label>
      ${unit > 0 ? payMethodsH() : '<p class="muted">This event is free, so there is nothing to pay.</p>'}
      <div class="sum"><span id="sumLine"></span><strong id="sumTotal"></strong></div>
      <p class="err" role="alert"></p>
      <div class="dlg-actions">
        <button type="button" class="btn" data-act="closeDlg">Cancel</button>
        <button type="submit" class="btn primary">${unit > 0 ? 'Book and pay' : 'Reserve tickets'}</button>
      </div>
    </form>`, root => {
    const qtyEl = $('[name=qty]', root);
    const update = () => {
      const q = Math.max(1, parseInt(qtyEl.value, 10) || 1);
      $('#sumLine', root).textContent = `${money(unit, { free: true })} × ${plural(q, unitWord)}`;
      $('#sumTotal', root).textContent = money(unit * q, { free: true });
    };
    qtyEl.addEventListener('input', update);
    update();
  });
}

async function submitBooking(form) {
  const { kind, item } = state.booking;
  const fd = new FormData(form);
  const isVenue = kind === 'venue';
  const unit = num(isVenue ? item.hourly_rate : item.ticket_price);
  const qty = parseInt(fd.get('qty'), 10);
  const max = isVenue ? 8 : Math.max(stubTotals(item).left, 1);
  const date = isVenue ? String(fd.get('date') || '') : String(item.event_date).slice(0, 10);

  if (!Number.isInteger(qty) || qty < 1 || qty > max) return fail(form, `Enter ${isVenue ? 'between 1 and 8 hours' : `between 1 and ${max} tickets`}.`);
  if (!date || date < todayISO()) return fail(form, 'Pick today or a later date.');

  const total = unit * qty;
  const b = await api('bookings.php', { method: 'POST', body: {
    customer_id: session.user.id, booking_type: kind,
    venue_id: isVenue ? num(item.id) : null, event_id: isVenue ? null : num(item.id),
    booking_date: date, quantity: qty, status: 'pending',
  } });
  if (!b.ok) return fail(form, b.error);

  const bookingId = num(b.data.booking_id);
  let ref = '';
  if (total > 0) {
    const p = await api('payments.php', { method: 'POST', body: { booking_id: bookingId, payment_method: fd.get('pay'), amount: total } });
    if (!p.ok) {
      setUnpaid([...new Set([...myUnpaid(), bookingId])]);
      closeDlg();
      toast(`Booking #${bookingId} is saved but payment didn't go through. Pay from My bookings.`, 'err');
      location.hash = '#/my-bookings';
      return;
    }
    ref = p.data.transaction_ref || '';
  }

  openDlg(`
    <div class="dlg-form">
      <h2>Booking placed</h2>
      <p>Booking #${esc(bookingId)} for ${esc(isVenue ? item.venue_name : item.event_name)} on ${esc(fmtDate(date))}.${ref ? ` Payment received, reference ${esc(ref)}.` : ''}</p>
      <p class="muted">Staff confirm each booking. Your QR ticket appears in My bookings as soon as they do.</p>
      <div class="dlg-actions">
        <button type="button" class="btn" data-act="closeDlg">Close</button>
        <a class="btn primary" href="#/my-bookings">View my bookings</a>
      </div>
    </div>`);
  route({ soft: true });
}

function openPayNow(id) {
  const b = state.cache.bookings.find(x => num(x.id) === num(id));
  if (!b) return;
  openDlg(`
    <form class="dlg-form" data-form="pay" data-id="${esc(b.id)}" novalidate>
      <div><h2>Pay for booking #${esc(b.id)}</h2><p class="muted">${esc(itemName(b))}, ${esc(fmtDate(b.booking_date))}</p></div>
      ${payMethodsH()}
      <div class="sum"><span>Total</span><strong>${esc(money(b.total_price))}</strong></div>
      <p class="err" role="alert"></p>
      <div class="dlg-actions"><button type="button" class="btn" data-act="closeDlg">Cancel</button><button type="submit" class="btn primary">Pay ${esc(money(b.total_price))}</button></div>
    </form>`);
}

async function submitPay(form) {
  const id = num(form.dataset.id);
  const b = state.cache.bookings.find(x => num(x.id) === id);
  const p = await api('payments.php', { method: 'POST', body: { booking_id: id, payment_method: new FormData(form).get('pay'), amount: num(b.total_price) } });
  if (!p.ok) return fail(form, p.error);
  setUnpaid(myUnpaid().filter(x => x !== id));
  closeDlg();
  toast(`Payment received, reference ${p.data.transaction_ref}.`);
  route({ soft: true });
}

/* =====================================================================
   Staff and admin: bookings, payments
   ===================================================================== */

async function viewStaffDashboard() {
  const [b, c, p] = await Promise.all([api('bookings.php'), api('venues.php'), api('payments.php')]);
  if (!b.ok) return errorH(b.error);
  const bookings = b.data.data || [];
  const courts = c.ok ? (c.data.data || []) : [];
  const payments = p.ok ? (p.data.data || []) : [];
  state.cache.bookings = bookings;
  state.cache.payments = payments;
  const pending = bookings.filter(x => x.status === 'pending');
  const confirmed = bookings.filter(x => x.status === 'confirmed');
  const openCourts = courts.filter(x => ['available','active','open','1'].includes(String(x.status ?? x.is_available ?? '').toLowerCase()));
  return `${roleBannerH('Staff dashboard', 'Your daily workspace for courts, reservations and payments.')}
    ${roleMetricsH(roleStatH('Total bookings', bookings.length), roleStatH('Awaiting approval', pending.length), roleStatH('Confirmed bookings', confirmed.length), roleStatH('Courts listed', courts.length))}
    <div class="staff-quick-actions">
      <button class="btn primary" data-act="nav" data-page="bookings">Manage bookings →</button>
      <button class="btn" data-act="nav" data-page="manage-courts">Manage courts →</button>
      <button class="btn" data-act="nav" data-page="payments">View payments →</button>
    </div>
    ${pageHead('Bookings requiring attention', 'Review payment details before confirming any reservation.')}
    ${pending.length ? `<div class="table-wrap"><table class="dt"><thead><tr><th>#</th><th>Customer</th><th>Booked</th><th>Date</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr></thead><tbody>${pending.slice(0,6).map(x=>bookingRowH(x,true)).join('')}</tbody></table></div>` : emptyH('All caught up', 'There are no pending bookings right now.')}
    <div class="staff-dashboard-footer"><span>${courts.length} courts in the system · ${payments.length} payment records</span><button class="btn sm" data-act="nav" data-page="bookings">See all bookings →</button></div>`;
}

async function viewBookings() {
  const [b, p] = await Promise.all([api('bookings.php'), api('payments.php')]);
  if (!b.ok) return errorH(b.error);
  state.cache.bookings = b.data.data || [];
  state.cache.payments = p.ok ? (p.data.data || []) : [];
  return `
    ${roleBannerH('Booking operations', 'Review reservations, verify payments and keep bookings moving.')}
    ${roleMetricsH(roleStatH('Total bookings',state.cache.bookings.length),roleStatH('Awaiting approval',state.cache.bookings.filter(x=>x.status==='pending').length),roleStatH('Confirmed',state.cache.bookings.filter(x=>x.status==='confirmed').length),roleStatH('Cancelled',state.cache.bookings.filter(x=>x.status==='cancelled').length))}
    ${pageHead('Booking queue', 'Check payment status before confirming a reservation.')}
    <div class="toolbar">
      <div class="tabs" id="bkTabs" role="group" aria-label="Filter by status"></div>
      <input type="search" id="bkQ" data-input="bkSearch" placeholder="Search customer or item" aria-label="Search bookings" value="${esc(state.bk.q)}">
    </div>
    <div class="table-wrap"><table class="dt">
      <thead><tr><th>#</th><th>Customer</th><th>Booked</th><th>Date</th><th class="num">Total</th><th>Payment</th><th>Status</th><th></th></tr></thead>
      <tbody id="bkBody"></tbody>
    </table></div>`;
}

function bookingActionsH(b, compact = false) {
  const isAdmin = roleOf() === 'admin' && !compact;
  const btn = (s, label, cls = '') => `<button class="btn sm ${cls}" data-act="setStatus" data-id="${esc(b.id)}" data-s="${s}">${label}</button>`;
  let out = '';
  if (b.status === 'pending') out = btn('confirmed', 'Confirm', 'primary') + btn('cancelled', 'Decline');
  else if (b.status === 'confirmed') out = btn('cancelled', 'Cancel');
  else out = btn('pending', 'Reopen');
  if (isAdmin) out += `<button class="btn sm danger" data-act="deleteBooking" data-id="${esc(b.id)}">Delete</button>`;
  return out;
}

function bookingRowH(b, compact = false) {
  return `<tr>
    <td class="nw">#${esc(b.id)}</td>
    <td class="nw">${esc(b.customer_name || 'Customer #' + b.customer_id)}</td>
    <td>${esc(itemName(b))}<span class="cell-sub">${b.booking_type === 'event' ? esc(plural(num(b.quantity), 'ticket')) : esc(plural(num(b.quantity), 'hour'))}</span></td>
    <td class="nw">${esc(fmtDate(b.booking_date))}</td>
    <td class="num">${esc(money(b.total_price))}</td>
    <td>${payChipH(paymentFor(b.id))}</td>
    <td>${chipH(b.status)}</td>
    <td class="actions">${bookingActionsH(b, compact)}</td>
  </tr>`;
}

function paintBookings() {
  const all = state.cache.bookings;
  const { status, q } = state.bk;
  const counts = { all: all.length };
  ['pending', 'confirmed', 'cancelled'].forEach(s => { counts[s] = all.filter(b => b.status === s).length; });
  $('#bkTabs').innerHTML = ['all', 'pending', 'confirmed', 'cancelled'].map(s =>
    `<button class="tab ${s === status ? 'on' : ''}" data-act="bkStatus" data-s="${s}" aria-pressed="${s === status}">${cap(s)}<span>${counts[s]}</span></button>`).join('');
  const needle = q.trim().toLowerCase();
  const rows = all.filter(b => (status === 'all' || b.status === status) &&
    (!needle || `${b.customer_name || ''} ${itemName(b)} #${b.id}`.toLowerCase().includes(needle)));
  $('#bkBody').innerHTML = rows.length ? rows.map(bookingRowH).join('') : '<tr><td colspan="8" class="empty-cell">No bookings match.</td></tr>';
}

async function setBookingStatus(id, status) {
  const b = state.cache.bookings.find(x => num(x.id) === num(id));
  if (status === 'cancelled') {
    const ok = await confirmDlg({
      title: b && b.status === 'confirmed' ? 'Cancel this confirmed booking?' : 'Decline this booking?',
      body: `Booking #${id}${b ? ' for ' + itemName(b) : ''} will be marked cancelled and its QR ticket stops working.`,
      ok: b && b.status === 'confirmed' ? 'Cancel booking' : 'Decline booking', danger: true,
    });
    if (!ok) return;
  }
  const r = await api(`bookings.php?id=${encodeURIComponent(id)}`, { method: 'PUT', body: { status } });
  if (!r.ok) return toast(r.error, 'err');
  toast(status === 'confirmed' ? `Booking #${id} confirmed. QR ticket issued.` : `Booking #${id} marked ${status}.`);
  route({ soft: true });
}

async function deleteBooking(id) {
  const ok = await confirmDlg({ title: `Delete booking #${id}?`, body: 'This removes the record for good. Payments linked to it may stop it from being deleted.', ok: 'Delete booking', danger: true });
  if (!ok) return;
  const r = await api(`bookings.php?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
  if (!r.ok) return toast(r.error, 'err');
  toast(`Booking #${id} deleted.`);
  route({ soft: true });
}

async function viewPayments() {
  const r = await api('payments.php');
  if (!r.ok) return errorH(r.error);
  const list = r.data.data || [];
  const done = list.filter(p => p.payment_status === 'completed');
  const collected = done.reduce((s, p) => s + num(p.amount), 0);
  return `
    ${roleBannerH('Payment centre', 'A clear view of customer transactions and receipts.')}
    ${roleMetricsH(roleStatH('Total transactions',list.length),roleStatH('Completed',done.length),roleStatH('Collected',money(collected)))}
    ${pageHead('Payment records', list.length ? `${money(collected)} collected from ${plural(done.length, 'completed payment')}.` : 'Payments appear here as customers pay.')}
    ${list.length ? `<div class="table-wrap"><table class="dt">
      <thead><tr><th>Reference</th><th>Booking</th><th>Method</th><th class="num">Amount</th><th>Status</th><th>Paid on</th></tr></thead>
      <tbody>${list.map(p => `<tr>
        <td>${esc(p.transaction_ref)}</td><td>#${esc(p.booking_id)}</td><td>${esc(METHOD[p.payment_method] || p.payment_method)}</td>
        <td class="num">${esc(money(p.amount))}</td>
        <td><span class="pay ${esc(p.payment_status)}">${esc(cap(p.payment_status))}</span></td>
        <td>${esc(fmtDate(p.created_at))}</td></tr>`).join('')}</tbody>
    </table></div>` : emptyH('No payments yet', 'Once a customer pays for a booking it is listed here.')}`;
}

/* =====================================================================
   Staff and admin: courts
   ===================================================================== */

async function viewManageCourts() {
  const r = await api('venues.php');
  if (!r.ok) return errorH(r.error);
  const list = state.cache.venues = r.data.data || [];
  const cats = [...new Set(['Futsal', 'Badminton', 'Pickleball', 'Tennis', 'Basketball', ...list.map(v => v.category)])];
  const isAdmin = roleOf() === 'admin';
  return `
    ${roleBannerH('Court management', 'Keep every venue ready for the next game.')}
    ${roleMetricsH(roleStatH('Total courts',list.length),roleStatH('Available',list.filter(v=>num(v.is_available)===1).length),roleStatH('Unavailable',list.filter(v=>num(v.is_available)!==1).length))}
    ${pageHead('Manage courts', 'Add courts, update rates and manage availability.')}
    <form class="inline-form" data-form="addCourt" novalidate>
      <label class="field">Court name<input name="name" required placeholder="Badminton Court 3"></label>
      <label class="field">Sport<input name="category" list="sports" required placeholder="Badminton"><datalist id="sports">${cats.map(c => `<option value="${esc(c)}">`).join('')}</datalist></label>
      <label class="field">Rate per hour (RM)<input name="rate" type="number" min="0" step="0.01" required placeholder="25.00"></label>
      <button class="btn primary" type="submit">Add court</button>
      <p class="err" role="alert"></p>
    </form>
    ${list.length ? `<div class="table-wrap"><table class="dt">
      <thead><tr><th>Court</th><th>Sport</th><th class="num">Rate per hour</th><th>Booking</th><th></th></tr></thead>
      <tbody>${list.map(v => {
        const open = num(v.is_available) === 1;
        return `<tr>
          <td><strong>${esc(v.venue_name)}</strong></td><td>${esc(v.category)}</td><td class="num">${esc(money(v.hourly_rate))}</td>
          <td>${open ? '<span class="chip confirmed">Open</span>' : '<span class="chip cancelled" style="text-decoration:none">Closed</span>'}</td>
          <td class="actions">
            <button class="btn sm" data-act="toggleCourt" data-id="${esc(v.id)}">${open ? 'Close for booking' : 'Open for booking'}</button>
            <button class="btn sm" data-act="editCourt" data-id="${esc(v.id)}">Edit</button>
            ${isAdmin ? `<button class="btn sm danger" data-act="deleteCourt" data-id="${esc(v.id)}">Delete</button>` : ''}
          </td></tr>`;
      }).join('')}</tbody></table></div>` : emptyH('No courts yet', 'Add the first court with the form above.')}`;
}

async function submitAddCourt(form) {
  const fd = new FormData(form);
  const name = String(fd.get('name') || '').trim(), category = String(fd.get('category') || '').trim(), rate = parseFloat(fd.get('rate'));
  if (!name || !category || !(rate >= 0)) return fail(form, 'Fill in the court name, sport and hourly rate.');
  const r = await api('venues.php', { method: 'POST', body: { venue_name: name, category, hourly_rate: rate } });
  if (!r.ok) return fail(form, r.error);
  toast(`${name} added.`);
  route();
}

function openEditCourt(id) {
  const v = state.cache.venues.find(x => num(x.id) === num(id));
  if (!v) return;
  openDlg(`
    <form class="dlg-form" data-form="editCourt" data-id="${esc(v.id)}" novalidate>
      <h2>Edit court</h2>
      <label class="field">Court name<input name="name" value="${esc(v.venue_name)}" required></label>
      <label class="field">Rate per hour (RM)<input name="rate" type="number" min="0" step="0.01" value="${esc(num(v.hourly_rate).toFixed(2))}" required></label>
      <label class="field check"><input type="checkbox" name="open" ${num(v.is_available) === 1 ? 'checked' : ''}>Open for booking</label>
      <p class="hint muted small">The sport can't be changed after a court is added.</p>
      <p class="err" role="alert"></p>
      <div class="dlg-actions"><button type="button" class="btn" data-act="closeDlg">Cancel</button><button type="submit" class="btn primary">Save changes</button></div>
    </form>`);
}

async function putCourt(id, name, rate, open) {
  return api(`venues.php?id=${encodeURIComponent(id)}`, { method: 'PUT', body: { venue_name: name, hourly_rate: rate, is_available: open ? 1 : 0 } });
}

async function submitEditCourt(form) {
  const fd = new FormData(form);
  const name = String(fd.get('name') || '').trim(), rate = parseFloat(fd.get('rate'));
  if (!name || !(rate >= 0)) return fail(form, 'Enter a court name and an hourly rate.');
  const r = await putCourt(form.dataset.id, name, rate, fd.get('open') === 'on');
  if (!r.ok) return fail(form, r.error);
  closeDlg(); toast('Court updated.'); route({ soft: true });
}

async function toggleCourt(id) {
  const v = state.cache.venues.find(x => num(x.id) === num(id));
  if (!v) return;
  const open = num(v.is_available) !== 1;
  const r = await putCourt(v.id, v.venue_name, num(v.hourly_rate), open);
  if (!r.ok) return toast(r.error, 'err');
  toast(`${v.venue_name} is now ${open ? 'open' : 'closed'} for booking.`);
  route({ soft: true });
}

async function deleteCourt(id) {
  const v = state.cache.venues.find(x => num(x.id) === num(id));
  const ok = await confirmDlg({ title: `Delete ${v ? v.venue_name : 'this court'}?`, body: 'Courts that already have bookings usually can\'t be deleted. Close it for booking instead if you just want it hidden.', ok: 'Delete court', danger: true });
  if (!ok) return;
  const r = await api(`venues.php?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
  if (!r.ok) return toast(r.error, 'err');
  toast('Court deleted.'); route({ soft: true });
}

/* =====================================================================
   Organiser and admin: events, ticket sales
   ===================================================================== */

async function viewOrganiserDashboard() {
  const [ev, bk] = await Promise.all([api('events.php'), api('bookings.php')]);
  if (!ev.ok) return errorH(ev.error);
  const mine = (ev.data.data || []).filter(e => num(e.organiser_id) === num(session.user.id));
  const ids = new Set(mine.map(e => num(e.id)));
  const bookings = bk.ok ? (bk.data.data || []).filter(b => b.booking_type === 'event' && ids.has(num(b.event_id))) : [];
  const upcoming = mine.filter(e => String(e.event_date) >= todayISO());
  const sold = bookings.filter(b => b.status !== 'cancelled').reduce((sum,b) => sum + num(b.quantity), 0);
  const revenue = bookings.filter(b => b.status === 'confirmed').reduce((sum,b) => sum + num(b.total_price), 0);
  const next = [...upcoming].sort((a,b) => String(a.event_date).localeCompare(String(b.event_date))).slice(0,5);
  return `${roleBannerH('Organiser dashboard', 'Manage your tournaments, track ticket sales and keep upcoming events on schedule.')}
    ${roleMetricsH(roleStatH('My events', mine.length), roleStatH('Upcoming events', upcoming.length), roleStatH('Tickets booked', sold), roleStatH('Confirmed revenue', money(revenue, {whole:true})))}
    <div class="staff-quick-actions"><button class="btn primary" data-act="nav" data-page="manage-events">Manage my events →</button><button class="btn" data-act="nav" data-page="sales">View ticket sales →</button></div>
    ${pageHead('Upcoming events', 'Your next scheduled tournaments and matches.')}
    ${next.length ? `<div class="table-wrap"><table class="dt"><thead><tr><th>Event</th><th>Date</th><th>Ticket price</th><th>Tickets sold</th></tr></thead><tbody>${next.map(e => {const t=stubTotals(e);return `<tr><td>${esc(e.event_name)}</td><td>${esc(e.event_date)}</td><td>${esc(money(e.ticket_price))}</td><td>${esc(t.sold)} / ${esc(t.total)}</td></tr>`;}).join('')}</tbody></table></div>` : emptyH('No upcoming events', 'Create an event from My events to get started.')}`;
}

async function viewManageEvents() {
  const r = await api('events.php');
  if (!r.ok) return errorH(r.error);
  const isAdmin = roleOf() === 'admin';
  const all = r.data.data || [];
  const list = state.cache.events = isAdmin ? all : all.filter(e => num(e.organiser_id) === session.user.id);
  const today = todayISO();
  return `
    ${roleBannerH(isAdmin ? 'Event management' : 'Your event studio', 'Plan tournaments, publish events and manage ticket inventory.')}
    ${roleMetricsH(roleStatH('Total events',list.length),roleStatH('Upcoming',list.filter(e=>String(e.event_date)>=today).length),roleStatH('Past events',list.filter(e=>String(e.event_date)<today).length))}
    ${pageHead(isAdmin ? 'Manage events' : 'My events', 'Create a new event or manage an existing one.')}
    <form class="inline-form" data-form="addEvent" novalidate>
      <label class="field">Event name<input name="name" required placeholder="Futsal Championship 2026"></label>
      <label class="field">Date<input name="date" type="date" min="${today}" required></label>
      <label class="field">Ticket price (RM)<input name="price" type="number" min="0" step="0.01" required placeholder="0 for a free event"></label>
      <label class="field">Tickets available<input name="tickets" type="number" min="1" step="1" required placeholder="100"></label>
      <button class="btn primary" type="submit">Publish event</button>
      <p class="err" role="alert"></p>
    </form>
    ${list.length ? `<div class="table-wrap"><table class="dt">
      <thead><tr><th>Event</th><th>Date</th><th class="num">Price</th><th>Tickets sold</th><th></th></tr></thead>
      <tbody>${list.map(e => {
        const t = stubTotals(e); const pct = t.total ? Math.min(100, Math.round(t.sold / t.total * 100)) : 0;
        return `<tr>
          <td><strong>${esc(e.event_name)}</strong>${String(e.event_date) < today ? '<span class="cell-sub">Ended</span>' : ''}</td>
          <td>${esc(fmtDate(e.event_date))}</td><td class="num">${esc(money(e.ticket_price, { free: true }))}</td>
          <td>${esc(t.sold)} of ${esc(t.total)}<div class="mini-meter"><i style="width:${pct}%"></i></div></td>
          <td class="actions"><button class="btn sm" data-act="editEvent" data-id="${esc(e.id)}">Edit</button><button class="btn sm danger" data-act="deleteEvent" data-id="${esc(e.id)}">Delete</button></td>
        </tr>`;
      }).join('')}</tbody></table></div>` : emptyH('No events yet', 'Publish your first event with the form above.')}`;
}

async function submitAddEvent(form) {
  const fd = new FormData(form);
  const name = String(fd.get('name') || '').trim(), date = String(fd.get('date') || ''), price = parseFloat(fd.get('price')), tickets = parseInt(fd.get('tickets'), 10);
  if (!name || !date || !(price >= 0) || !(tickets >= 1)) return fail(form, 'Fill in every field. Tickets must be at least 1.');
  if (date < todayISO()) return fail(form, 'Pick today or a later date.');
  const r = await api('events.php', { method: 'POST', body: { event_name: name, organiser_id: session.user.id, event_date: date, ticket_price: price, total_tickets: tickets } });
  if (!r.ok) return fail(form, r.error);
  toast(`${name} published.`);
  route();
}

function openEditEvent(id) {
  const e = state.cache.events.find(x => num(x.id) === num(id));
  if (!e) return;
  openDlg(`
    <form class="dlg-form" data-form="editEvent" data-id="${esc(e.id)}" novalidate>
      <h2>Edit event</h2>
      <label class="field">Event name<input name="name" value="${esc(e.event_name)}" required></label>
      <label class="field">Ticket price (RM)<input name="price" type="number" min="0" step="0.01" value="${esc(num(e.ticket_price).toFixed(2))}" required></label>
      <p class="muted small">The date and ticket count can't be changed after publishing.</p>
      <p class="err" role="alert"></p>
      <div class="dlg-actions"><button type="button" class="btn" data-act="closeDlg">Cancel</button><button type="submit" class="btn primary">Save changes</button></div>
    </form>`);
}

async function submitEditEvent(form) {
  const fd = new FormData(form);
  const name = String(fd.get('name') || '').trim(), price = parseFloat(fd.get('price'));
  if (!name || !(price >= 0)) return fail(form, 'Enter an event name and a ticket price.');
  const r = await api(`events.php?id=${encodeURIComponent(form.dataset.id)}`, { method: 'PUT', body: { event_name: name, ticket_price: price } });
  if (!r.ok) return fail(form, r.error);
  closeDlg(); toast('Event updated.'); route({ soft: true });
}

async function deleteEvent(id) {
  const e = state.cache.events.find(x => num(x.id) === num(id));
  const sold = e ? stubTotals(e).sold : 0;
  const ok = await confirmDlg({
    title: `Delete ${e ? e.event_name : 'this event'}?`,
    body: sold ? `${plural(sold, 'ticket')} already sold. Deleting the event may be blocked by those bookings.` : 'No tickets have been sold, so nobody is affected.',
    ok: 'Delete event', danger: true,
  });
  if (!ok) return;
  const r = await api(`events.php?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
  if (!r.ok) return toast(r.error, 'err');
  toast('Event deleted.'); route({ soft: true });
}

async function viewSales() {
  const [ev, bk] = await Promise.all([api('events.php'), api('bookings.php')]);
  if (!ev.ok) return errorH(ev.error);
  if (!bk.ok) return errorH(bk.error);
  const mineIds = new Set((ev.data.data || []).filter(e => num(e.organiser_id) === session.user.id).map(e => num(e.id)));
  const rows = (bk.data.data || []).filter(b => b.booking_type === 'event' && mineIds.has(num(b.event_id)));
  const live = rows.filter(b => b.status !== 'cancelled');
  const tickets = live.reduce((s, b) => s + num(b.quantity), 0);
  const revenue = rows.filter(b => b.status === 'confirmed').reduce((s, b) => s + num(b.total_price), 0);
  return `
    ${roleBannerH('Ticket sales insights', 'Track your event performance and confirmed sales.')}
    ${pageHead('Sales overview', 'Every booking made for your events.')}
    <div class="stats">
      <div class="stat"><b>${esc(tickets)}</b><span>Tickets sold</span></div>
      <div class="stat"><b>${esc(money(revenue, { whole: true }))}</b><span>Confirmed revenue</span></div>
      <div class="stat ${rows.some(b => b.status === 'pending') ? 'hot' : ''}"><b>${esc(rows.filter(b => b.status === 'pending').length)}</b><span>Waiting for staff to confirm</span></div>
    </div>
    ${rows.length ? `<div class="table-wrap"><table class="dt">
      <thead><tr><th>#</th><th>Event</th><th>Customer</th><th class="num">Tickets</th><th class="num">Total</th><th>Status</th></tr></thead>
      <tbody>${rows.map(b => `<tr><td>#${esc(b.id)}</td><td>${esc(itemName(b))}</td><td>${esc(b.customer_name || 'Customer #' + b.customer_id)}</td>
        <td class="num">${esc(b.quantity)}</td><td class="num">${esc(money(b.total_price))}</td><td>${chipH(b.status)}</td></tr>`).join('')}</tbody>
    </table></div>` : emptyH('No ticket sales yet', 'Bookings for your events will be listed here.')}`;
}

/* =====================================================================
   Admin: overview, users
   ===================================================================== */

async function viewOverview() {
  const [b, p, ev, ve, us] = await Promise.all([api('bookings.php'), api('payments.php'), api('events.php'), api('venues.php'), api('users.php?page=1&limit=500')]);
  for (const r of [b, ev, ve]) if (!r.ok) return errorH(r.error);
  state.cache.bookings = b.data.data || [];
  state.cache.payments = p.ok ? (p.data.data || []) : [];
  const events = ev.data.data || [], venues = ve.data.data || [];
  const pending = state.cache.bookings.filter(x => x.status === 'pending');
  const revenue = state.cache.bookings.filter(x => x.status === 'confirmed').reduce((s, x) => s + num(x.total_price), 0);
  const sold = events.reduce((s, e) => s + num(e.tickets_sold), 0);
  const open = venues.filter(v => num(v.is_available) === 1).length;
  const users = us.ok ? (us.data.data || []).length : '–';

  return `
    ${roleBannerH('Command centre', 'Monitor the platform, manage operations and spot what needs attention.')}
    ${pageHead('Platform overview', 'Live figures from your SportSphere database.')}
    <div class="stats">
      <div class="stat ${pending.length ? 'hot' : ''}"><b>${esc(pending.length)}</b><span>Bookings to confirm</span></div>
      <div class="stat"><b>${esc(money(revenue, { whole: true }))}</b><span>Confirmed revenue</span></div>
      <div class="stat"><b>${esc(sold)}</b><span>Tickets sold</span></div>
      <div class="stat"><b>${esc(open)}/${esc(venues.length)}</b><span>Courts open</span></div>
      <div class="stat"><b>${esc(users)}</b><span>Users</span></div>
    </div>
    <div class="section-title"><h2>Waiting for confirmation</h2><a href="#/bookings" class="small"><strong>All bookings</strong></a></div>
    ${pending.length ? `<div class="table-wrap"><table class="dt">
      <thead><tr><th>#</th><th>Customer</th><th>Booked</th><th>Date</th><th class="num">Total</th><th>Payment</th><th>Status</th><th></th></tr></thead>
      <tbody>${pending.slice(0, 8).map(x => bookingRowH(x, true)).join('')}</tbody></table></div>`
      : emptyH('All caught up', 'No bookings are waiting for confirmation.')}`;
}

async function viewUsers() {
  const r = await api('users.php?page=1&limit=500');
  if (!r.ok) return errorH(r.error);
  const list = state.cache.users = r.data.data || [];
  const roles = ['customer', 'organiser', 'staff', 'admin'];
  return `
    ${roleBannerH('People & access', 'Manage accounts and permissions across the platform.')}
    ${roleMetricsH(roleStatH('Total users',list.length),roleStatH('Customers',list.filter(u=>u.role==='customer').length),roleStatH('Organisers',list.filter(u=>u.role==='organiser').length),roleStatH('Staff & admins',list.filter(u=>['staff','admin'].includes(u.role)).length))}
    ${pageHead('User directory', 'Add accounts and change access roles.')}
    <form class="inline-form" data-form="addUser" novalidate>
      <label class="field">Full name<input name="name" required></label>
      <label class="field">Email<input name="email" type="email" required></label>
      <label class="field">Password<input name="password" type="text" autocomplete="off" required></label>
      <label class="field">Role<select name="role">${roles.map(x => `<option value="${x}">${cap(x)}</option>`).join('')}</select></label>
      <button class="btn primary" type="submit">Add user</button>
      <p class="err" role="alert"></p>
    </form>
    <div class="table-wrap"><table class="dt">
      <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th></th></tr></thead>
      <tbody>${list.map(u => {
        const me = num(u.id) === session.user.id;
        return `<tr><td><strong>${esc(u.name)}</strong>${me ? '<span class="cell-sub">You</span>' : ''}</td><td>${esc(u.email)}</td>
          <td><select data-change="userRole" data-id="${esc(u.id)}" aria-label="Role for ${esc(u.name)}" ${me ? 'disabled' : ''}>${roles.map(x => `<option value="${x}" ${x === u.role ? 'selected' : ''}>${cap(x)}</option>`).join('')}</select></td>
          <td>${esc(fmtDate(u.created_at))}</td>
          <td class="actions">${me ? '' : `<button class="btn sm danger" data-act="deleteUser" data-id="${esc(u.id)}">Delete</button>`}</td></tr>`;
      }).join('')}</tbody></table></div>`;
}

async function submitAddUser(form) {
  const fd = new FormData(form);
  const body = { name: String(fd.get('name') || '').trim(), email: String(fd.get('email') || '').trim(), password: String(fd.get('password') || ''), role: fd.get('role') };
  if (!body.name || !/^\S+@\S+\.\S+$/.test(body.email) || !body.password) return fail(form, 'Enter a name, a valid email and a password.');
  const r = await api('users.php', { method: 'POST', body });
  if (!r.ok) return fail(form, r.error);
  toast(`${body.name} added as ${body.role}.`);
  route();
}

async function changeUserRole(id, role, selectEl) {
  const u = state.cache.users.find(x => num(x.id) === num(id));
  if (!u) return;
  const r = await api(`users.php?id=${encodeURIComponent(id)}`, { method: 'PUT', body: { name: u.name, role } });
  if (!r.ok) { toast(r.error, 'err'); selectEl.value = u.role; return; }
  u.role = role;
  toast(`${u.name} is now ${role}.`);
}

async function deleteUser(id) {
  const u = state.cache.users.find(x => num(x.id) === num(id));
  const ok = await confirmDlg({ title: `Delete ${u ? u.name : 'this user'}?`, body: 'They will no longer be able to sign in. Users with bookings or events may not be deletable.', ok: 'Delete user', danger: true });
  if (!ok) return;
  const r = await api(`users.php?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
  if (!r.ok) return toast(r.error, 'err');
  toast('User deleted.'); route({ soft: true });
}

/* =====================================================================
   Wiring
   ===================================================================== */

async function viewAccountProfile() {
  if (!session?.user?.id) return errorH('Please sign in to view your profile.');
  const r = await api(`users.php?id=${encodeURIComponent(session.user.id)}`);
  if (!r.ok) return errorH(r.error);
  const u = r.data?.data;
  if (!u || Number(u.id) !== Number(session.user.id)) return errorH('Unable to verify your account details.');
  session.user.name = u.name;
  store.set('ss_session', JSON.stringify(session));
  return `<section class="customer-profile">
    <div class="cp-heading"><div class="cp-avatar">${esc((u.name || 'C').charAt(0).toUpperCase())}</div><div><span class="cd-eyebrow">MY ACCOUNT</span><h1>Profile management</h1><p>Account information for your signed-in SportSphere user.</p></div></div>
    <form data-form="accountProfile" class="cp-card">
      <h2>Personal information</h2><p>Your details are loaded from your existing user account.</p>
      <div class="cp-grid"><label>Full name<input name="name" required maxlength="100" minlength="2" value="${esc(u.name || '')}" autocomplete="name"></label><label>Email address<input type="email" value="${esc(u.email || '')}" readonly aria-label="Email address (read only)"></label></div>
      <div class="cp-meta"><span>Account type: <strong>${esc(u.role || session.user.role)}</strong></span><span>Member since: <strong>${esc(fmtDate(u.created_at) || 'Not available')}</strong></span></div>
      <p>Email and password changes are not supported by the existing user API.</p>
      <p class="err" role="alert"></p><button type="submit" class="btn primary">Save name</button>
    </form></section>`;
}
async function submitAccountProfile(f) {
  if (!session?.user?.id || !['customer','organiser','staff','admin'].includes(session.user.role)) return fail(f, 'Please sign in to manage your profile.');
  const name = f.elements.name.value.trim();
  if (name.length < 2) return fail(f, 'Enter a name with at least 2 characters.');
  const r = await api(`users.php?id=${encodeURIComponent(session.user.id)}`, {method:'PUT', body:{name,role:session.user.role}});
  if (!r.ok) return fail(f,r.error);
  session.user.name = name;
  store.set('ss_session', JSON.stringify(session));
  toast('Your name has been updated.');
  route({soft:true});
}

const VIEWS = {
  profile: viewAccountProfile, 'organiser-dashboard': viewOrganiserDashboard, 'staff-dashboard': viewStaffDashboard, dashboard: viewCustomerDashboard, courts: viewCourts, events: viewEvents, 'my-bookings': viewMyBookings,
  bookings: viewBookings, payments: viewPayments, 'manage-courts': viewManageCourts,
  'manage-events': viewManageEvents, sales: viewSales, overview: viewOverview, users: viewUsers,
};
const MOUNT = { bookings: paintBookings, 'my-bookings': paintMyBookings };

const ACTIONS = {
  logout: () => logout(),
  closeDlg: () => closeDlg(),
  reload: () => route(),
  demo: d => { const x = DEMO_LOGINS[+d.i]; const f = $('form[data-form=login]'); f.email.value = x[1]; f.password.value = x[2]; },
  courtCat: d => {
    state.courtCat = d.cat;
    document.querySelectorAll('.chips .filter[data-act="courtCat"]').forEach(btn => {
      btn.setAttribute('aria-pressed', String(btn.dataset.cat === state.courtCat));
    });
    document.querySelectorAll('.courts [data-court-category]').forEach(card => {
      card.hidden = state.courtCat !== 'All' && card.dataset.courtCategory !== state.courtCat;
    });
  },
  book: d => openBooking(d.kind, d.id),
  payNow: d => openPayNow(d.id),
  myBookingTab: d => { myBookingTab = d.tab; paintMyBookings(); },
  myBookingDetails: d => openMyBookingDetails(d.id),
  bkStatus: d => { state.bk.status = d.s; paintBookings(); },
  setStatus: d => setBookingStatus(d.id, d.s),
  deleteBooking: d => deleteBooking(d.id),
  toggleCourt: d => toggleCourt(d.id),
  editCourt: d => openEditCourt(d.id),
  deleteCourt: d => deleteCourt(d.id),
  editEvent: d => openEditEvent(d.id),
  deleteEvent: d => deleteEvent(d.id),
  deleteUser: d => deleteUser(d.id),
};

const FORMS = {
  accountProfile: submitAccountProfile, login: submitLogin, register: submitRegister, book: submitBooking, pay: submitPay,
  addCourt: submitAddCourt, editCourt: submitEditCourt, addEvent: submitAddEvent, editEvent: submitEditEvent, addUser: submitAddUser,
};

document.addEventListener('click', e => {
  const t = e.target.closest('[data-act]');
  if (t && ACTIONS[t.dataset.act]) ACTIONS[t.dataset.act](t.dataset, t);
});

document.addEventListener('submit', async e => {
  const f = e.target.closest('form[data-form]');
  if (!f || !FORMS[f.dataset.form]) return;
  e.preventDefault();
  const btn = $('[type=submit]', f);
  const err = $('.err', f); if (err) err.textContent = '';
  if (btn) btn.disabled = true;
  try { await FORMS[f.dataset.form](f); }
  catch (ex) { fail(f, ex.message || 'Something went wrong.'); }
  finally { if (btn) btn.disabled = false; }
});

document.addEventListener('input', e => {
  if (e.target.dataset.input === 'bkSearch') { state.bk.q = e.target.value; paintBookings(); }
});

document.addEventListener('change', e => {
  if (e.target.dataset.change === 'userRole') changeUserRole(e.target.dataset.id, e.target.value, e.target);
});

// If the QR image service can't be reached, say so instead of showing a broken image.
document.addEventListener('error', e => {
  if (e.target.matches && e.target.matches('img.qr')) {
    e.target.replaceWith(Object.assign(document.createElement('span'), { className: 'qr-fallback', textContent: 'QR image unavailable. Check your connection.' }));
  }
}, true);

window.addEventListener('hashchange', () => { closeDlg(); route(); });

loadSession();
route();
