/* SportSphere frontend – talks to the shared PHP REST API (auth, users, events, venues, bookings, payments) */
// Auto-detects the API folder when the page is opened through Apache (http://localhost/sportsphere/...).
// If your API is somewhere else, replace this with a fixed address, e.g. 'http://localhost/my-folder'
const API_BASE_URL = (() => { const m = location.pathname.match(/^(.*?\/sportsphere)\//i);
  return location.protocol.startsWith('http') && m ? location.origin + m[1] : 'http://localhost/sportsphere'; })();

const $ = (s, r = document) => r.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const rm = n => 'RM ' + Number(n || 0).toFixed(2);
const fdate = d => d ? new Date(d + 'T00:00:00').toLocaleDateString('en-MY', {day:'numeric', month:'short', year:'numeric'}) : '-';
const today = () => new Date().toISOString().slice(0, 10);
const SLOT_KEY = 'ss_time_slots';
const slotStore = () => { try { return JSON.parse(localStorage.getItem(SLOT_KEY) || '{}'); } catch { return {}; } };
const saveSlot = (id, label) => { try { const m = slotStore(); m[id] = label; localStorage.setItem(SLOT_KEY, JSON.stringify(m)); } catch {} };
const slotOf = b => b.time_slot || slotStore()[b.id] || null;
const hh = n => String(n).padStart(2, '0') + ':00';
const slotLabel = (start, hrs) => `${hh(start)} – ${hh(start + hrs)}`;
const START_OPTIONS = Array.from({length: 14}, (_, i) => [i + 8, hh(i + 8)]);   // courts open 08:00 - 23:00
const SPORTS = ['futsal', 'badminton', 'pickleball', 'tennis', 'basketball'];
const sportKey = t => SPORTS.find(k => String(t || '').toLowerCase().includes(k)) || 'default';
// tries images/<sport>.jpg, then .png, .webp, .jpeg; if none exist the gradient fallback is shown
function imgFallback(img) {
  const exts = ['jpg', 'png', 'webp', 'jpeg'], i = +img.dataset.i || 0;
  if (i < exts.length - 1) { img.dataset.i = i + 1; img.src = img.src.replace(/\.\w+$/, '.' + exts[i + 1]); } else img.style.display = 'none';
}
const hoverMedia = (key, fallbackLabel) => `<div class="card-bg"><img src="images/${key}.jpg" alt="" loading="lazy" onerror="imgFallback(this)"></div>
  <span class="sport-tag">${key === 'default' ? fallbackLabel : key[0].toUpperCase() + key.slice(1)}</span>`;
const badge = v => `<span class="badge b-${esc(v)}">${esc(v)}</span>`;

let session = JSON.parse(sessionStorage.getItem('ss_session') || 'null'); // {token, user:{id,name,role}}
let current = null;

/* ---------- API layer (adds JWT, parses JSON, centralised errors) ---------- */
async function api(file, {method = 'GET', body, query} = {}) {
  const url = new URL(`${API_BASE_URL}/${file}.php`);
  Object.entries(query || {}).forEach(([k, v]) => url.searchParams.set(k, v));
  const headers = {'Content-Type': 'application/json'};
  if (session) headers.Authorization = 'Bearer ' + session.token;
  let res;
  try { res = await fetch(url, {method, headers, body: body ? JSON.stringify(body) : undefined}); }
  catch { if (location.protocol === 'file:') throw new Error(`You opened this page as a file (file:///). Open it through Apache instead: http://localhost/sportsphere/frontend/Haziq_frontend/index.html`);
    throw new Error(`Cannot reach the API at ${url.origin}${url.pathname}. Check that Apache is running, open this URL in the browser to test it, and fix API_BASE_URL in app.js.`); }
  let data = {};
  try { data = await res.json(); } catch {}
  if (res.status === 401 && session && file !== 'auth') { toast('Session expired. Please sign in again.', true); logout(); }
  if (!res.ok) throw new Error((data.error || `Request failed (${res.status})`) + (data.fields ? ' – ' + Object.entries(data.fields).map(([k, v]) => `${k}: ${v}`).join(', ') : ''));
  return data;
}

/* ---------- UI helpers ---------- */
function toast(msg, err = false) {
  const t = document.createElement('div');
  t.className = 'toast' + (err ? ' err' : ''); t.textContent = msg;
  $('#toasts').append(t); setTimeout(() => t.remove(), 4500);
}
const skeleton = () => '<div class="skel"></div>'.repeat(3);
const fail = e => `<div class="panel"><p class="msg">${esc(e.message)}</p><button class="btn" data-act="reload">Try again</button></div>`;

function closeModal() { $('#modalRoot').innerHTML = ''; }
/* generic form modal: fields=[{id,label,type,value,options,min,max,step}] */
function modal(title, fields, {submit = 'Save', onSubmit, total} = {}) {
  const inputs = fields.map(f => f.type === 'select'
    ? `<label>${f.label}<select name="${f.id}" required>${f.options.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(f.value) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`
    : `<label>${f.label}<input name="${f.id}" type="${f.type || 'text'}" value="${esc(f.value ?? '')}" ${f.min !== undefined ? `min="${f.min}"` : ''} ${f.max !== undefined ? `max="${f.max}"` : ''} ${f.step ? `step="${f.step}"` : ''} ${f.ro ? 'readonly' : ''} required></label>`).join('');
  $('#modalRoot').innerHTML = `<div class="overlay" data-act="closeModal"><form class="modal stack" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <h3>${esc(title)}</h3>${inputs}${total ? '<div class="total"><span>Total payment</span><b id="mTotal">RM 0.00</b></div>' : ''}
    <p class="msg" id="mMsg"></p><div class="acts"><button type="button" class="btn" data-act="closeModalBtn">Cancel</button><button class="btn primary">${submit}</button></div></form></div>`;
  const form = $('#modalRoot form');
  form.addEventListener('click', e => e.stopPropagation());
  const vals = () => Object.fromEntries(new FormData(form));
  const upd = () => { if (total) $('#mTotal').textContent = rm(total(vals())); };
  form.addEventListener('input', upd); upd();
  form.addEventListener('submit', async e => {
    e.preventDefault(); const b = form.querySelector('.primary'); b.disabled = true;
    try { await onSubmit(vals()); closeModal(); } catch (err) { $('#mMsg').textContent = err.message; b.disabled = false; }
  });
  form.querySelector('input,select')?.focus();
}

/* ---------- Reusable table: search, filter, sort, pagination ---------- */
function mountTable(el, cols, rows, o = {}) {
  const st = {q: '', sort: null, dir: 1, page: 1, f: ''}, size = o.size || 8;
  const val = (c, x) => c.v ? c.v(x) : x[c.k];
  el.innerHTML = `<div class="tbar"><input type="search" placeholder="Search…" aria-label="Search table">
    ${o.filter ? `<select aria-label="Filter"><option value="">All ${o.filter.label}</option>${o.filter.values.map(v => `<option>${v}</option>`).join('')}</select>` : ''}</div>
    <div class="tw"></div><div class="pager"></div>`;
  const draw = () => {
    let r = rows.filter(x => (!st.f || String(x[o.filter.key]) === st.f) &&
      (!st.q || cols.some(c => String(val(c, x) ?? '').toLowerCase().includes(st.q))));
    if (st.sort !== null) {
      const c = cols[st.sort];
      r.sort((a, b) => { const A = val(c, a), B = val(c, b), n = A !== '' && B !== '' && !isNaN(A) && !isNaN(B);
        return (n ? A - B : String(A ?? '').localeCompare(String(B ?? ''))) * st.dir; });
    }
    const pages = Math.max(1, Math.ceil(r.length / size)); st.page = Math.min(st.page, pages);
    const slice = r.slice((st.page - 1) * size, st.page * size);
    $('.tw', el).innerHTML = `<table><thead><tr>${cols.map((c, i) => `<th ${c.ns ? '' : `class="s" data-i="${i}"`}>${c.l}${st.sort === i ? (st.dir > 0 ? ' ▲' : ' ▼') : ''}</th>`).join('')}</tr></thead>
      <tbody>${slice.map(x => `<tr>${cols.map(c => `<td>${c.h ? c.h(x) : esc(c.v ? c.v(x) : x[c.k])}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${cols.length}" class="empty">${o.empty || 'No records found.'}</td></tr>`}</tbody></table>`;
    $('.pager', el).innerHTML = `<span>${r.length} record(s)</span><button class="btn sm" data-p="-1" ${st.page <= 1 ? 'disabled' : ''}>Prev</button><span>Page ${st.page} / ${pages}</span><button class="btn sm" data-p="1" ${st.page >= pages ? 'disabled' : ''}>Next</button>`;
  };
  el.addEventListener('input', e => { if (e.target.type === 'search') { st.q = e.target.value.toLowerCase(); st.page = 1; draw(); } });
  el.addEventListener('change', e => { if (e.target.tagName === 'SELECT') { st.f = e.target.value; st.page = 1; draw(); } });
  el.addEventListener('click', e => {
    const th = e.target.closest('th[data-i]'), p = e.target.closest('[data-p]');
    if (th) { const i = +th.dataset.i; st.dir = st.sort === i ? -st.dir : 1; st.sort = i; draw(); }
    if (p) { st.page += +p.dataset.p; draw(); }
  });
  draw();
}
const qrCell = b => b.qr_code_url ? `<img class="qr" src="${esc(b.qr_code_url)}" alt="QR ticket for booking ${b.id}" data-act="showQR" data-id="${b.id}">` : '<span class="meta">Awaiting confirmation</span>';
const itemName = b => b.booking_type === 'event' ? (b.event_name || 'Event removed') : (b.venue_name || 'Venue removed');

/* ---------- Views ---------- */
const VIEWS = {
  overview: {t: 'Overview', s: 'A snapshot of the platform today.', roles: ['admin', 'organiser', 'staff'], r: vOverview},
  discover: {t: 'Discover', s: 'Browse tournaments and rent courts by the hour.', roles: ['guest', 'customer', 'admin', 'organiser', 'staff'], r: vDiscover},
  mine:     {t: 'My bookings', s: 'Track your bookings, payments and digital QR tickets.', roles: ['customer'], r: vMine},
  events:   {t: 'Manage events', s: 'Publish tournaments and control ticket pricing.', roles: ['admin', 'organiser'], r: vEvents},
  venues:   {t: 'Manage venues', s: 'Register courts and control their availability.', roles: ['admin', 'staff'], r: vVenues},
  bookings: {t: 'Booking verification', s: 'Confirm paid bookings to issue QR tickets, or cancel them.', roles: ['admin', 'staff'], r: vBookings},
  payments: {t: 'Payments', s: 'All payment transactions recorded by the system.', roles: ['admin', 'staff'], r: vPayments},
  users:    {t: 'User accounts', s: 'Create, edit and remove users and assign roles.', roles: ['admin'], r: vUsers},
  profile:  {t: 'My profile', s: 'Your account details and session security.', roles: ['customer', 'admin', 'organiser', 'staff'], r: vProfile},
  help:     {t: 'Help & user manual', s: 'Step-by-step guides for every role, answers to common questions and a live system check.', roles: ['guest', 'customer', 'admin', 'organiser', 'staff'], r: vHelp}
};
const ORDER = ['overview', 'discover', 'mine', 'events', 'venues', 'bookings', 'payments', 'users', 'profile', 'help'];
const NAV_GROUPS = [['Main', ['overview', 'discover', 'mine']], ['Manage', ['events', 'venues', 'bookings', 'payments', 'users']], ['Account', ['profile']], ['Support', ['help']]];
const NAV_LABEL = {overview: 'Overview', discover: 'Discover', mine: 'My bookings', events: 'Events', venues: 'Venues', bookings: 'Verify bookings', payments: 'Payments', users: 'Users', profile: 'My profile', help: 'Help & manual'};
const NAV_ICON = {
  overview: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  discover: '<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/>',
  mine: '<path d="M3 9V7a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v2a3 3 0 0 0 0 6v2a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-2a3 3 0 0 0 0-6zM14 6v12"/>',
  events: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  venues: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M12 5v14M3 12h18"/>',
  bookings: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4h6v3H9zM9 14l2 2 4-4"/>',
  payments: '<rect x="2.5" y="5" width="19" height="14" rx="3"/><path d="M2.5 10h19M6 15h4"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6.5 6.5 0 0 1 3.5 6"/>',
  profile: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 .9-1 1.7M12 17h.01"/>'
};

async function show(id) {
  current = id; const v = VIEWS[id];
  document.querySelectorAll('#nav .nav-i').forEach(b => { const on = b.dataset.view === id; b.classList.toggle('on', on); on ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current'); });
  closeDrawer();
  $('#viewTitle').textContent = v.t; $('#viewSub').textContent = v.s;
  $('.top').hidden = id === 'discover';   // the hero replaces the page title
  $('#content').innerHTML = skeleton();
  try { await v.r($('#content')); } catch (e) { $('#content').innerHTML = fail(e); }
  refreshBadges();
}

async function vOverview(el) {
  const [ev, ve, bk] = await Promise.all([api('events'), api('venues'), api('bookings')]);
  const E = ev.data, V = ve.data, B = bk.data, role = session.user.role;
  const sport = Object.fromEntries(V.map(v => [v.id, v.category])), n = s => B.filter(x => x.status === s).length;
  const rev = B.filter(x => x.status === 'confirmed').reduce((s, x) => s + +x.total_price, 0), pend = n('pending');
  const h = new Date().getHours(), greet = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  const dateStr = new Date().toLocaleDateString('en-MY', {weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'});
  const ic = p => `<svg viewBox="0 0 24 24">${p}</svg>`;
  const stats = [['Events published', E.length, null, '<path d="M3 9V7a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v2a3 3 0 0 0 0 6v2a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-2a3 3 0 0 0 0-6zM14 6v12"/>'],
    ['Courts open', V.filter(v => +v.is_available).length, null, '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M12 5v14M3 12h18"/>'],
    ['Awaiting confirmation', pend, null, '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'],
    ['Confirmed revenue', rev, rm, '<rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/>']];
  const C = 2 * Math.PI * 54, tot = B.length || 1; let off = 0;
  const segs = ['confirmed', 'pending', 'cancelled'].map(s => { const len = n(s) / tot * C;
    const seg = `<circle class="dn-seg ${s}" cx="70" cy="70" r="54" stroke-dasharray="${len} ${C - len}" stroke-dashoffset="${-off}"/>`; off += len; return seg; }).join('');
  const tally = {}; B.forEach(x => { const k = x.booking_type === 'venue' ? (sport[x.venue_id] || 'Court') : 'Events'; tally[k] = (tally[k] || 0) + 1; });
  const sports = Object.entries(tally).sort((a, b) => b[1] - a[1]), top = sports[0]?.[1] || 1;
  const upcoming = E.filter(e => e.event_date >= today()).sort((a, b) => a.event_date.localeCompare(b.event_date)).slice(0, 4);
  const recent = [...B].sort((a, b) => b.id - a.id).slice(0, 6);
  const quick = [[`Review pending${pend ? ` (${pend})` : ''}`, 'bookings'], ['Manage courts', 'venues'], ['Publish an event', 'events'], ['View payments', 'payments'], ['Open customer view', 'discover']].filter(([, v]) => VIEWS[v].roles.includes(role));

  el.innerHTML = `<section class="ov-hero"><div><p class="ov-date">${dateStr}</p><h2>${greet}, ${esc(session.user.name)}</h2>
      <p class="ov-sub">${pend ? `<span class="ov-chip"><i></i>${pend} booking${pend > 1 ? 's' : ''} waiting for confirmation</span>` : 'All bookings are up to date. Nice work!'}</p></div>
      <div class="ov-quick">${quick.map(([l, v]) => `<button class="ov-btn" data-go="${v}">${l}<span>→</span></button>`).join('')}</div></section>
    <div class="ov-stats">${stats.map(([l, , , p], i) => `<div class="ov-stat" style="--i:${i}"><span class="ov-ic">${ic(p)}</span><div><b>0</b><span>${l}</span></div></div>`).join('')}</div>
    <div class="ov-grid">
      <div class="panel ov-card" style="--i:4"><h3>Booking status</h3><div class="ov-donut"><div class="dn-wrap"><svg viewBox="0 0 140 140" class="dn"><circle cx="70" cy="70" r="54" class="dn-bg"/>${segs}</svg><div class="dn-mid"><b>${B.length}</b><span>bookings</span></div></div>
        <ul class="dn-legend">${['confirmed', 'pending', 'cancelled'].map(s => `<li><i class="${s}"></i>${s[0].toUpperCase() + s.slice(1)}<b>${n(s)}</b></li>`).join('')}</ul></div></div>
      <div class="panel ov-card" style="--i:5"><h3>Bookings by sport</h3><div class="pm">${sports.map(([k, c]) => `<div class="pm-row"><span class="pm-name">${esc(k)}</span><div class="pm-bar"><i style="--w:${Math.max(6, c / top * 100)}%"></i></div><b>${c}</b></div>`).join('') || '<p class="meta">No bookings yet.</p>'}</div></div>
      <div class="panel ov-card" style="--i:6"><h3>Upcoming events</h3>${upcoming.map(e => { const pct = Math.min(100, Math.round(e.tickets_sold / e.total_tickets * 100));
        return `<div class="ov-ev"><div class="ov-evd"><b>${new Date(e.event_date + 'T00:00:00').getDate()}</b><span>${new Date(e.event_date + 'T00:00:00').toLocaleDateString('en-MY', {month: 'short'})}</span></div>
          <div class="ov-evm"><strong>${esc(e.event_name)}</strong><div class="ov-prog"><i style="--w:${pct}%"></i></div><small>${e.tickets_sold} / ${e.total_tickets} tickets sold · ${pct}%</small></div></div>`; }).join('') || '<p class="meta">No upcoming events.</p>'}</div>
      <div class="panel ov-card" style="--i:7"><h3>Recent bookings</h3>${recent.map(x => `<div class="ov-act"><span class="ov-av">${esc((x.customer_name || '?')[0].toUpperCase())}</span>
        <div><strong>${esc(x.customer_name || 'Customer')}</strong> <span class="meta">booked</span> ${esc(itemName(x))}<small>${fdate((x.created_at || '').slice(0, 10))} · ${rm(x.total_price)}</small></div>${badge(x.status)}</div>`).join('') || '<p class="meta">No bookings yet.</p>'}</div>
    </div>`;
  el.querySelectorAll('.ov-stat b').forEach((b, i) => countUp(b, stats[i][1], stats[i][2] || (v => Math.round(v))));
  el.addEventListener('click', e => { const g = e.target.closest('[data-go]'); if (g) show(g.dataset.go); });
}

const SPORT_INFO = {
  futsal: 'Fast five-a-side football played on an indoor court. Book a court by the hour and bring your team.',
  badminton: 'A quick racket sport for singles or doubles, played on an indoor court. Reserve a court or watch a tournament.',
  pickleball: 'A friendly mix of tennis, badminton and table tennis, played with a paddle on a compact court.',
  tennis: 'Classic racket sport for singles or doubles. Book a court by the hour.',
  basketball: 'Fast team game on the court. Reserve a court or join a tournament.',
  default: 'Browse the events and courts available for this sport.'
};
function spotlightHtml(c, evs, ves) {
  const k = sportKey(c), open = ves.filter(v => +v.is_available), rates = ves.map(v => +v.hourly_rate);
  const next = evs.filter(e => e.event_date >= today()).sort((x, y) => x.event_date.localeCompare(y.event_date))[0];
  return `<div class="spot-img" data-sport="${k}"><img src="images/${k}.jpg" alt="" onerror="imgFallback(this)"><span class="spot-badge">Selected sport</span></div>
    <div class="spot-body"><h3>${esc(c)}</h3><p>${SPORT_INFO[k] || SPORT_INFO.default}</p>
    <div class="spot-stats"><div><b>${evs.length}</b><span>Events</span></div><div><b>${open.length}/${ves.length}</b><span>Courts open</span></div>
      <div><b>${rates.length ? 'RM ' + Math.min(...rates).toFixed(0) : '-'}</b><span>From / hour</span></div></div>
    ${next ? `<p class="spot-next">Next event: <strong>${esc(next.event_name)}</strong> · ${fdate(next.event_date)}</p>` : ''}
    <div class="spot-acts"><button class="btn primary" data-act="toCourts">View courts</button><button class="btn" data-act="clearSport">Clear filter</button></div></div>`;
}

async function vDiscover(el) {
  const [ev, ve] = await Promise.all([api('events'), api('venues')]);
  window._ev = ev.data; window._ve = ve.data;
  const sports = [...new Set(ve.data.map(v => v.category))];
  el.innerHTML = `<div class="hero-wrap">
      <section class="hero"><img class="hero-img" src="images/hero.jpg" alt="" onerror="imgFallback(this)"><div class="hero-shade"></div>
        <div class="hero-text"><h1>Book Your Game.<br>Own the Court.</h1><p>Reserve courts, join tournaments and get your QR ticket in minutes.</p></div></section>
      <form class="hero-search" id="heroForm" role="search">
        <label>Sport<select id="dc"><option value="">All sports</option>${sports.map(c => `<option>${esc(c)}</option>`).join('')}</select><small>Choose a sport</small></label>
        <label>Search<input type="search" id="dq" placeholder="Event or court name"><small>Futsal, Badminton…</small></label>
        <label>Events from<input type="date" id="dd"><small>Add date</small></label>
        <button class="hero-go" aria-label="Search"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg></button>
      </form></div>
    <div class="results" id="results"><div class="res-main"><h3 class="sec-title" id="evTitle" style="margin-top:0">Tournaments & events</h3><div class="grid" id="evGrid"></div>
    <h3 class="sec-title" id="veTitle">Courts & facilities</h3><div class="grid" id="veGrid"></div></div><aside class="spot" id="spot" hidden aria-live="polite"></aside></div>`;
  const avail = v => badge(+v ? 'yes' : 'no').replace('>yes<', '>Available<').replace('>no<', '>Unavailable<');
  const draw = () => {
    const q = $('#dq').value.toLowerCase(), c = $('#dc').value, d = $('#dd').value;
    const evs = ev.data.filter(e => (!c || e.event_name.toLowerCase().includes(c.toLowerCase())) && (!d || e.event_date >= d) && e.event_name.toLowerCase().includes(q));
    $('#evGrid').innerHTML = evs.map(e => {
      const left = e.total_tickets - e.tickets_sold, past = e.event_date < today(), off = left <= 0 || past;
      const k = sportKey(e.event_name);
      return `<article class="card hov" data-sport="${k}">${hoverMedia(k, 'Event')}<h4>${esc(e.event_name)}</h4><span class="meta">${fdate(e.event_date)}</span>
        <span class="meta">${left > 0 ? left + ' of ' + e.total_tickets + ' tickets left' : 'Sold out'}</span>
        <div class="price">${+e.ticket_price ? rm(e.ticket_price) : 'Free'}</div>
        <button class="btn primary" data-act="bookEvent" data-id="${e.id}" ${off ? 'disabled' : ''}>${past ? 'Event ended' : left <= 0 ? 'Sold out' : 'Book tickets'}</button></article>`;
    }).join('') || '<p class="empty">No events match.</p>';
    const ves = ve.data.filter(v => (!c || v.category === c) && v.venue_name.toLowerCase().includes(q));
    $('#veGrid').innerHTML = ves.map(v => { const k = sportKey(v.category); return `<article class="card hov" data-sport="${k}">${hoverMedia(k, 'Court')}<h4>${esc(v.venue_name)}</h4>
      <span class="meta">${esc(v.category)}</span>${avail(v.is_available)}<div class="price">${rm(v.hourly_rate)} <small class="meta">/ hour</small></div>
      <button class="btn primary" data-act="bookVenue" data-id="${v.id}" ${+v.is_available ? '' : 'disabled'}>Rent court</button></article>`; }).join('') || '<p class="empty">No courts match.</p>';
    const spot = $('#spot');
    $('#results').classList.toggle('has-spot', !!c);
    if (!c) { spot.hidden = true; spot.dataset.c = ''; return; }
    spot.hidden = false; spot.innerHTML = spotlightHtml(c, evs, ves);
    if (spot.dataset.c !== c) { spot.dataset.c = c; spot.classList.remove('in'); void spot.offsetWidth; spot.classList.add('in'); }
  };
  el.addEventListener('input', draw); el.addEventListener('change', draw); draw();
  $('#heroForm').onsubmit = e => { e.preventDefault(); draw(); $('#evTitle').scrollIntoView({behavior: 'smooth', block: 'start'}); };
}

async function placeBooking(payload, amount, method) {
  const b = await api('bookings', {method: 'POST', body: payload});
  await api('payments', {method: 'POST', body: {booking_id: b.booking_id, payment_method: method, amount}});
  toast(`Booking #${b.booking_id} placed and paid (${rm(amount)}). Staff will confirm it to issue your QR ticket.`);
  return b.booking_id;
}
const PAY = [['fpx', 'Online Banking (FPX)'], ['card', 'Credit / Debit Card'], ['e-wallet', 'E-Wallet (TNG / GrabPay)']];

function countUp(el, to, fmt = n => Math.round(n), dur = 900) {
  const t0 = performance.now();
  const step = n => { const k = Math.min(1, (n - t0) / dur); el.textContent = fmt(to * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(step); };
  requestAnimationFrame(step);
}

async function vMine(el) {
  const [bk, ve] = await Promise.all([api('bookings'), api('venues')]);
  const sport = Object.fromEntries(ve.data.map(v => [v.id, v.category]));
  const rows = bk.data.filter(b => +b.customer_id === +session.user.id);
  window._mine = rows; window._bk = rows;
  const isV = x => x.booking_type === 'venue', live = rows.filter(x => x.status !== 'cancelled');
  const stats = [['Total bookings', rows.length, n => Math.round(n)], ['Upcoming', live.filter(x => x.booking_date >= today()).length, n => Math.round(n)],
    ['Confirmed', rows.filter(x => x.status === 'confirmed').length, n => Math.round(n)], ['Total spent', live.reduce((s, x) => s + +x.total_price, 0), rm]];
  const st = {f: '', q: '', sort: 'new'}, count = s => s ? rows.filter(x => x.status === s).length : rows.length;
  el.innerHTML = `<div class="mb-stats">${stats.map(([l], i) => `<div class="mb-stat" style="--i:${i}"><b>0</b><span>${l}</span></div>`).join('')}</div>
    <div class="mb-bar"><div class="mb-pills" role="tablist">${[['', 'All'], ['pending', 'Pending'], ['confirmed', 'Confirmed'], ['cancelled', 'Cancelled']].map(([v, l]) =>
      `<button class="mb-pill ${v === '' ? 'on' : ''}" data-f="${v}">${l} <em>${count(v)}</em></button>`).join('')}</div>
      <input type="search" id="mbq" placeholder="Search by court, event or sport…" aria-label="Search bookings">
      <select id="mbs" aria-label="Sort"><option value="new">Newest first</option><option value="date">Date: soonest</option><option value="price">Price: high to low</option></select></div>
    <div id="mbList" class="mb-list"></div>`;
  el.querySelectorAll('.mb-stat b').forEach((b, i) => countUp(b, stats[i][1], stats[i][2]));

  const card = (x, i) => {
    const v = isV(x), name = itemName(x), sp = v ? (sport[x.venue_id] || 'Court') : 'Event', k = sportKey(v ? sp : x.event_name);
    const d = new Date(x.booking_date + 'T00:00:00'), slot = slotOf(x), cancelled = x.status === 'cancelled';
    return `<article class="tk ${x.status}" style="--i:${i}" data-sport="${k}">
      <div class="tk-stub"><img src="images/${k}.jpg" alt="" onerror="imgFallback(this)">
        <div class="tk-date"><b>${String(d.getDate()).padStart(2, '0')}</b><span>${d.toLocaleDateString('en-MY', {month: 'short'})}</span><small>${d.getFullYear()}</small></div></div>
      <div class="tk-main">
        <div class="tk-top"><span class="tk-sport">${esc(sp)}</span>${badge(x.status)}<span class="tk-id">Booking #${x.id}</span></div>
        <h3>${esc(name)}</h3>
        <div class="tk-meta"><div><i>${v ? 'Time slot' : 'When'}</i><b>${v ? (slot ? esc(slot) : 'Not set') : 'Event day'}</b></div>
          <div><i>${v ? 'Duration' : 'Tickets'}</i><b>${x.quantity} ${v ? 'hr' : 'ticket(s)'}</b></div><div><i>Total</i><b class="tk-price">${rm(x.total_price)}</b></div></div>
        <ol class="tk-steps"><li class="done"><span></span>Placed</li><li class="${cancelled ? 'bad' : x.status === 'confirmed' ? 'done' : 'now'}"><span></span>${cancelled ? 'Cancelled' : 'Confirmed'}</li></ol>
        ${cancelled ? '' : `<div class="tk-acts">${v ? `<button class="btn sm" data-act="editMine" data-id="${x.id}">Edit time</button>` : ''}<button class="btn sm danger" data-act="cancelMine" data-id="${x.id}">Cancel booking</button></div>`}
      </div>
      <div class="tk-qr">${x.qr_code_url ? `<img src="${esc(x.qr_code_url)}" alt="QR ticket for booking ${x.id}" data-act="showQR" data-id="${x.id}" tabindex="0"><small>Tap to enlarge</small>`
        : cancelled ? '<div class="tk-wait"><small>No ticket</small></div>' : '<div class="tk-wait"><span class="pulse"></span><small>Awaiting<br>confirmation</small></div>'}</div>
    </article>`;
  };
  const draw = () => {
    let r = rows.filter(x => (!st.f || x.status === st.f) && (!st.q || [itemName(x), isV(x) ? sport[x.venue_id] : 'event', x.status, x.booking_date].join(' ').toLowerCase().includes(st.q)));
    r = [...r].sort(st.sort === 'date' ? (a, b) => a.booking_date.localeCompare(b.booking_date) : st.sort === 'price' ? (a, b) => b.total_price - a.total_price : (a, b) => b.id - a.id);
    $('#mbList', el).innerHTML = r.map(card).join('') || `<div class="mb-empty"><svg viewBox="0 0 64 64" width="84" height="84" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><rect x="8" y="14" width="48" height="36" rx="6"/><path d="M8 26h48M22 14v-4M42 14v-4M24 40h16"/></svg>
      <h3>${rows.length ? 'No bookings match' : 'No bookings yet'}</h3><p>${rows.length ? 'Try a different filter or search.' : 'Reserve a court or grab event tickets to see them here.'}</p>
      ${rows.length ? '' : '<button class="btn primary" id="mbGo">Browse courts & events</button>'}</div>`;
    const go = $('#mbGo', el); if (go) go.onclick = () => show('discover');
  };
  el.addEventListener('click', e => { const p = e.target.closest('.mb-pill'); if (!p) return;
    el.querySelectorAll('.mb-pill').forEach(x => x.classList.toggle('on', x === p)); st.f = p.dataset.f; draw(); });
  $('#mbq', el).oninput = e => { st.q = e.target.value.toLowerCase(); draw(); };
  $('#mbs', el).onchange = e => { st.sort = e.target.value; draw(); };
  draw();
}

async function vEvents(el) {
  const ev = await api('events'), mine = session.user.role === 'admin' ? ev.data : ev.data.filter(e => +e.organiser_id === +session.user.id);
  el.innerHTML = `<div class="panel"><h3>Publish a new event</h3><form id="f" class="form-row">
    <label>Event name<input name="event_name" required maxlength="150"></label><label>Date<input type="date" name="event_date" min="${today()}" required></label>
    <label>Ticket price (RM)<input type="number" step="0.01" min="0" name="ticket_price" required></label>
    <label>Total tickets<input type="number" min="1" name="total_tickets" required></label><button class="btn primary">Publish event</button></form><p class="msg" id="m"></p></div>
    <div class="panel"><h3>Published events</h3><div id="t"></div></div>`;
  $('#f', el).onsubmit = async e => {
    e.preventDefault(); const d = Object.fromEntries(new FormData(e.target));
    try { await api('events', {method: 'POST', body: {...d, ticket_price: +d.ticket_price, total_tickets: +d.total_tickets, organiser_id: +session.user.id}});
      toast('Event published.'); show('events'); } catch (err) { $('#m', el).textContent = err.message; }
  };
  mountTable($('#t', el), [{l: 'ID', k: 'id'}, {l: 'Event', k: 'event_name'}, {l: 'Date', k: 'event_date', h: x => fdate(x.event_date)},
    {l: 'Price', k: 'ticket_price', h: x => rm(x.ticket_price)}, {l: 'Sold / Total', v: x => x.tickets_sold + ' / ' + x.total_tickets, h: x => `${x.tickets_sold} / ${x.total_tickets}`},
    {l: 'Actions', ns: true, h: x => `<button class="btn sm" data-act="editEvent" data-id="${x.id}">Edit</button><button class="btn sm danger" data-act="delEvent" data-id="${x.id}">Delete</button>`}], mine);
  window._ev = mine;
}

/* Reusable animated card list: stat tiles + filter pills + search + sort (used by venues and booking verification) */
function mountCards(el, o) {
  const st = {f: '', q: '', sort: o.sorts[0][0]}, cnt = v => v === '' ? o.rows.length : o.rows.filter(x => o.pill.get(x) === v).length;
  el.insertAdjacentHTML('beforeend', `<div class="mb-stats">${o.stats.map(([l], i) => `<div class="mb-stat" style="--i:${i}"><b>0</b><span>${l}</span></div>`).join('')}</div>
    <div class="mb-bar"><div class="mb-pills">${o.pill.items.map(([v, l]) => `<button class="mb-pill ${v === '' ? 'on' : ''}" data-f="${esc(v)}">${esc(l)} <em>${cnt(v)}</em></button>`).join('')}</div>
      <input type="search" class="mc-q" placeholder="${o.placeholder}" aria-label="Search"><select class="mc-s" aria-label="Sort">${o.sorts.map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select></div>
    <div class="${o.cls} mc-list"></div>`);
  el.querySelectorAll('.mb-stat b').forEach((b, i) => countUp(b, o.stats[i][1], o.stats[i][2] || (n => Math.round(n))));
  const draw = () => {
    const cmp = o.sorts.find(s => s[0] === st.sort)[2];
    const r = o.rows.filter(x => (!st.f || o.pill.get(x) === st.f) && (!st.q || o.text(x).toLowerCase().includes(st.q))).sort(cmp);
    $('.mc-list', el).innerHTML = r.map(o.card).join('') || `<div class="mb-empty"><h3>${o.empty}</h3><p>Try a different filter or search.</p></div>`;
  };
  el.addEventListener('click', e => { const p = e.target.closest('.mb-pill'); if (!p) return;
    el.querySelectorAll('.mb-pill').forEach(x => x.classList.toggle('on', x === p)); st.f = p.dataset.f; draw(); });
  $('.mc-q', el).oninput = e => { st.q = e.target.value.toLowerCase(); draw(); };
  $('.mc-s', el).onchange = e => { st.sort = e.target.value; draw(); };
  draw();
}

async function vVenues(el) {
  const ve = await api('venues'), isAdmin = session.user.role === 'admin';
  window._ve = ve.data;
  el.innerHTML = `<div class="panel fancy"><div class="fancy-head"><span class="fancy-ic"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></span><div><h3>Register a court / venue</h3><p class="meta">New courts appear instantly in the customer Discover page.</p></div></div>
    <form id="f" class="form-row"><label>Venue name<input name="venue_name" required maxlength="120" placeholder="e.g. Indoor Futsal Court C"></label>
    <label>Sport<select name="category">${['Futsal', 'Badminton', 'Pickleball', 'Tennis', 'Basketball'].map(c => `<option>${c}</option>`).join('')}</select></label>
    <label>Hourly rate (RM)<input type="number" step="0.01" min="1" name="hourly_rate" required placeholder="60.00"></label><button class="btn primary">Register court</button></form><p class="msg" id="m"></p></div>`;
  $('#f', el).onsubmit = async e => {
    e.preventDefault(); const d = Object.fromEntries(new FormData(e.target));
    try { await api('venues', {method: 'POST', body: {...d, hourly_rate: +d.hourly_rate}}); toast('Venue registered.'); show('venues'); }
    catch (err) { $('#m', el).textContent = err.message; }
  };
  const rates = ve.data.map(v => +v.hourly_rate), sports = [...new Set(ve.data.map(v => v.category))];
  mountCards(el, {rows: ve.data, cls: 'vn-grid', placeholder: 'Search courts…', empty: 'No courts found',
    stats: [['Total courts', ve.data.length], ['Open for booking', ve.data.filter(v => +v.is_available).length], ['Sports offered', sports.length], ['Average rate / hr', rates.length ? rates.reduce((s, n) => s + n, 0) / rates.length : 0, rm]],
    pill: {get: x => x.category, items: [['', 'All'], ...sports.map(s => [s, s])]},
    sorts: [['id', 'Oldest first', (a, b) => a.id - b.id], ['rate', 'Rate: high to low', (a, b) => b.hourly_rate - a.hourly_rate], ['name', 'Name A–Z', (a, b) => a.venue_name.localeCompare(b.venue_name)]],
    text: x => `${x.venue_name} ${x.category}`,
    card: (x, i) => { const k = sportKey(x.category), on = +x.is_available;
      return `<article class="vn ${on ? '' : 'off'}" style="--i:${i}" data-sport="${k}"><div class="vn-top"><img src="images/${k}.jpg" alt="" onerror="imgFallback(this)"><span class="vn-sport">${esc(x.category)}</span><span class="vn-id">#${x.id}</span></div>
        <div class="vn-body"><h3>${esc(x.venue_name)}</h3><div class="vn-rate"><b>${rm(x.hourly_rate)}</b><span>/ hour</span></div>
        <div class="vn-row"><button class="sw ${on ? 'on' : ''}" role="switch" aria-checked="${!!on}" aria-label="Toggle availability" data-act="toggleVenue" data-id="${x.id}"><i></i></button><span>${on ? 'Open for booking' : 'Unavailable'}</span></div>
        <div class="vn-acts"><button class="btn sm" data-act="editVenue" data-id="${x.id}">Edit</button>${isAdmin ? `<button class="btn sm danger" data-act="delVenue" data-id="${x.id}">Delete</button>` : ''}</div></div></article>`; }});
}

async function vBookings(el) {
  const [bk, ve] = await Promise.all([api('bookings'), api('venues')]), isAdmin = session.user.role === 'admin';
  const sport = Object.fromEntries(ve.data.map(v => [v.id, v.category])), rows = bk.data;
  window._bk = rows; el.innerHTML = '';
  const money = rows.filter(x => x.status === 'confirmed').reduce((s, x) => s + +x.total_price, 0), n = s => rows.filter(x => x.status === s).length;
  const rank = {pending: 0, confirmed: 1, cancelled: 2};
  mountCards(el, {rows, cls: 'bk-list', placeholder: 'Search customer, court or event…', empty: 'No bookings found',
    stats: [['Needs action', n('pending')], ['Confirmed', n('confirmed')], ['Cancelled', n('cancelled')], ['Confirmed revenue', money, rm]],
    pill: {get: x => x.status, items: [['', 'All'], ['pending', 'Pending'], ['confirmed', 'Confirmed'], ['cancelled', 'Cancelled']]},
    sorts: [['queue', 'Pending first', (a, b) => rank[a.status] - rank[b.status] || b.id - a.id], ['new', 'Newest first', (a, b) => b.id - a.id], ['date', 'Date: soonest', (a, b) => a.booking_date.localeCompare(b.booking_date)], ['price', 'Price: high to low', (a, b) => b.total_price - a.total_price]],
    text: x => `${x.customer_name} ${itemName(x)} ${x.status} ${x.booking_date}`,
    card: (x, i) => { const v = x.booking_type === 'venue', sp = v ? (sport[x.venue_id] || 'Court') : 'Event', k = sportKey(v ? sp : x.event_name);
      return `<article class="bk ${x.status}" style="--i:${i}" data-sport="${k}"><div class="bk-av">${esc((x.customer_name || '?')[0].toUpperCase())}</div>
        <div class="bk-main"><div class="bk-top"><strong>${esc(x.customer_name || 'Unknown customer')}</strong>${badge(x.status)}<span class="bk-id">#${x.id}</span></div>
          <div class="bk-item"><span class="bk-sp">${esc(sp)}</span>${esc(itemName(x))}</div>
          <div class="bk-meta"><span>${fdate(x.booking_date)}</span><span>${x.quantity} ${v ? 'hr' : 'ticket(s)'}</span><b>${rm(x.total_price)}</b></div></div>
        <div class="bk-qr">${x.qr_code_url ? `<img src="${esc(x.qr_code_url)}" alt="QR for booking ${x.id}" data-act="showQR" data-id="${x.id}" tabindex="0">` : x.status === 'pending' ? '<span class="pulse sm"></span><small>Awaiting<br>confirmation</small>' : '<small>No ticket</small>'}</div>
        <div class="bk-acts">${x.status !== 'confirmed' ? `<button class="btn primary" data-act="setStatus" data-s="confirmed" data-id="${x.id}">✓ Confirm</button>` : ''}${x.status !== 'cancelled' ? `<button class="btn" data-act="setStatus" data-s="cancelled" data-id="${x.id}">Cancel</button>` : ''}${isAdmin ? `<button class="btn danger" data-act="delBooking" data-id="${x.id}">Delete</button>` : ''}</div></article>`; }});
}

async function vPayments(el) {
  const p = await api('payments'), rows = p.data, done = rows.filter(x => x.payment_status === 'completed');
  const total = done.reduce((s, x) => s + +x.amount, 0), by = Object.fromEntries(Object.keys(PAY_UI).map(m => [m, done.filter(x => x.payment_method === m).reduce((s, x) => s + +x.amount, 0)]));
  const stats = [['Total received', total, rm], ['Transactions', rows.length], ['Completed', done.length], ['Average payment', done.length ? total / done.length : 0, rm]];
  const icon = m => `<svg viewBox="0 0 24 24">${PAY_UI[m][2]}</svg>`;
  el.innerHTML = `<div class="mb-stats">${stats.map(([l], i) => `<div class="mb-stat" style="--i:${i}"><b>0</b><span>${l}</span></div>`).join('')}</div>
    <div class="panel"><h3>Revenue by payment method</h3><div class="pm">${Object.entries(by).map(([m, v]) => `<div class="pm-row"><span class="pm-name">${icon(m)}${PAY_UI[m][0]}</span>
      <div class="pm-bar"><i style="--w:${total ? Math.max(3, v / total * 100) : 0}%"></i></div><b>${rm(v)}</b></div>`).join('')}</div></div>
    <div class="panel"><h3>All transactions</h3><div id="t"></div></div>`;
  el.querySelectorAll('.mb-stat b').forEach((b, i) => countUp(b, stats[i][1], stats[i][2] || (n => Math.round(n))));
  mountTable($('#t', el), [{l: 'ID', k: 'id'}, {l: 'Booking', k: 'booking_id', h: x => '#' + esc(x.booking_id)}, {l: 'Reference', k: 'transaction_ref', h: x => `<code class="ref">${esc(x.transaction_ref)}</code>`},
    {l: 'Method', k: 'payment_method', h: x => `<span class="mchip">${PAY_UI[x.payment_method] ? icon(x.payment_method) : ''}${esc(PAY_UI[x.payment_method]?.[0] || x.payment_method)}</span>`},
    {l: 'Amount', k: 'amount', h: x => `<strong>${rm(x.amount)}</strong>`}, {l: 'Status', k: 'payment_status', h: x => badge(x.payment_status)},
    {l: 'Paid at', k: 'created_at', h: x => esc(String(x.created_at).replace('T', ' ').slice(0, 16))}],
    rows, {filter: {key: 'payment_status', label: 'statuses', values: ['pending', 'completed', 'failed']}});
}

const ROLES = ['admin', 'organiser', 'staff', 'customer'];
async function vUsers(el) {
  const u = await api('users', {query: {page: 1, limit: 100}});
  el.innerHTML = `<div class="panel"><h3>Add a user</h3><form id="f" class="form-row">
    <label>Full name<input name="name" required></label><label>Email<input type="email" name="email" required></label>
    <label>Password<input type="password" name="password" minlength="6" required></label>
    <label>Role<select name="role">${ROLES.map(r => `<option>${r}</option>`).join('')}</select></label><button class="btn primary">Create user</button></form><p class="msg" id="m"></p></div>
    <div class="panel"><h3>All users</h3><div id="t"></div></div>`;
  $('#f', el).onsubmit = async e => {
    e.preventDefault();
    try { await api('users', {method: 'POST', body: Object.fromEntries(new FormData(e.target))}); toast('User created.'); show('users'); }
    catch (err) { $('#m', el).textContent = err.message; }
  };
  mountTable($('#t', el), [{l: 'ID', k: 'id'}, {l: 'Name', k: 'name'}, {l: 'Email', k: 'email'}, {l: 'Role', k: 'role', h: x => `<span class="badge b-role">${esc(x.role)}</span>`},
    {l: 'Joined', k: 'created_at'}, {l: 'Actions', ns: true, h: x => `<button class="btn sm" data-act="editUser" data-id="${x.id}">Edit</button>${+x.id !== +session.user.id ? `<button class="btn sm danger" data-act="delUser" data-id="${x.id}">Delete</button>` : ''}`}],
    u.data, {filter: {key: 'role', label: 'roles', values: ROLES}});
  window._us = u.data;
}

/* ---------- Animated checkout (used for ticket + court bookings) ---------- */
const PAY_UI = {
  fpx: ['FPX', 'Online banking', '<path d="M3 10l9-6 9 6M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 20h18"/>'],
  card: ['Card', 'Credit / Debit', '<rect x="2.5" y="5" width="19" height="14" rx="3"/><path d="M2.5 10h19M6 15h4"/>'],
  'e-wallet': ['E-Wallet', 'TNG / GrabPay', '<path d="M4 7h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h11"/><circle cx="16.5" cy="13.5" r="1.2"/>']
};
function checkout(o) {
  // o: {title, sub, sport, price, unit, qtyLabel, qtyMax, extra:[{id,label,type,value,min,options}], onPay({qty,method,vals}) -> extra receipt rows}
  const extra = (o.extra || []).map(f => f.type === 'select'
    ? `<label>${f.label}<select name="${f.id}">${f.options.map(([v, l]) => `<option value="${v}" ${String(v) === String(f.value) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`
    : `<label>${f.label}<input name="${f.id}" type="${f.type}" value="${esc(f.value)}" ${f.min ? `min="${f.min}"` : ''} required></label>`).join('');
  $('#modalRoot').innerHTML = `<div class="overlay" data-act="closeModal"><div class="modal co" role="dialog" aria-modal="true" aria-label="Checkout">
    <div class="co-head" data-sport="${o.sport}"><span class="co-tag">${esc(o.tag)}</span><h3>${esc(o.title)}</h3><p>${esc(o.sub)}</p></div>
    <form class="co-body">
      ${extra ? `<div class="co-extra">${extra}</div>` : ''}
      <div class="co-qty"><span>${o.qtyLabel}</span><div class="stepper"><button type="button" data-d="-1" aria-label="Decrease">−</button><output id="coQ">1</output><button type="button" data-d="1" aria-label="Increase">+</button></div></div>
      <div><div class="co-sec">Payment method</div><div class="pay-grid">${PAY.map(([v], i) => `<label class="pay-card"><input type="radio" name="method" value="${v}" ${i ? '' : 'checked'}>
        <svg viewBox="0 0 24 24">${PAY_UI[v][2]}</svg><span>${PAY_UI[v][0]}</span><small>${PAY_UI[v][1]}</small></label>`).join('')}</div></div>
      <div class="co-sum"><div><small>Price</small><div id="coLine"></div></div><div class="co-total"><small>Total</small><b id="coT">RM 0.00</b></div></div>
      <p class="msg" id="mMsg"></p><p class="co-note">Demo checkout – no real payment is taken.</p>
      <div class="acts"><button type="button" class="btn" data-act="closeModalBtn">Cancel</button><button class="btn primary co-pay"><span>Pay & book</span></button></div>
    </form></div></div>`;
  const box = $('#modalRoot .co'), form = $('form', box), [minus, plus] = form.querySelectorAll('.stepper button');
  let qty = 1, shown = 0;
  const setTotal = to => { const from = shown, t0 = performance.now();
    const step = n => { const k = Math.min(1, (n - t0) / 350); shown = from + (to - from) * (1 - Math.pow(1 - k, 3)); $('#coT').textContent = rm(shown); if (k < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step); };
  const update = () => { $('#coQ').textContent = qty; $('#coQ').classList.remove('pop'); void $('#coQ').offsetWidth; $('#coQ').classList.add('pop');
    minus.disabled = qty <= 1; plus.disabled = qty >= o.qtyMax;
    $('#coLine').textContent = `${rm(o.price)} × ${qty} ${o.unit}${qty > 1 ? 's' : ''}`; setTotal(o.price * qty); };
  form.querySelector('.stepper').addEventListener('click', e => { const b = e.target.closest('[data-d]'); if (!b) return; qty = Math.min(o.qtyMax, Math.max(1, qty + +b.dataset.d)); update(); });
  update();
  form.onsubmit = async e => {
    e.preventDefault(); const btn = $('.co-pay', form), vals = Object.fromEntries(new FormData(form)); $('#mMsg').textContent = '';
    btn.disabled = true; btn.classList.add('loading');
    try {
      const rows = await o.onPay({qty, method: vals.method, vals}) || [];
      box.innerHTML = `<div class="co-ok"><svg class="tick" viewBox="0 0 52 52"><circle class="tick-c" cx="26" cy="26" r="24"/><path class="tick-p" d="M14 27l8 8 16-17"/></svg>
        <h3>Booking placed!</h3><p class="meta">Payment received. Staff will confirm it to issue your QR ticket.</p>
        <div class="co-receipt"><div><span>Reservation</span><b>${esc(o.title)}</b></div>${rows.map(([l, v]) => `<div><span>${esc(l)}</span><b>${esc(v)}</b></div>`).join('')}
        <div><span>Quantity</span><b>${qty} ${o.unit}${qty > 1 ? 's' : ''}</b></div><div><span>Paid with</span><b>${PAY_UI[vals.method][0]}</b></div><div class="rc-total"><span>Total paid</span><b>${rm(o.price * qty)}</b></div></div>
        <div class="acts"><button class="btn" data-act="doneBooking">Done</button><button class="btn primary" data-act="goMine">View my bookings</button></div></div>`;
    } catch (err) {
      $('#mMsg').textContent = err.message; btn.disabled = false; btn.classList.remove('loading');
      box.classList.remove('shake'); void box.offsetWidth; box.classList.add('shake');
    }
  };
}

/* ---------- Actions (event-delegated via data-act) ---------- */
const find = (list, id) => (list || []).find(x => +x.id === +id);
const A = {
  reload: () => show(current),
  toggleVenue: async id => { const x = find(window._ve, id);
    try { await api('venues', {method: 'PUT', query: {id}, body: {venue_name: x.venue_name, hourly_rate: +x.hourly_rate, is_available: +x.is_available ? 0 : 1}}); toast(+x.is_available ? 'Court marked unavailable.' : 'Court is open for booking.'); show('venues'); }
    catch (e) { toast(e.message, true); } },
  doneBooking: () => { closeModal(); show(current); },
  goMine: () => { closeModal(); if (VIEWS.mine.roles.includes(session.user.role)) show('mine'); else show(current); },
  toCourts: () => $('#veTitle').scrollIntoView({behavior: 'smooth', block: 'start'}),
  clearSport: () => { const s = $('#dc'); s.value = ''; s.dispatchEvent(new Event('change', {bubbles: true})); },
  closeModal: e => { if (e.target.classList.contains('overlay')) closeModal(); },
  closeModalBtn: closeModal,
  showQR: (id, b) => { const x = find(window._bk, id); const src = b.src;
    $('#modalRoot').innerHTML = `<div class="overlay" data-act="closeModal"><div class="modal" style="text-align:center"><h3>Digital ticket #${id}</h3><img src="${esc(src)}" alt="QR code" style="width:240px;height:240px"><p class="meta" style="margin:10px 0">Show this QR code at the entrance.</p><button class="btn primary" data-act="closeModalBtn">Close</button></div></div>`; },

  bookEvent: id => { if (!session) return authModal('Please sign in to book tickets.');
    const e = find(window._ev, id), left = e.total_tickets - e.tickets_sold;
    checkout({title: e.event_name, tag: 'Event', sub: fdate(e.event_date), sport: sportKey(e.event_name), price: +e.ticket_price, unit: 'ticket', qtyLabel: `Tickets <small class="meta">(${left} left)</small>`, qtyMax: Math.min(left, 20),
      onPay: async ({qty, method}) => { await placeBooking({customer_id: +session.user.id, booking_type: 'event', event_id: +e.id, booking_date: e.event_date, quantity: qty, status: 'pending'}, e.ticket_price * qty, method);
        return [['Date', fdate(e.event_date)]]; }}); },
  bookVenue: id => { if (!session) return authModal('Please sign in to rent a court.');
    const x = find(window._ve, id);
    checkout({title: x.venue_name, tag: x.category, sub: `${rm(x.hourly_rate)} per hour`, sport: sportKey(x.category), price: +x.hourly_rate, unit: 'hour', qtyLabel: 'Hours', qtyMax: 12,
      extra: [{id: 'date', label: 'Date', type: 'date', min: today(), value: today()}, {id: 'start', label: 'Preferred start time', type: 'select', value: 18, options: START_OPTIONS}],
      onPay: async ({qty, method, vals}) => {
        const start = +vals.start, label = slotLabel(start, qty);
        if (start + qty > 23) throw new Error('Courts close at 23:00. Choose an earlier start time or fewer hours.');
        if (vals.date < today()) throw new Error('Please choose today or a future date.');
        const bid = await placeBooking({customer_id: +session.user.id, booking_type: 'venue', venue_id: +x.id, booking_date: vals.date, quantity: qty, status: 'pending', time_slot: label}, x.hourly_rate * qty, method);
        saveSlot(bid, label); return [['Date', fdate(vals.date)], ['Time slot', label]]; }}); },
  editMine: id => { const b = find(window._mine, id);
    if (!b || b.booking_type !== 'venue') return toast('Event tickets cannot be rescheduled. Cancel and book again.', true);
    const cur = parseInt((slotOf(b) || '18').slice(0, 2), 10) || 18;
    modal('Change time slot – ' + itemName(b), [{id: 'info', label: 'Date and hours', value: `${fdate(b.booking_date)} · ${b.quantity} hour(s)`, ro: true},
      {id: 'start', label: 'New start time', type: 'select', value: cur, options: START_OPTIONS}],
      {submit: 'Save time slot', onSubmit: async v => {
        if (+v.start + +b.quantity > 23) throw new Error('Courts close at 23:00. Choose an earlier start time.');
        saveSlot(b.id, slotLabel(+v.start, +b.quantity)); toast('Time slot updated.'); show('mine'); }}); },
  cancelMine: async id => { if (!confirm('Cancel this booking? This cannot be undone.')) return;
    try { await api('bookings', {method: 'PUT', query: {id}, body: {status: 'cancelled'}}); toast('Booking cancelled.'); show('mine'); }
    catch (e) { toast(/forbidden/i.test(e.message) ? 'The server only lets staff cancel bookings. Ask staff to cancel it, or enable customer cancellation in bookings.php.' : e.message, true); } },
  editEvent: id => { const e = find(window._ev, id);
    modal('Edit event', [{id: 'event_name', label: 'Event name', value: e.event_name}, {id: 'ticket_price', label: 'Ticket price (RM)', type: 'number', step: '0.01', min: 0, value: e.ticket_price}],
      {onSubmit: async v => { await api('events', {method: 'PUT', query: {id}, body: {event_name: v.event_name, ticket_price: +v.ticket_price}}); toast('Event updated.'); show('events'); }}); },
  delEvent: async id => { if (!confirm('Cancel and delete this event?')) return;
    try { await api('events', {method: 'DELETE', query: {id}}); toast('Event deleted.'); show('events'); } catch (e) { toast(e.message, true); } },

  editVenue: id => { const x = find(window._ve, id);
    modal('Edit venue', [{id: 'venue_name', label: 'Venue name', value: x.venue_name}, {id: 'hourly_rate', label: 'Hourly rate (RM)', type: 'number', step: '0.01', min: 1, value: x.hourly_rate},
      {id: 'is_available', label: 'Availability', type: 'select', value: +x.is_available, options: [[1, 'Available'], [0, 'Unavailable']]}],
      {onSubmit: async v => { await api('venues', {method: 'PUT', query: {id}, body: {venue_name: v.venue_name, hourly_rate: +v.hourly_rate, is_available: +v.is_available}}); toast('Venue updated.'); show('venues'); }}); },
  delVenue: async id => { if (!confirm('Delete this venue?')) return;
    try { await api('venues', {method: 'DELETE', query: {id}}); toast('Venue deleted.'); show('venues'); } catch (e) { toast(e.message, true); } },

  setStatus: async (id, b) => {
    try { await api('bookings', {method: 'PUT', query: {id}, body: {status: b.dataset.s}}); toast(b.dataset.s === 'confirmed' ? 'Booking confirmed. QR ticket generated.' : 'Booking updated.'); show('bookings'); }
    catch (e) { toast(e.message, true); } },
  delBooking: async id => { if (!confirm('Permanently delete this booking?')) return;
    try { await api('bookings', {method: 'DELETE', query: {id}}); toast('Booking deleted.'); show('bookings'); } catch (e) { toast(e.message, true); } },

  editUser: id => { const u = find(window._us, id);
    modal('Edit user', [{id: 'name', label: 'Full name', value: u.name}, {id: 'role', label: 'Role', type: 'select', value: u.role, options: ROLES.map(r => [r, r])}],
      {onSubmit: async v => { await api('users', {method: 'PUT', query: {id}, body: v}); toast('User updated.'); show('users'); }}); },
  delUser: async id => { if (!confirm('Delete this user and their bookings?')) return;
    try { await api('users', {method: 'DELETE', query: {id}}); toast('User deleted.'); show('users'); } catch (e) { toast(e.message, true); } }
};
document.addEventListener('click', e => {
  const b = e.target.closest('[data-act]'); if (!b || !A[b.dataset.act]) return;
  if (b.dataset.act === 'closeModal') return A.closeModal(e);
  A[b.dataset.act](b.dataset.id, b.dataset.act === 'showQR' ? {src: b.src} : b);
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });


/* ---------- Auth (sidebar button -> modal) & bootstrap ---------- */
/* ---------- My profile ---------- */
async function vProfile(el) {
  const u = (await api('users', {query: {id: session.user.id}})).data, role = session.user.role, exp = jwtExp();
  const left = exp ? Math.max(0, exp - Date.now()) : 0, pct = Math.min(100, left / (5 * 3600e3) * 100);
  const item = (l, v) => `<div class="pf-item"><span>${l}</span><b>${v}</b></div>`;
  el.innerHTML = `<section class="pf-hero"><div class="pf-av role-${esc(role)}">${esc((u.name || '?')[0].toUpperCase())}</div>
      <div><h3>${esc(u.name)}</h3><span class="pill role-${esc(role)}">${esc(role)}</span><p>${esc(u.email)}</p></div></section>
    <div class="pf-grid">${item('User ID', '#' + esc(u.id))}${item('Role', esc(role))}${item('Member since', fdate((u.created_at || '').slice(0, 10)))}${item('Session ends', exp ? new Date(exp).toLocaleTimeString('en-MY', {hour: '2-digit', minute: '2-digit'}) : '-')}</div>
    <div class="ov-grid"><section class="panel"><h3>Edit display name</h3><form id="pf" class="stack"><label>Full name<input name="name" value="${esc(u.name)}" required maxlength="100"></label>
      <button class="btn primary">Save name</button></form><p class="msg" id="m"></p><p class="meta">Email, password and role cannot be changed from this page.</p></section>
    <section class="panel"><h3>Session security</h3><p class="meta">You stay signed in for 5 hours after logging in. The sign-in token is kept only for this browser tab and is removed when you sign out or close the tab.</p>
      <div class="sess-meter"><i style="width:${pct}%"></i></div><p><b>${Math.floor(left / 3600000)}h ${Math.floor(left % 3600000 / 60000)}m</b> left</p><button class="btn danger" id="pfOut">Sign out now</button></section></div>`;
  $('#pfOut', el).onclick = logout;
  $('#pf', el).onsubmit = async e => {
    e.preventDefault(); const name = new FormData(e.target).get('name').trim();
    if (name.length < 2) return ($('#m', el).textContent = 'Please enter at least 2 characters.');
    if (name === u.name) return ($('#m', el).textContent = 'That is already your name.');
    try { await api('users', {method: 'PUT', query: {id: u.id}, body: {name, role: u.role}});
      session.user.name = name; sessionStorage.setItem('ss_session', JSON.stringify(session)); renderUserCard(); toast('Name updated.'); show('profile'); }
    catch (err) { $('#m', el).textContent = err.message; }
  };
}

/* ---------- Help & user manual ---------- */
const HELP = {
  guest: ['Guest', 'You can browse every court and event without an account. Sign in when you are ready to book.', [
    ['Browse courts and events', ['Open <b>Discover</b> from the sidebar.', 'Use the search bar, the sport filter or the date to narrow the list.', 'Pick a sport to see the sport panel with prices and the next event.']],
    ['Create an account', ['Click <b>Create account</b> in the sidebar.', 'Enter your name, a valid email and a password of at least 6 characters.', 'You are signed in automatically as a customer.']],
    ['Why am I asked to sign in?', ['Booking needs an account, so the sign-in window opens when you press <b>Book tickets</b> or <b>Rent court</b>.']]]],
  customer: ['Customer', 'Book courts and event tickets, pay online and keep your digital QR tickets.', [
    ['Book a court', ['Open <b>Discover</b> and choose a sport.', 'Press <b>Rent court</b> on an available court.', 'Choose the date, your preferred start time, the number of hours and a payment method.', 'Press <b>Pay & book</b>. The booking is <i>pending</i> until staff confirm it.']],
    ['Buy event tickets', ['Open <b>Discover</b> and press <b>Book tickets</b> on an event.', 'Use + and − to choose how many tickets (up to the tickets left).', 'Choose a payment method and press <b>Pay & book</b>.']],
    ['Find your QR ticket', ['Open <b>My bookings</b>.', 'When a booking shows <b>Confirmed</b>, its QR code appears on the right of the ticket.', 'Click the QR code to enlarge it and show it at the entrance.']],
    ['Change your time slot', ['Open <b>My bookings</b> and press <b>Edit time</b> on a court booking.', 'Choose a new start time and save. The slot is saved on this browser.']],
    ['Cancel a booking', ['Open <b>My bookings</b> and press <b>Cancel booking</b>.', 'If a message says only staff can cancel, please ask the venue staff to cancel it for you.']]]],
  staff: ['Staff', 'Run the courts, verify bookings and watch payments.', [
    ['Verify a booking', ['Open <b>Verify bookings</b>. Pending bookings are listed first.', 'Press <b>Confirm</b> to approve a booking. A QR ticket is created automatically.', 'Press <b>Cancel</b> to reject a booking.']],
    ['Register a court', ['Open <b>Venues</b>.', 'Fill in the name, sport and hourly rate, then press <b>Register court</b>.']],
    ['Close or open a court', ['Open <b>Venues</b> and use the switch on a court card.', 'A closed court cannot be booked by customers.']],
    ['Check payments', ['Open <b>Payments</b> to see every transaction and the revenue by payment method.']]]],
  organiser: ['Organiser', 'Publish tournaments and follow your ticket sales.', [
    ['Publish an event', ['Open <b>Events</b>.', 'Enter the event name, date, ticket price and total tickets, then press <b>Publish event</b>.']],
    ['Change or remove an event', ['In the events table press <b>Edit</b> to change the name or the ticket price.', 'Press <b>Delete</b> to remove the event.']],
    ['Follow ticket sales', ['The <b>Sold / Total</b> column shows how many tickets are booked.', 'The <b>Overview</b> page shows upcoming events with a progress bar.']]]],
  admin: ['Administrator', 'Full control of users, venues, events, bookings and payments.', [
    ['Manage users', ['Open <b>Users</b>.', 'Add a user and choose the role, or press <b>Edit</b> to rename a user or change the role.', 'Press <b>Delete</b> to remove an account.']],
    ['Manage venues and events', ['Use <b>Venues</b> and <b>Events</b> to register, edit or delete. Only administrators can delete venues.']],
    ['Verify or delete bookings', ['Open <b>Verify bookings</b> to confirm or cancel. Only administrators see the <b>Delete</b> button.']],
    ['Read the dashboard', ['<b>Overview</b> shows booking status, bookings by sport, upcoming events and recent bookings.']]]]
};
const FAQ = [
  ['Why is my booking still pending?', 'A staff member must confirm the booking after the payment. Your QR ticket appears as soon as it is confirmed.'],
  ['I cannot cancel my booking.', 'Under the current server rules only staff and administrators can cancel bookings. Ask the venue staff to cancel it.'],
  ['Where is my preferred time slot saved?', 'In this browser only. It is not stored in the server database, so it will not show on another device.'],
  ['I was signed out suddenly.', 'A session lasts 5 hours. Sign in again to continue.'],
  ['The page says it cannot reach the API.', 'Start Apache and MySQL in XAMPP, then open the site through http://localhost/ instead of opening the file directly.']
];
const RIGHTS = [['Browse courts and events', 1, 1, 1, 1, 1], ['Book courts and tickets', 0, 1, 1, 1, 1], ['View own bookings and QR', 0, 1, 0, 0, 0], ['Confirm or cancel bookings', 0, 0, 1, 0, 1],
  ['Manage venues', 0, 0, 1, 0, 1], ['Manage events', 0, 0, 0, 1, 1], ['View payments', 0, 0, 1, 0, 1], ['Manage users', 0, 0, 0, 0, 1], ['Delete venues, bookings and users', 0, 0, 0, 0, 1]];

async function vHelp(el) {
  const mine = session?.user.role || 'guest'; let tab = mine, q = '';
  const roleKeys = ['guest', 'customer', 'staff', 'organiser', 'admin'], ok = '<span class="yes">✓</span>', no = '<span class="no">–</span>';
  el.innerHTML = `<section class="hp-hero"><div><h2>How can we help?</h2><p>Search the manual, or pick your role to see step-by-step guides.</p></div>
      <input type="search" id="hq" placeholder="Search the manual…" aria-label="Search the manual"></section>
    <div class="hp-quick"><button class="hp-q" data-go="discover"><b>1</b><div><strong>Book a court</strong><span>Discover → Rent court → pay</span></div></button>
      <button class="hp-q" data-go="discover"><b>2</b><div><strong>Buy event tickets</strong><span>Discover → Book tickets → pay</span></div></button>
      <button class="hp-q" data-go="mine"><b>3</b><div><strong>Get your QR ticket</strong><span>My bookings → click the QR code</span></div></button></div>
    <div class="mb-pills hp-tabs">${roleKeys.map(r => `<button class="mb-pill ${r === tab ? 'on' : ''}" data-r="${r}">${HELP[r][0]}${r === mine ? ' <em>you</em>' : ''}</button>`).join('')}</div>
    <div id="hpBody"></div>
    <section class="panel"><h3>Who can do what</h3><div class="tw"><table class="hp-rights"><thead><tr><th>Feature</th>${roleKeys.map(r => `<th class="${r === mine ? 'me' : ''}">${HELP[r][0]}</th>`).join('')}</tr></thead>
      <tbody>${RIGHTS.map(([f, ...v]) => `<tr><td>${f}</td>${v.map((x, i) => `<td class="${roleKeys[i] === mine ? 'me' : ''}">${x ? ok : no}</td>`).join('')}</tr>`).join('')}</tbody></table></div></section>
    <section class="panel"><h3>Frequently asked questions</h3><div id="hpFaq"></div></section>
    <section class="panel hp-sys"><h3>System check</h3><div class="hp-sys-grid"><div><span>Server</span><b id="hpApi">Not checked yet</b></div><div><span>Your role</span><b>${esc(HELP[mine][0])}</b></div>
      <div><span>Signed in</span><b>${session ? esc(session.user.name) : 'No'}</b></div></div>
      <div class="hp-acts"><button class="btn" id="hpChk">Check server</button><button class="btn" id="hpPrint">Print / save as PDF</button></div></section>`;
  const mt = (s, qq) => !qq || s.toLowerCase().includes(qq);
  const det = (t, body, open, tag = '') => `<details class="hp-d" ${open ? 'open' : ''}><summary>${t}${tag}</summary>${body}</details>`;
  const draw = () => {
    let h = '';
    if (q) { roleKeys.forEach(r => HELP[r][2].forEach(([t, st]) => { if (mt(t + ' ' + st.join(' '), q)) h += det(t, `<ol>${st.map(s => `<li>${s}</li>`).join('')}</ol>`, true, `<em class="hp-tag">${HELP[r][0]}</em>`); }));
      h = h || '<p class="empty">No guide matches your search.</p>'; }
    else h = `<p class="hp-intro">${HELP[tab][1]}</p>` + HELP[tab][2].map(([t, st], i) => det(t, `<ol>${st.map(s => `<li>${s}</li>`).join('')}</ol>`, i === 0)).join('');
    $('#hpBody', el).innerHTML = h;
    $('#hpFaq', el).innerHTML = FAQ.filter(([f, an]) => mt(f + ' ' + an, q)).map(([f, an]) => det(f, `<p>${an}</p>`, false)).join('') || '<p class="meta">No question matches your search.</p>';
  };
  el.addEventListener('click', e => {
    const r = e.target.closest('[data-r]'), g = e.target.closest('[data-go]');
    if (r) { tab = r.dataset.r; q = ''; $('#hq', el).value = ''; el.querySelectorAll('.hp-tabs .mb-pill').forEach(x => x.classList.toggle('on', x === r)); draw(); }
    if (g) VIEWS[g.dataset.go].roles.includes(mine) ? show(g.dataset.go) : authModal('Please sign in to use this feature.');
  });
  $('#hq', el).oninput = e => { q = e.target.value.trim().toLowerCase(); draw(); };
  $('#hpChk', el).onclick = async () => { $('#hpApi', el).textContent = 'Checking…'; const r = await checkApi(); $('#hpApi', el).textContent = r.ok ? `Online (${r.ms} ms)` : 'Offline – start Apache and MySQL in XAMPP'; };
  $('#hpPrint', el).onclick = () => { el.querySelectorAll('details').forEach(d => d.open = true); window.print(); };
  draw();
}

/* ---------- Sidebar: user card, grouped navigation, badges, API status, session timer ---------- */
const navItem = id => `<button class="nav-i" data-view="${id}" title="${NAV_LABEL[id]}"><span class="nav-ic"><svg viewBox="0 0 24 24">${NAV_ICON[id]}</svg></span><span class="nav-t">${NAV_LABEL[id]}</span><span class="nav-badge" data-badge="${id}" hidden></span></button>`;
const jwtExp = () => { try { return JSON.parse(atob(session.token.split('.')[1])).exp * 1000; } catch { return null; } };
let sessTimer = null, warned = false;
function tickSession() {
  if (!session) return; const exp = jwtExp(); if (!exp) return;
  const left = exp - Date.now();
  if (left <= 0) { toast('Your session has expired. Please sign in again.', true); logout(); return; }
  if (left < 5 * 60000 && !warned) { warned = true; toast('Your session ends in less than 5 minutes.'); }
  const m = Math.floor(left / 60000), t = $('#sessTxt'), b = $('#sessBar');
  if (t) t.textContent = `Session: ${Math.floor(m / 60)}h ${m % 60}m left`;
  if (b) b.style.width = Math.min(100, left / (5 * 3600e3) * 100) + '%';
}
function renderUserCard() {
  const el = $('#userCard');
  if (!session) {
    el.innerHTML = `<div class="uc"><div class="uc-av">?</div><div class="uc-txt"><b>Welcome, guest</b><small>Sign in to book courts and tickets</small></div></div>
      <div class="uc-btns"><button class="btn primary" data-open-auth="login"><svg viewBox="0 0 24 24"><path d="M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 8l4 4-4 4M14 12H3"/></svg><span>Sign in</span></button>
      <button class="btn ghost" data-open-auth="register"><span>Create account</span></button></div>`;
    return;
  }
  const {name, role} = session.user;
  el.innerHTML = `<div class="uc"><div class="uc-av role-${esc(role)}">${esc((name || '?')[0].toUpperCase())}</div><div class="uc-txt"><b>${esc(name)}</b><span class="pill role-${esc(role)}">${esc(role)}</span></div></div>
    <div class="uc-sess"><span id="sessTxt">Session active</span><i><b id="sessBar" style="width:100%"></b></i></div>`;
  tickSession();
}
async function refreshBadges() {          // pending counts shown on the sidebar items
  if (!session) return; const role = session.user.role;
  try {
    const b = (await api('bookings')).data; let key = null, n = 0;
    if (role === 'customer') { key = 'mine'; n = b.filter(x => +x.customer_id === +session.user.id && x.status === 'pending').length; }
    else if (role === 'admin' || role === 'staff') { key = 'bookings'; n = b.filter(x => x.status === 'pending').length; }
    const el = key && $(`#nav [data-badge=${key}]`); if (el) { el.textContent = n; el.hidden = !n; el.title = `${n} pending`; }
  } catch {}
}
async function checkApi() {               // live server check shown in the sidebar footer and the Help page
  const chip = $('#apiChip'), txt = $('#apiTxt'), t0 = performance.now();
  if (chip) { chip.dataset.s = 'wait'; txt.textContent = 'Checking server…'; }
  try {
    const r = await fetch(`${API_BASE_URL}/venues.php`, {cache: 'no-store'}); if (!r.ok) throw new Error();
    const ms = Math.round(performance.now() - t0); if (chip) { chip.dataset.s = 'ok'; txt.textContent = `Server online · ${ms} ms`; } return {ok: true, ms};
  } catch { if (chip) { chip.dataset.s = 'bad'; txt.textContent = 'Server offline'; } return {ok: false}; }
}
function openDrawer() { $('#side').classList.add('open'); $('#scrim').classList.add('on'); $('#burger').setAttribute('aria-expanded', 'true'); }
function closeDrawer() { $('#side').classList.remove('open'); $('#scrim').classList.remove('on'); $('#burger').setAttribute('aria-expanded', 'false'); }
const SIDE_KEY = 'ss_side_collapsed';
function setCollapsed(c) {
  $('#appShell').classList.toggle('collapsed', c); $('#sideToggle').setAttribute('aria-expanded', String(!c)); $('#sideToggle').title = c ? 'Expand sidebar' : 'Collapse sidebar';
  try { localStorage.setItem(SIDE_KEY, c ? '1' : '0'); } catch {}
}

function startApp() {
  const role = session?.user.role || 'guest';
  renderUserCard(); $('#logoutBtn').hidden = !session;
  const allowed = ORDER.filter(id => VIEWS[id].roles.includes(role));
  $('#nav').innerHTML = NAV_GROUPS.map(([g, ids]) => { const items = ids.filter(i => allowed.includes(i));
    return items.length ? `<div class="nav-g">${g}</div>` + items.map(navItem).join('') : ''; }).join('');
  clearInterval(sessTimer); warned = false; if (session) sessTimer = setInterval(tickSession, 30000);
  show(allowed[0]); checkApi();
}
function logout() { session = null; sessionStorage.removeItem('ss_session'); closeModal(); startApp(); }
async function login(email, password, onOk) {
  const d = await api('auth', {method: 'POST', body: {email, password}});
  session = {token: d.token, user: d.user}; sessionStorage.setItem('ss_session', JSON.stringify(session));
  if (onOk) await onOk(d);            // lets the sign-in window play its success animation first
  closeModal(); startApp(); toast('Welcome, ' + d.user.name + '!');
}
const validEmail = v => /^\S+@\S+\.\S+$/.test(v);

function authModal(note = '', tab = 'login') {
  const ic = {mail: '<path d="M3 6h18v12H3zM3 7l9 6 9-6"/>', lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>', user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'};
  const eye = '<svg viewBox="0 0 24 24"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  const fl = (id, type, label, icon, extra = '') => `<label class="fl"><svg class="fl-ic" viewBox="0 0 24 24">${ic[icon]}</svg><input id="${id}" type="${type}" placeholder=" " ${extra}><span>${label}</span>
    ${type === 'password' ? `<button type="button" class="fl-eye" data-eye="${id}" aria-label="Show password" tabindex="-1">${eye}</button>` : ''}</label>`;
  const btn = t => `<button class="au-btn" type="submit"><span class="au-btn-t">${t}</span><span class="au-spin"></span></button>`;
  $('#modalRoot').innerHTML = `<div class="overlay" data-act="closeModal"><div class="modal au" role="dialog" aria-modal="true" aria-label="Account">
    <aside class="au-art" aria-hidden="true">
      <svg class="au-court" viewBox="0 0 300 180" fill="none" stroke="currentColor" stroke-width="2.2"><rect pathLength="1" x="8" y="8" width="284" height="164" rx="8"/><path pathLength="1" d="M150 8v164"/><circle pathLength="1" cx="150" cy="90" r="28"/>
        <path pathLength="1" d="M8 52h42v76H8M292 52h-42v76h42"/><circle cx="150" cy="90" r="3" fill="currentColor" stroke="none"/></svg>
      <div class="au-brand"><img src="favicon.png" alt="" width="40" height="40"><b>SportSphere</b></div>
      <div class="au-copy"><h3 id="auHead">Welcome back</h3><p id="auSub">Sign in to manage your bookings and QR tickets.</p></div>
      <ul class="au-list"><li>Book courts by the hour</li><li>Buy tournament tickets</li><li>Get your QR ticket once confirmed</li></ul>
      <div class="au-ball"></div><div class="au-shadow"></div>
    </aside>
    <section class="au-form">
      <button class="au-x" data-act="closeModalBtn" aria-label="Close">&times;</button>
      <div class="au-tabs"><i class="au-ind"></i><button type="button" class="on" data-auth="login">Sign in</button><button type="button" data-auth="register">Create account</button></div>
      ${note ? `<p class="au-note">${esc(note)}</p>` : ''}
      <form id="loginForm" class="au-fields" novalidate>${fl('loginEmail', 'email', 'Email address', 'mail', 'autocomplete="username"')}${fl('loginPassword', 'password', 'Password', 'lock', 'autocomplete="current-password"')}
        <p class="au-caps" hidden>Caps Lock is on</p>${btn('Sign in')}</form>
      <form id="registerForm" class="au-fields" hidden novalidate>${fl('regName', 'text', 'Full name', 'user', 'autocomplete="name" maxlength="100"')}${fl('regEmail', 'email', 'Email address', 'mail', 'autocomplete="email"')}
        ${fl('regPassword', 'password', 'Password (min 6 characters)', 'lock', 'autocomplete="new-password"')}
        <div class="au-str" aria-live="polite"><div><i></i><i></i><i></i><i></i></div><small>Choose a strong password</small></div>
        ${fl('regConfirm', 'password', 'Confirm password', 'lock', 'autocomplete="new-password"')}${btn('Create customer account')}</form>
      <p id="authMsg" class="au-msg" role="alert"></p>
    </section></div></div>`;
  const root = $('#modalRoot'), box = $('.au', root), msg = (t, ok) => { const m = $('#authMsg'); m.textContent = t; m.classList.toggle('ok', !!ok); m.classList.toggle('show', !!t); };
  const shake = () => { box.classList.remove('shake'); void box.offsetWidth; box.classList.add('shake'); };
  const bad = (el, m) => { el.closest('.fl').classList.add('bad'); msg(m); shake(); el.focus(); return false; };
  const busy = (f, on) => { const b = $('.au-btn', f); b.disabled = on; b.classList.toggle('loading', on); };
  const COPY = {login: ['Welcome back', 'Sign in to manage your bookings and QR tickets.'], register: ['Join the game', 'Create a free customer account in a few seconds.']};
  const setTab = t => {
    root.querySelectorAll('[data-auth]').forEach(x => x.classList.toggle('on', x.dataset.auth === t));
    $('.au-ind', root).style.transform = t === 'register' ? 'translateX(100%)' : 'none';
    $('#loginForm').hidden = t !== 'login'; $('#registerForm').hidden = t !== 'register'; msg('');
    const c = $('.au-copy', root); c.classList.remove('swap'); void c.offsetWidth; c.classList.add('swap');
    $('#auHead').textContent = COPY[t][0]; $('#auSub').textContent = COPY[t][1];
    setTimeout(() => $(t === 'login' ? '#loginEmail' : '#regName')?.focus(), 50);
  };
  root.querySelectorAll('[data-auth]').forEach(t => t.onclick = () => setTab(t.dataset.auth));
  root.addEventListener('click', e => { const b = e.target.closest('[data-eye]'); if (!b) return;
    const i = $('#' + b.dataset.eye); const show = i.type === 'password'; i.type = show ? 'text' : 'password'; b.classList.toggle('on', show); b.setAttribute('aria-label', show ? 'Hide password' : 'Show password'); });
  root.addEventListener('input', e => { const l = e.target.closest('.fl'); if (l) { l.classList.remove('bad'); msg(''); } });
  root.addEventListener('keyup', e => { if (e.target.type === 'password') $('.au-caps').hidden = !(e.getModifierState && e.getModifierState('CapsLock')) || $('#loginForm').hidden; });
  $('#regPassword').addEventListener('input', e => {       // password strength meter
    const v = e.target.value; let s = 0; if (v.length >= 6) s++; if (v.length >= 10) s++; if (/[a-z]/.test(v) && /[A-Z]/.test(v)) s++; if (/\d/.test(v) && /[^A-Za-z0-9]/.test(v)) s++;
    const bar = $('.au-str', root); bar.dataset.s = v ? s : ''; $('small', bar).textContent = v ? ['Too weak', 'Weak', 'Fair', 'Good', 'Strong'][v.length < 6 ? 0 : Math.max(1, s)] : 'Choose a strong password';
  });
  const done = title => async d => { $('.au-form', root).innerHTML = `<div class="au-ok"><svg class="tick" viewBox="0 0 52 52"><circle class="tick-c" cx="26" cy="26" r="24"/><path class="tick-p" d="M14 27l8 8 16-17"/></svg>
    <h3>${title}, ${esc(d.user.name)}!</h3><p class="meta">Taking you to your dashboard…</p><div class="au-bar"><i></i></div></div>`; await new Promise(r => setTimeout(r, 1300)); };
  $('#loginForm').onsubmit = async e => {
    e.preventDefault(); const em = $('#loginEmail'), pw = $('#loginPassword');
    if (!validEmail(em.value.trim())) return bad(em, 'Enter a valid email address.');
    if (!pw.value) return bad(pw, 'Password is required.');
    busy(e.target, true); msg('');
    try { await login(em.value.trim(), pw.value, done('Welcome back')); }
    catch (err) { busy(e.target, false); msg(err.message); shake(); }
  };
  $('#registerForm').onsubmit = async e => {
    e.preventDefault(); const n = $('#regName'), em = $('#regEmail'), pw = $('#regPassword'), cf = $('#regConfirm');
    if (n.value.trim().length < 2) return bad(n, 'Please enter your full name.');
    if (!validEmail(em.value.trim())) return bad(em, 'Enter a valid email address.');
    if (pw.value.length < 6) return bad(pw, 'Password must be at least 6 characters.');
    if (cf.value !== pw.value) return bad(cf, 'The two passwords do not match.');
    busy(e.target, true); msg('');
    try { await api('users', {method: 'POST', body: {name: n.value.trim(), email: em.value.trim(), password: pw.value, role: 'customer'}}); await login(em.value.trim(), pw.value, done('Account created')); }
    catch (err) { busy(e.target, false); msg(err.message); shake(); }
  };
  setTab(tab);
}

$('#nav').addEventListener('click', e => { const b = e.target.closest('[data-view]'); if (b) show(b.dataset.view); });
$('#side').addEventListener('click', e => { const o = e.target.closest('[data-open-auth]'); if (o) { closeDrawer(); authModal('', o.dataset.openAuth); } });
$('#logoutBtn').onclick = logout;
$('#apiChip').onclick = checkApi;
$('#sideToggle').onclick = () => setCollapsed(!$('#appShell').classList.contains('collapsed'));
$('#burger').onclick = openDrawer; $('#scrim').onclick = closeDrawer;
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDrawer(); });
setInterval(checkApi, 120000);
try { if (localStorage.getItem(SIDE_KEY) === '1') setCollapsed(true); } catch {}
startApp();