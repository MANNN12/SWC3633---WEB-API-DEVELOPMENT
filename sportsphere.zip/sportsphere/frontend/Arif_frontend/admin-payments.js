const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// Protect admin page
if (!token || !userData) {
    window.location.href = "index.html";
}

const user = JSON.parse(userData);

// Only admin can access
if (user.role !== "admin") {
    window.location.href = "dashboard.html";
}


// ===============================
// LOAD PAYMENTS
// ===============================

async function loadAdminPayments() {

    const paymentsGrid =
        document.getElementById("adminPaymentsGrid");

    paymentsGrid.innerHTML = "<p>Loading payments...</p>";

    try {

        const response = await fetch(
            "../../payments.php",
            {
                method: "GET",

                headers: {
                    "Authorization": "Bearer " + token
                }
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.error || "Unable to load payments."
            );
        }

        const payments = data.data || [];

        displayPayments(payments);

    } catch (error) {

        console.error(error);

        paymentsGrid.innerHTML =
            `<p style="color:red;">${error.message}</p>`;
    }
}


// ===============================
// DISPLAY PAYMENTS
// ===============================

function displayPayments(payments) {

    const paymentsGrid =
        document.getElementById("adminPaymentsGrid");

    paymentsGrid.innerHTML = "";

    if (payments.length === 0) {

        paymentsGrid.innerHTML =
            "<p>No payment records found.</p>";

        return;
    }

    payments.forEach(function (payment) {

        const card = document.createElement("div");

        card.className = "booking-card";

        card.innerHTML = `
            <div class="booking-top">

                <div>
                    <p class="booking-id">
                        PAYMENT #${payment.id}
                    </p>

                    <h3>
                        Booking #${payment.booking_id}
                    </h3>
                </div>

               <span class="status-badge status-${payment.payment_status}">
    ${payment.payment_status}
</span>
                </span>

            </div>

            <div class="booking-details">

                <p>
                    <strong>Payment Method:</strong>
                    ${payment.payment_method}
                </p>

                <p>
                    <strong>Amount:</strong>
                    RM ${Number(payment.amount).toFixed(2)}
                </p>

                <p>
                    <strong>Transaction Ref:</strong>
                    ${payment.transaction_ref || "-"}
                </p>

            </div>
        `;

        paymentsGrid.appendChild(card);
    });
}


// ===============================
// FILTER PAYMENT STATUS
// ===============================

document
    .getElementById("paymentStatusFilter")
    .addEventListener("change", function () {

        const selectedStatus = this.value;

        const cards =
            document.querySelectorAll("#adminPaymentsGrid .booking-card");

        cards.forEach(function (card) {

            if (
                selectedStatus === "" ||
                card
                    .querySelector(".status-badge")
                    .textContent
                    .trim()
                    .toLowerCase() === selectedStatus
            ) {
                card.style.display = "";
            } else {
                card.style.display = "none";
            }

        });

    });


// ===============================
// LOGOUT
// ===============================

document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";

    });


// Load payments when page opens
loadAdminPayments();