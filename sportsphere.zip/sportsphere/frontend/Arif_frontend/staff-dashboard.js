const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// ===============================
// CHECK LOGIN
// ===============================

if (!token || !userData) {
    window.location.href = "index.html";
}

const currentUser = JSON.parse(userData);


// ===============================
// PROTECT STAFF PAGE
// ===============================

if (currentUser.role !== "staff") {

    if (currentUser.role === "admin") {
        window.location.href = "admin-dashboard.html";

    } else if (currentUser.role === "organiser") {
        window.location.href = "organiser-dashboard.html";

    } else {
        window.location.href = "dashboard.html";
    }
}


// ===============================
// WELCOME MESSAGE
// ===============================

document.getElementById("welcomeText").textContent =
    `Welcome, ${currentUser.name}!`;


// ===============================
// MANAGE BOOKINGS
// ===============================

document
    .getElementById("manageBookingsBtn")
    .addEventListener("click", function () {

        window.location.href =
            "staff-bookings.html";

    });


// ===============================
// VIEW PAYMENTS
// ===============================

document
    .getElementById("viewPaymentsBtn")
    .addEventListener("click", function () {

        window.location.href =
            "staff-payments.html";

    });


// ===============================
// LOGOUT
// ===============================

document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";

    });