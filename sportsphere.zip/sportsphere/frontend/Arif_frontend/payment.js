const API_BASE = "http://localhost/sportsphere";

const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// ===============================
// CHECK LOGIN
// ===============================

if (!token || !userData) {
    window.location.href = "index.html";
}


// ===============================
// GET PAYMENT INFORMATION FROM URL
// ===============================

const params = new URLSearchParams(window.location.search);

const bookingId = params.get("booking_id");
const amount = params.get("amount");
const eventName = params.get("event");
const quantity = params.get("quantity");


// ===============================
// DISPLAY PAYMENT SUMMARY
// ===============================

const paymentSummary =
    document.getElementById("paymentSummary");

if (!bookingId || !amount) {

    paymentSummary.innerHTML = `
        <p style="color:red;">
            Payment information is missing.
        </p>
    `;

    document.getElementById("makePaymentBtn").disabled = true;

} else {

    paymentSummary.innerHTML = `
        <div class="booking-details">

            <p>
                <strong>Booking ID:</strong>
                #${bookingId}
            </p>

            <p>
                <strong>Event:</strong>
                ${eventName || "-"}
            </p>

            <p>
                <strong>Quantity:</strong>
                ${quantity || "-"} ticket(s)
            </p>

            <p>
                <strong>Total Amount:</strong>
                RM ${Number(amount).toFixed(2)}
            </p>

        </div>
    `;
}

// ===============================
// MAKE PAYMENT
// ===============================

document
    .getElementById("makePaymentBtn")
    .addEventListener("click", async function () {

        const paymentMethod =
            document.getElementById("paymentMethod").value;

        const paymentMessage =
            document.getElementById("paymentMessage");

        // Validate payment method
        if (!paymentMethod) {

            paymentMessage.style.color = "red";
            paymentMessage.textContent =
                "Please select a payment method.";

            return;
        }

        try {

            paymentMessage.style.color = "#64748b";
            paymentMessage.textContent =
                "Processing payment...";

            const response = await fetch(
                `${API_BASE}/payments.php`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    },

                    body: JSON.stringify({
                        booking_id: Number(bookingId),
                        payment_method: paymentMethod,
                        amount: Number(amount)
                    })
                }
            );

            const result = await response.json();

            if (!response.ok) {
                throw new Error(
                    result.error ||
                    "Unable to process payment."
                );
            }

            // Payment successful
            paymentMessage.style.color = "green";

           paymentMessage.innerHTML = `
    <strong>Payment Successful!</strong>
    <br><br>

    Transaction Reference:
    <strong>${result.transaction_ref}</strong>

    <br><br>

    <button id="viewBookingsBtn">
        View My Bookings
    </button>
`;

document
    .getElementById("viewBookingsBtn")
    .addEventListener("click", function () {

        window.location.href = "my-bookings.html";

    });

            // Disable button to prevent double payment
            document.getElementById(
                "makePaymentBtn"
            ).disabled = true;

            document.getElementById(
                "paymentMethod"
            ).disabled = true;

        } catch (error) {

            console.error(error);

            paymentMessage.style.color = "red";
            paymentMessage.textContent =
                error.message;
        }

    });

// ===============================
// LOGOUT
// ===============================

document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";
    });