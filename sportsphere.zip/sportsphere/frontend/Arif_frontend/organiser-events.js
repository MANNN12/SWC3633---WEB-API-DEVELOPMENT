const API_BASE = "http://localhost/sportsphere";

const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// ===============================
// CHECK LOGIN
// ===============================

if (!token || !userData) {
    window.location.href = "index.html";
}

const currentUser = JSON.parse(userData);

// ===============================
// PROTECT ORGANISER PAGE
// ===============================

if (currentUser.role !== "organiser") {

    if (currentUser.role === "admin") {
        window.location.href = "admin-dashboard.html";

    } else if (currentUser.role === "staff") {
        window.location.href = "staff-dashboard.html";

    } else {
        window.location.href = "dashboard.html";
    }
}


// ===============================
// LOAD EVENTS
// ===============================

async function loadOrganiserEvents() {

    const eventsGrid =
        document.getElementById("organiserEventsGrid");

    eventsGrid.innerHTML =
        "<p>Loading events...</p>";

    try {

        const response = await fetch(
            `${API_BASE}/events.php`
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.error || "Unable to load events."
            );
        }

        const events = data.data || data;

        displayEvents(events);

    } catch (error) {

        console.error(error);

        eventsGrid.innerHTML =
            `<p style="color:red;">${error.message}</p>`;
    }
}


// ===============================
// DISPLAY EVENTS
// ===============================

function displayEvents(events) {

    const eventsGrid =
        document.getElementById("organiserEventsGrid");

    eventsGrid.innerHTML = "";

    if (!events || events.length === 0) {

        eventsGrid.innerHTML =
            "<p>No events found.</p>";

        return;
    }

    events.forEach(function (event) {

        const card =
            document.createElement("div");

        card.className = "booking-card";

        card.innerHTML = `

            <div class="booking-top">

                <div>

                    <p class="booking-id">
                        EVENT #${event.id}
                    </p>

                    <h3>
                        ${event.event_name}
                    </h3>

                </div>

            </div>


            <div class="booking-details">

                <p>
                    <strong>Date:</strong>
                    ${event.event_date}
                </p>

                <p>
                    <strong>Ticket Price:</strong>
                    RM ${Number(event.ticket_price).toFixed(2)}
                </p>

                <p>
                    <strong>Total Tickets:</strong>
                    ${event.total_tickets}
                </p>

                <p>
                    <strong>Tickets Available:</strong>
                    ${event.tickets_available}
                </p>

            </div>


            <div class="booking-actions">

                <button
                    onclick="editEvent(
                        ${event.id},
                        '${event.event_name}',
                        '${event.event_date}',
                        ${event.ticket_price},
                        ${event.total_tickets}
                    )"
                >
                    Edit Event
                </button>

                <button
                    onclick="deleteEvent(${event.id}, '${event.event_name}')"
                >
                    Delete Event
                </button>

            </div>
        `;

        eventsGrid.appendChild(card);
    });
}


// ===============================
// CREATE EVENT
// ===============================

document
    .getElementById("createEventBtn")
    .addEventListener("click", async function () {

        const eventName =
            document.getElementById("eventName").value.trim();

        const eventDate =
            document.getElementById("eventDate").value;

        const ticketPrice =
            document.getElementById("ticketPrice").value;

        const totalTickets =
            document.getElementById("totalTickets").value;

        const message =
            document.getElementById("eventMessage");


        if (
            !eventName ||
            !eventDate ||
            !ticketPrice ||
            !totalTickets
        ) {

            message.style.color = "red";

            message.textContent =
                "Please complete all event details.";

            return;
        }


        try {

            message.style.color = "#64748b";
            message.textContent = "Creating event...";

            const response = await fetch(
                `${API_BASE}/events.php`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    },

                    body: JSON.stringify({
                        organiser_id: Number(currentUser.id),
                        event_name: eventName,
                        event_date: eventDate,
                        ticket_price: Number(ticketPrice),
                        total_tickets: Number(totalTickets)
                    })
                }
            );

            const result = await response.json();

            if (!response.ok) {
                throw new Error(
                    result.error ||
                    "Unable to create event."
                );
            }

            message.style.color = "green";

            message.textContent =
                "Event created successfully!";


            // Clear form
            document.getElementById("eventName").value = "";
            document.getElementById("eventDate").value = "";
            document.getElementById("ticketPrice").value = "";
            document.getElementById("totalTickets").value = "";


            // Refresh event list
            await loadOrganiserEvents();

        } catch (error) {

            console.error(error);

            message.style.color = "red";
            message.textContent = error.message;
        }

    });


// ===============================
// EDIT EVENT
// ===============================

// ===============================
// EDIT EVENT
// ===============================

async function editEvent(
    id,
    currentName,
    currentDate,
    currentPrice,
    currentTotalTickets
) {

    const newName = prompt(
        "Event name:",
        currentName
    );

    if (newName === null) {
        return;
    }

    if (newName.trim() === "") {
        alert("Event name cannot be empty.");
        return;
    }


    const newPrice = prompt(
        "Ticket price (RM):",
        currentPrice
    );

    if (newPrice === null) {
        return;
    }

    if (
        newPrice.trim() === "" ||
        Number(newPrice) < 0
    ) {
        alert("Please enter a valid ticket price.");
        return;
    }


    try {

        const response = await fetch(
            `${API_BASE}/events.php?id=${id}`,
            {
                method: "PUT",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },

                body: JSON.stringify({
                    event_name: newName.trim(),
                    ticket_price: Number(newPrice)
                })
            }
        );


        const result = await response.json();


        if (!response.ok) {

            throw new Error(
                result.error ||
                "Unable to update event."
            );

        }


        alert("Event updated successfully!");

        await loadOrganiserEvents();


    } catch (error) {

        console.error(error);

        alert(error.message);

    }
}

// ===============================
// DELETE EVENT
// ===============================

async function deleteEvent(id, eventName) {

    const confirmDelete =
        confirm(
            `Are you sure you want to delete ${eventName}?`
        );

    if (!confirmDelete) {
        return;
    }


    try {

        const response = await fetch(
            `${API_BASE}/events.php?id=${id}`,
            {
                method: "DELETE",

                headers: {
                    "Authorization": `Bearer ${token}`
                }
            }
        );

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error ||
                "Unable to delete event."
            );
        }

        alert("Event deleted successfully!");

        await loadOrganiserEvents();

    } catch (error) {

        console.error(error);

        alert(error.message);
    }
}


// ===============================
// LOGOUT
// ===============================

document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";

    });


// ===============================
// LOAD PAGE
// ===============================

loadOrganiserEvents();