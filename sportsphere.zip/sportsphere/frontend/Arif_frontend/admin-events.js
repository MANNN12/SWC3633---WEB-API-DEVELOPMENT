const API_URL = "../../events.php";

const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

if (!token || !userData) {
    window.location.href = "index.html";
}

const user = JSON.parse(userData);

// Only admin can access this page
if (user.role !== "admin") {
    window.location.href = "dashboard.html";
}


// ==========================
// LOAD ALL EVENTS
// ==========================
async function loadAdminEvents() {

    const eventsGrid = document.getElementById("adminEventsGrid");

    try {

        const response = await fetch(API_URL);

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || "Unable to load events");
        }

        const events = result.data || [];

        eventsGrid.innerHTML = "";

        if (events.length === 0) {
            eventsGrid.innerHTML = "<p>No events found.</p>";
            return;
        }

        events.forEach(function (event) {

            const card = document.createElement("div");

            card.className = "dashboard-card";

            const available =
                Number(event.total_tickets) -
                Number(event.tickets_sold || 0);

            card.innerHTML = `
                <div class="card-icon">🏆</div>

                <h3>${event.event_name}</h3>

                <p>
                    <strong>Event ID:</strong>
                    ${event.id}
                </p>

                <p>
                    <strong>Date:</strong>
                    ${event.event_date}
                </p>

                <p>
                    <strong>Ticket Price:</strong>
                    RM ${Number(event.ticket_price).toFixed(2)}
                </p>

                <p>
                    <strong>Total Tickets:</strong>
                    ${event.total_tickets}
                </p>

               <p>
    <strong>Tickets Available:</strong>
    ${available}
</p>

<button
    class="edit-event-btn"
    onclick="editEvent(${event.id}, '${event.event_name}', ${event.ticket_price})"
>
    Edit Event
</button>
<button
    class="delete-event-btn"
    onclick="deleteEvent(${event.id}, '${event.event_name}')"
>
    Delete Event
</button>
`;

            eventsGrid.appendChild(card);

        });

    } catch (error) {

        console.error(error);

        eventsGrid.innerHTML =
            `<p style="color:red;">Unable to load events.</p>`;
    }
}


// ==========================
// LOGOUT
// ==========================
document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";
    });


// Load events when page opens
loadAdminEvents();

// ==========================
// CREATE NEW EVENT
// ==========================
document
    .getElementById("createEventForm")
    .addEventListener("submit", async function (event) {

        event.preventDefault();

        const eventName =
            document.getElementById("eventName").value.trim();

        const eventDate =
            document.getElementById("eventDate").value;

        const ticketPrice =
            Number(document.getElementById("ticketPrice").value);

        const totalTickets =
            Number(document.getElementById("totalTickets").value);

        const message =
            document.getElementById("eventMessage");

        // Simple validation
        if (
            !eventName ||
            !eventDate ||
            ticketPrice < 0 ||
            totalTickets < 1
        ) {
            message.style.color = "red";
            message.textContent = "Please enter valid event details.";
            return;
        }

        message.style.color = "#64748b";
        message.textContent = "Creating event...";

        try {

            const response = await fetch(API_URL, {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },

                body: JSON.stringify({
                    event_name: eventName,
                    organiser_id: Number(user.id),
                    event_date: eventDate,
                    ticket_price: ticketPrice,
                    total_tickets: totalTickets
                })
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(
                    result.error || "Unable to create event"
                );
            }

            message.style.color = "green";
            message.textContent = "Event created successfully!";

            // Clear form
            document
                .getElementById("createEventForm")
                .reset();

            // Refresh event list
            await loadAdminEvents();

        } catch (error) {

            console.error(error);

            message.style.color = "red";
            message.textContent = error.message;
        }
    });

    // ==========================
// EDIT EVENT
// ==========================
async function editEvent(id, currentName, currentPrice) {

    const newName = prompt(
        "Enter new event name:",
        currentName
    );

    // User pressed Cancel
    if (newName === null) {
        return;
    }

    if (newName.trim() === "") {
        alert("Event name cannot be empty.");
        return;
    }

    const newPrice = prompt(
        "Enter new ticket price:",
        currentPrice
    );

    // User pressed Cancel
    if (newPrice === null) {
        return;
    }

    const price = Number(newPrice);

    if (newPrice.trim() === "" || isNaN(price) || price < 0) {
        alert("Please enter a valid ticket price.");
        return;
    }

    try {

        const response = await fetch(
            `${API_URL}?id=${id}`,
            {
                method: "PUT",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },

                body: JSON.stringify({
                    event_name: newName.trim(),
                    ticket_price: price
                })
            }
        );

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error || "Unable to update event"
            );
        }

        alert("Event updated successfully!");

        // Reload latest data from database
        await loadAdminEvents();

    } catch (error) {

        console.error(error);

        alert(error.message);
    }
}

// ==========================
// DELETE EVENT
// ==========================
async function deleteEvent(id, eventName) {

    const confirmation = confirm(
        `Are you sure you want to delete "${eventName}"?`
    );

    // User presses Cancel
    if (!confirmation) {
        return;
    }

    try {

        const response = await fetch(
            `${API_URL}?id=${id}`,
            {
                method: "DELETE",

                headers: {
                    "Authorization": `Bearer ${token}`
                }
            }
        );

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error || "Unable to delete event"
            );
        }

        alert("Event deleted successfully!");

        // Refresh events after deletion
        await loadAdminEvents();

    } catch (error) {

        console.error(error);

        alert(error.message);
    }
}