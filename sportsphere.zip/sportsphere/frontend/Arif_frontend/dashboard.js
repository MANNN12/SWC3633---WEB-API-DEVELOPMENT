const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// User belum login
if (!token || !userData) {
    window.location.href = "index.html";
} else {
    const user = JSON.parse(userData);

    document.getElementById("customerName").textContent =
        user.name || "Customer";
}
// Navigation
document.getElementById("eventsLink").addEventListener("click", function (e) {
    e.preventDefault();
    window.location.href = "events.html";
});

document.getElementById("bookingsLink").addEventListener("click", function (e) {
    e.preventDefault();
    window.location.href = "my-bookings.html";
});

document.getElementById("browseEventsBtn").addEventListener("click", function () {
    window.location.href = "events.html";
});

document.getElementById("viewBookingsBtn").addEventListener("click", function () {
    window.location.href = "my-bookings.html";
});

// Logout
document.getElementById("logoutBtn").addEventListener("click", function () {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    window.location.href = "index.html";
});