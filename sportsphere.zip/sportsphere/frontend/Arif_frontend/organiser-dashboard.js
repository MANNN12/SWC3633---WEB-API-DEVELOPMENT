const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// ===============================
// CHECK LOGIN
// ===============================

if (!token || !userData) {
    window.location.href = "index.html";
}

const currentUser = JSON.parse(userData);


// ===============================
// PROTECT ORGANISER PAGE
// ===============================

if (currentUser.role !== "organiser") {

    if (currentUser.role === "admin") {
        window.location.href = "admin-dashboard.html";

    } else if (currentUser.role === "staff") {
        window.location.href = "staff-dashboard.html";

    } else {
        window.location.href = "dashboard.html";
    }
}


// ===============================
// WELCOME MESSAGE
// ===============================

document.getElementById("welcomeText").textContent =
    `Welcome, ${currentUser.name}!`;


// ===============================
// MANAGE EVENTS
// ===============================

document
    .getElementById("manageEventsBtn")
    .addEventListener("click", function () {

        window.location.href =
            "organiser-events.html";

    });


// ===============================
// VIEW BOOKINGS
// ===============================

document
    .getElementById("viewBookingsBtn")
    .addEventListener("click", function () {

        window.location.href =
            "organiser-bookings.html";

    });


// ===============================
// LOGOUT
// ===============================

document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";

    });