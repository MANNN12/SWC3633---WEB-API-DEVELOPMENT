const API_BASE = "http://localhost/sportsphere";

const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

if (!token || !userData) {
    window.location.href = "index.html";
}

const eventsGrid = document.getElementById("eventsGrid");
const loadingMessage = document.getElementById("loadingMessage");

// Load all events from REST API
async function loadEvents() {

    try {

        const response = await fetch(`${API_BASE}/events.php`);

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || "Failed to load events");
        }

        loadingMessage.style.display = "none";

        const events = result.data;

        if (!events || events.length === 0) {
            eventsGrid.innerHTML = `
                <p>No events are currently available.</p>
            `;
            return;
        }

        events.forEach(function (event) {

            const ticketsAvailable =
                Number(event.total_tickets) -
                Number(event.tickets_sold);

            const eventCard = document.createElement("div");

            eventCard.className = "event-card";

            eventCard.innerHTML = `
                <div class="event-icon">🏆</div>

                <h3>${event.event_name}</h3>

                <div class="event-info">
                    <p>
                        <strong>Date:</strong>
                        ${event.event_date}
                    </p>

                    <p>
                        <strong>Ticket Price:</strong>
                        RM ${Number(event.ticket_price).toFixed(2)}
                    </p>

                    <p>
                        <strong>Tickets Available:</strong>
                        ${ticketsAvailable}
                    </p>
                </div>

                <button
                    class="event-btn"
                    onclick="viewEvent(${event.id})">
                    View Event
                </button>
            `;

            eventsGrid.appendChild(eventCard);
        });

    } catch (error) {

        console.error(error);

        loadingMessage.textContent =
            "Unable to load events. Please try again.";

        loadingMessage.style.color = "red";
    }
}


// Open individual event
function viewEvent(eventId) {

    window.location.href =
        `event-details.html?id=${eventId}`;
}


// Logout
document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";
    });


loadEvents();