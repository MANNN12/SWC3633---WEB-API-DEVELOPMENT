<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_helpers.php';

jsonHeaders(['POST']);

$data = readJson();
$email = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');

if (empty($email) || empty($password)) {
    respond(422, ['error' => 'Email and password fields are required']);
}

$stmt = $conn->prepare('SELECT id, name, email, password, role FROM users WHERE email = ?');
$stmt->bind_param('s', $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// MENGGUNAKAN password_verify() UNTUK SEMAK KATA LALUAN
if (!$user || !password_verify($password, $user['password'])) {
    respond(401, ['error' => 'Invalid email or password credentials']);
}

// Generate JWT Token (Base64Url Safe)
$header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT'])));
$payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode([
    'sub' => $user['id'],
    'name' => $user['name'],
    'role' => $user['role'],
    'iat' => time(),
    'exp' => time() + (3600 * 5) 
])));

$rawSignature = hash_hmac('sha256', "$header.$payload", 'SPORTSPHERE_SECRET_KEY', true);
$signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($rawSignature));
$jwtToken = "$header.$payload.$signature";

respond(200, [
    'message' => 'Authentication successful',
    'token' => $jwtToken,
    'user' => [
        'id' => $user['id'],
        'name' => $user['name'],
        'role' => $user['role']
    ]
]);