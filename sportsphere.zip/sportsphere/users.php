<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_helpers.php';

jsonHeaders(['GET', 'POST', 'PUT', 'DELETE']);
$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? validId($_GET['id']) : null;

if ($method === 'GET') {
    if ($id !== null) {
        $stmt = $conn->prepare('SELECT id, name, email, role, created_at FROM users WHERE id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if (!$user) respond(404, ['error' => 'User not found']);
        respond(200, ['data' => $user]);
    }

    $page = validId($_GET['page'] ?? 1) ?? 1;
    $limit = validId($_GET['limit'] ?? 10) ?? 10;
    $offset = ($page - 1) * $limit; // Pembetulan formula offset

    $stmt = $conn->prepare('SELECT id, name, email, role, created_at FROM users LIMIT ? OFFSET ?');
    $stmt->bind_param('ii', $limit, $offset);
    $stmt->execute();
    $users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    respond(200, [
        'page' => $page,
        'limit' => $limit,
        'data' => $users
    ]);
}

if ($method === 'POST') {
    $data = readJson();
    $name = trim($data['name'] ?? '');
    $email = trim($data['email'] ?? '');
    $password = trim($data['password'] ?? '');
    $role = trim($data['role'] ?? 'customer');

    if (empty($name) || !filter_var($email, FILTER_VALIDATE_EMAIL) || empty($password)) {
        respond(422, ['error' => 'Valid name, email, and password required']);
    }

    // MENGGUNAKAN password_hash() SEBELUM SIMPAN KE DATABASE
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    try {
        $stmt = $conn->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('ssss', $name, $email, $hashedPassword, $role);
        $stmt->execute();
        respond(201, ['message' => 'User created successfully', 'id' => $conn->insert_id]);
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() === 1062) respond(409, ['error' => 'Email address already exists']);
        respond(500, ['error' => 'Failed to create user record']);
    }
}

if ($method === 'PUT') {
    $currentUser = authenticateToken();
    if ($id === null) respond(400, ['error' => 'User ID is required']);

    $data = readJson();
    $name = trim($data['name'] ?? '');
    $role = trim($data['role'] ?? '');

    $stmt = $conn->prepare('UPDATE users SET name = ?, role = ? WHERE id = ?');
    $stmt->bind_param('ssi', $name, $role, $id);
    $stmt->execute();

    if ($stmt->affected_rows === 0) respond(404, ['error' => 'User not found or no changes made']);
    respond(200, ['message' => 'User profile updated successfully']);
}

if ($method === 'DELETE') {
    $currentUser = authenticateToken();
    authorizeRoles(['admin'], $currentUser);

    if ($id === null) respond(400, ['error' => 'User ID is required']);

    $stmt = $conn->prepare('DELETE FROM users WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();

    if ($stmt->affected_rows === 0) respond(404, ['error' => 'User not found']);
    respond(200, ['message' => 'User record deleted successfully']);
}

respond(405, ['error' => 'Method Not Allowed']);